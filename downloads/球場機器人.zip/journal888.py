﻿# NX 1872
# Journal created by Admin on Fri Jun 14 13:56:36 2024 台北標準時間

#
import math
import NXOpen
import NXOpen.Annotations
import NXOpen.Assemblies
import NXOpen.Drawings
import NXOpen.Features
import NXOpen.GeometricUtilities
import NXOpen.Preferences
def main() : 

    theSession  = NXOpen.Session.GetSession()
    workPart = theSession.Parts.Work
    displayPart = theSession.Parts.Display
    # ----------------------------------------------
    #   Menu: Tools->Movie->Record...
    # ----------------------------------------------
    theUI = NXOpen.UI.GetUI()
    
    theUI.MovieManager.Start("F:\\鹽+命\Sie\\Siemens_NX1872\\movie88.avi", False)
    
    rotMatrix1 = NXOpen.Matrix3x3()
    
    rotMatrix1.Xx = -0.93618116057654011
    rotMatrix1.Xy = 0.29900492093214331
    rotMatrix1.Xz = -0.18482665348895594
    rotMatrix1.Yx = -0.2157561034222544
    rotMatrix1.Yy = -0.073670018668664475
    rotMatrix1.Yz = 0.9736642296938941
    rotMatrix1.Zx = 0.27751421300108076
    rotMatrix1.Zy = 0.9514035871320452
    rotMatrix1.Zz = 0.13348062022132415
    translation1 = NXOpen.Point3d(-106.45552778988912, -13.208824745241508, -48.880689533128837)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix1, translation1, 0.36738246376426498)
    
    # ----------------------------------------------
    #   Menu: Edit->Redo
    # ----------------------------------------------
    theSession.Redo()
    
    rotMatrix2 = NXOpen.Matrix3x3()
    
    rotMatrix2.Xx = -0.97753671208517678
    rotMatrix2.Xy = -0.0018910905711968778
    rotMatrix2.Xz = -0.21075673251916766
    rotMatrix2.Yx = -0.21062300517404398
    rotMatrix2.Yy = -0.02796252587776726
    rotMatrix2.Yz = 0.97716735866380133
    rotMatrix2.Zx = -0.0077412025654313987
    rotMatrix2.Zy = 0.99960718330901865
    rotMatrix2.Zz = 0.026936088428987572
    translation2 = NXOpen.Point3d(-100.77463905539308, -13.946479156739123, -17.961125775621145)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix2, translation2, 0.36738246376426498)
    
    # ----------------------------------------------
    #   Menu: Edit->Redo
    # ----------------------------------------------
    theSession.Redo()
    
    rotMatrix3 = NXOpen.Matrix3x3()
    
    rotMatrix3.Xx = -0.66428304216222678
    rotMatrix3.Xy = 0.73744460270363532
    rotMatrix3.Xz = -0.12207988302327967
    rotMatrix3.Yx = -0.21062300517404398
    rotMatrix3.Yy = -0.02796252587776726
    rotMatrix3.Yz = 0.97716735866380133
    rotMatrix3.Zx = 0.71719313269659413
    rotMatrix3.Zy = 0.67482853754847683
    rotMatrix3.Zz = 0.17389783012744167
    translation3 = NXOpen.Point3d(-124.70587870030148, -13.946479156739123, -67.849640335121535)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix3, translation3, 0.36738246376426498)
    
    rotMatrix4 = NXOpen.Matrix3x3()
    
    rotMatrix4.Xx = -0.97572639196543776
    rotMatrix4.Xy = 0.067330631107158229
    rotMatrix4.Xz = -0.20838568601711377
    rotMatrix4.Yx = -0.21062300517404398
    rotMatrix4.Yy = -0.02796252587776726
    rotMatrix4.Yz = 0.97716735866380133
    rotMatrix4.Zx = 0.059966304818338798
    rotMatrix4.Zy = 0.997338800639607
    rotMatrix4.Zz = 0.041465154349008666
    translation4 = NXOpen.Point3d(-101.08820088735098, -13.946479156739123, -22.696352113950184)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix4, translation4, 0.36738246376426498)
    
    markId1 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchFeature26 = workPart.Features.FindObject("SKETCH(1)")
    sketch26 = sketchFeature26.FindObject("SKETCH_000")
    parallelDimension3 = sketch26.FindObject("Dimension p0")
    sketchLinearDimensionBuilder1 = workPart.Sketches.CreateLinearDimensionBuilder(parallelDimension3)
    
    sketchLinearDimensionBuilder1.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Inferred
    
    sketchLinearDimensionBuilder1.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId1, "Linear Dimension Dialog")
    
    sketchLinearDimensionBuilder1.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits1 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits2 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    sketchLinearDimensionBuilder1.Style.OrdinateStyle.DoglegCreationOption = NXOpen.Annotations.OrdinateDoglegCreationOption.No
    
    dimensionlinearunits3 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits4 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits5 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits6 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    sketchLinearDimensionBuilder1.Origin.SetInferRelativeToGeometry(True)
    
    sketchLinearDimensionBuilder1.Origin.SetInferRelativeToGeometry(True)
    
    sketchLinearDimensionBuilder1.Measurement.Direction = NXOpen.Direction.Null
    
    sketchLinearDimensionBuilder1.Measurement.DirectionView = NXOpen.View.Null
    
    sketchLinearDimensionBuilder1.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits7 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits8 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits9 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits10 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits11 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits12 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits13 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits14 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits15 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits16 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits17 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits18 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    markId2 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Linear Dimension")
    
    theSession.DeleteUndoMark(markId2, None)
    
    markId3 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Linear Dimension")
    
    sketchLinearDimensionBuilder1.Driving.ExpressionValue.SetFormula("140")
    
    sketchLinearDimensionBuilder1.Driving.ExpressionValue.SetFormula("140")
    
    sketchLinearDimensionBuilder1.Driving.ExpressionMode = NXOpen.Annotations.DrivingValueBuilder.DrivingExpressionMode.KeepExpression
    
    sketchLinearDimensionBuilder1.Origin.SetInferRelativeToGeometry(True)
    
    nXObject1 = sketchLinearDimensionBuilder1.Commit()
    
    taggedObject1 = sketchLinearDimensionBuilder1.SecondAssociativity.Value
    
    line28 = taggedObject1
    point1_3 = NXOpen.Point3d(-1.8369701987210301e-14, 0.0, 140.0)
    point2_3 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchLinearDimensionBuilder1.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line28, NXOpen.View.Null, point1_3, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_3)
    
    point1_4 = NXOpen.Point3d(-9.3716429166601866e-16, 0.0, 0.0)
    point2_4 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchLinearDimensionBuilder1.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line28, NXOpen.View.Null, point1_4, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_4)
    
    theSession.SetUndoMarkName(markId3, "Linear Dimension - =")
    
    theSession.SetUndoMarkVisibility(markId3, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId1, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId4 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Linear Dimension")
    
    markId5 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Linear Dimension")
    
    nXObject2 = sketchLinearDimensionBuilder1.Commit()
    
    theSession.DeleteUndoMark(markId5, None)
    
    theSession.SetUndoMarkName(markId1, "Linear Dimension")
    
    expression1 = sketchLinearDimensionBuilder1.Driving.ExpressionValue
    sketchLinearDimensionBuilder1.Destroy()
    
    theSession.DeleteUndoMark(markId4, None)
    
    theSession.SetUndoMarkVisibility(markId1, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId3, None)
    
    markId6 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    parallelDimension4 = sketch26.FindObject("ENTITY 26 1 1")
    sketchLinearDimensionBuilder2 = workPart.Sketches.CreateLinearDimensionBuilder(parallelDimension4)
    
    sketchLinearDimensionBuilder2.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Inferred
    
    sketchLinearDimensionBuilder2.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId6, "Linear Dimension Dialog")
    
    sketchLinearDimensionBuilder2.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits19 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits20 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    sketchLinearDimensionBuilder2.Style.OrdinateStyle.DoglegCreationOption = NXOpen.Annotations.OrdinateDoglegCreationOption.No
    
    dimensionlinearunits21 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits22 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits23 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits24 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    sketchLinearDimensionBuilder2.Origin.SetInferRelativeToGeometry(True)
    
    sketchLinearDimensionBuilder2.Origin.SetInferRelativeToGeometry(True)
    
    sketchLinearDimensionBuilder2.Measurement.Direction = NXOpen.Direction.Null
    
    sketchLinearDimensionBuilder2.Measurement.DirectionView = NXOpen.View.Null
    
    sketchLinearDimensionBuilder2.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits25 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits26 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits27 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits28 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits29 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits30 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits31 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits32 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits33 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits34 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits35 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits36 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    # ----------------------------------------------
    #   Dialog Begin Linear Dimension
    # ----------------------------------------------
    markId7 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Linear Dimension")
    
    theSession.DeleteUndoMark(markId7, None)
    
    markId8 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Linear Dimension")
    
    sketchLinearDimensionBuilder2.Driving.ExpressionValue.SetFormula("140")
    
    sketchLinearDimensionBuilder2.Driving.ExpressionValue.SetFormula("140")
    
    sketchLinearDimensionBuilder2.Driving.ExpressionMode = NXOpen.Annotations.DrivingValueBuilder.DrivingExpressionMode.KeepExpression
    
    sketchLinearDimensionBuilder2.Origin.SetInferRelativeToGeometry(True)
    
    nXObject3 = sketchLinearDimensionBuilder2.Commit()
    
    taggedObject2 = sketchLinearDimensionBuilder2.SecondAssociativity.Value
    
    line29 = taggedObject2
    point1_5 = NXOpen.Point3d(139.99999999999997, 0.0, 140.0)
    point2_5 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchLinearDimensionBuilder2.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line29, NXOpen.View.Null, point1_5, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_5)
    
    point1_6 = NXOpen.Point3d(-2.8421709430404007e-14, 0.0, 140.0)
    point2_6 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchLinearDimensionBuilder2.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line29, NXOpen.View.Null, point1_6, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_6)
    
    theSession.SetUndoMarkName(markId8, "Linear Dimension - =")
    
    theSession.SetUndoMarkVisibility(markId8, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId6, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId9 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Linear Dimension")
    
    markId10 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Linear Dimension")
    
    nXObject4 = sketchLinearDimensionBuilder2.Commit()
    
    theSession.DeleteUndoMark(markId10, None)
    
    theSession.SetUndoMarkName(markId6, "Linear Dimension")
    
    expression2 = sketchLinearDimensionBuilder2.Driving.ExpressionValue
    sketchLinearDimensionBuilder2.Destroy()
    
    theSession.DeleteUndoMark(markId9, None)
    
    theSession.SetUndoMarkVisibility(markId6, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId8, None)
    
    rotMatrix5 = NXOpen.Matrix3x3()
    
    rotMatrix5.Xx = -0.93201659244966373
    rotMatrix5.Xy = 0.30494427893989845
    rotMatrix5.Xz = -0.19584192130477496
    rotMatrix5.Yx = -0.19679341591788443
    rotMatrix5.Yy = 0.027937983992805226
    rotMatrix5.Yz = 0.98004684607511938
    rotMatrix5.Zx = 0.30433110726623191
    rotMatrix5.Zy = 0.95196032259346119
    rotMatrix5.Zz = 0.033972361676311368
    translation5 = NXOpen.Point3d(-104.58031845996052, -14.959542955631967, -35.676171653241951)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix5, translation5, 0.36738246376426498)
    
    rotMatrix6 = NXOpen.Matrix3x3()
    
    rotMatrix6.Xx = -0.97892225017183732
    rotMatrix6.Xy = 0.050090011273430747
    rotMatrix6.Xz = -0.19799550219420933
    rotMatrix6.Yx = -0.19679341591788443
    rotMatrix6.Yy = 0.027937983992805226
    rotMatrix6.Yz = 0.98004684607511938
    rotMatrix6.Zx = 0.054622152739342317
    rotMatrix6.Zy = 0.99835387504684403
    rotMatrix6.Zz = -0.017491729733637721
    translation6 = NXOpen.Point3d(-101.78606560489803, -14.959542955631967, -17.42869043198337)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix6, translation6, 0.36738246376426498)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Curve->Arc...
    # ----------------------------------------------
    markId11 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId12 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    theSession.DeleteUndoMark(markId12, "Curve")
    
    rotMatrix7 = NXOpen.Matrix3x3()
    
    rotMatrix7.Xx = -0.70971358043637289
    rotMatrix7.Xy = 0.68908367412200811
    rotMatrix7.Xz = -0.14652755304959456
    rotMatrix7.Yx = -0.22314275891262469
    rotMatrix7.Yy = -0.022599378907627293
    rotMatrix7.Yz = 0.97452376944733998
    rotMatrix7.Zx = 0.66821698787822614
    rotMatrix7.Zy = 0.72432931607902451
    rotMatrix7.Zz = 0.1698031182854032
    translation7 = NXOpen.Point3d(-121.12003267977501, -13.026260874218231, -67.395458043654486)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix7, translation7, 0.36738246376426498)
    
    # ----------------------------------------------
    #   Menu: Insert->Design Feature->Extrude...
    # ----------------------------------------------
    markId13 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder1 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section1 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder1.Section = section1
    
    extrudeBuilder1.AllowSelfIntersectingSection(True)
    
    unit1 = extrudeBuilder1.Draft.FrontDraftAngle.Units
    
    expression3 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit1)
    
    extrudeBuilder1.DistanceTolerance = 0.01
    
    extrudeBuilder1.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies1 = [NXOpen.Body.Null] * 1 
    targetBodies1[0] = NXOpen.Body.Null
    extrudeBuilder1.BooleanOperation.SetTargetBodies(targetBodies1)
    
    extrudeBuilder1.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder1.Limits.EndExtend.Value.SetFormula("140")
    
    extrudeBuilder1.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder1.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder1.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder1.Offset.EndOffset.SetFormula("5")
    
    smartVolumeProfileBuilder1 = extrudeBuilder1.SmartVolumeProfile
    
    smartVolumeProfileBuilder1.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder1.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId13, "Extrude Dialog")
    
    section1.DistanceTolerance = 0.01
    
    section1.ChainingTolerance = 0.0094999999999999998
    
    section1.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    markId14 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    curves1 = [NXOpen.ICurve.Null] * 4 
    line30 = sketch26.FindObject("Curve Line3")
    curves1[0] = line30
    curves1[1] = line29
    line31 = sketch26.FindObject("Curve Line4")
    curves1[2] = line31
    curves1[3] = line28
    seedPoint1 = NXOpen.Point3d(46.66666666666665, 0.0, 93.333333333333329)
    regionBoundaryRule1 = workPart.ScRuleFactory.CreateRuleRegionBoundary(sketch26, curves1, seedPoint1, 0.01)
    
    section1.AllowSelfIntersection(True)
    
    rules1 = [None] * 1 
    rules1[0] = regionBoundaryRule1
    helpPoint1 = NXOpen.Point3d(0.0, 0.0, 0.0)
    section1.AddToSection(rules1, NXOpen.NXObject.Null, NXOpen.NXObject.Null, NXOpen.NXObject.Null, helpPoint1, NXOpen.Section.Mode.Create, False)
    
    theSession.DeleteUndoMark(markId14, None)
    
    markId15 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId16 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    theSession.DeleteUndoMark(markId16, None)
    
    direction2 = workPart.Directions.CreateDirection(sketch26, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrudeBuilder1.Direction = direction2
    
    unit2 = expression1.Units
    
    expression4 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit2)
    
    theSession.DeleteUndoMark(markId15, None)
    
    markId17 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    theSession.DeleteUndoMark(markId17, None)
    
    markId18 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    extrudeBuilder1.ParentFeatureInternal = False
    
    markId19 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    feature1 = extrudeBuilder1.CommitFeature()
    
    theSession.DeleteUndoMark(markId18, None)
    
    theSession.SetUndoMarkName(markId13, "Extrude")
    
    expression5 = extrudeBuilder1.Limits.StartExtend.Value
    expression6 = extrudeBuilder1.Limits.EndExtend.Value
    extrudeBuilder1.Destroy()
    
    workPart.Expressions.Delete(expression3)
    
    workPart.Expressions.Delete(expression4)
    
    rotMatrix8 = NXOpen.Matrix3x3()
    
    rotMatrix8.Xx = -0.96421184661840487
    rotMatrix8.Xy = 0.14784097339701016
    rotMatrix8.Xz = -0.22008762215480185
    rotMatrix8.Yx = -0.23188390554981442
    rotMatrix8.Yy = -0.067750592488982145
    rotMatrix8.Yz = 0.97038121970922209
    rotMatrix8.Zx = 0.12855103728751005
    rotMatrix8.Zy = 0.98668784516807617
    rotMatrix8.Zz = 0.099607866204877188
    translation8 = NXOpen.Point3d(-136.04293826041811, -15.284987078641535, -6.3400768204339286)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix8, translation8, 0.36738246376426498)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Curve->Arc...
    # ----------------------------------------------
    markId20 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId21 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    rotMatrix9 = NXOpen.Matrix3x3()
    
    rotMatrix9.Xx = -0.97124421508774084
    rotMatrix9.Xy = 0.016145874346781774
    rotMatrix9.Xz = -0.23753733475010133
    rotMatrix9.Yx = -0.23785537134575016
    rotMatrix9.Yy = -0.021951963720428846
    rotMatrix9.Yz = 0.97105248756737828
    rotMatrix9.Zx = 0.010464080493710913
    rotMatrix9.Zy = 0.99962864206184199
    rotMatrix9.Zz = 0.025161100711738032
    translation9 = NXOpen.Point3d(-143.54784951940962, -11.708069209198236, 8.0431395222153554)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix9, translation9, 0.36738246376426498)
    
    rotMatrix10 = NXOpen.Matrix3x3()
    
    rotMatrix10.Xx = -0.94807544940025179
    rotMatrix10.Xy = 0.22213316460107507
    rotMatrix10.Xz = -0.22761766062594516
    rotMatrix10.Yx = -0.23578672228069208
    rotMatrix10.Yy = -0.010610056124734127
    rotMatrix10.Yz = 0.97174690547753173
    rotMatrix10.Zx = 0.21344217915080341
    rotMatrix10.Zy = 0.97495860624610575
    rotMatrix10.Zz = 0.062435184519744079
    translation10 = NXOpen.Point3d(-131.44492998842424, -11.107550365764411, -10.501415757443084)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix10, translation10, 0.36738246376426498)
    
    scalar1 = workPart.Scalars.CreateScalar(1.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    point4 = workPart.Points.CreatePoint(line31, scalar1, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    datumAxis2 = workPart.Datums.FindObject("SKETCH(1:1B) X axis")
    direction3 = workPart.Directions.CreateDirection(datumAxis2, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    datumPlane2 = workPart.Datums.FindObject("SKETCH(1:1B) XY plane")
    xform2 = workPart.Xforms.CreateXformByPlaneXDirPoint(datumPlane2, direction3, point4, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem3 = workPart.CoordinateSystems.CreateCoordinateSystem(xform2, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    datumCsysBuilder1 = workPart.Features.CreateDatumCsysBuilder(NXOpen.Features.Feature.Null)
    
    datumCsysBuilder1.Csys = cartesianCoordinateSystem3
    
    datumCsysBuilder1.DisplayScaleFactor = 1.25
    
    feature2 = datumCsysBuilder1.CommitFeature()
    
    datumCsysBuilder1.Destroy()
    
    sketchInPlaceBuilder1 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    sketchInPlaceBuilder1.Csystem = cartesianCoordinateSystem3
    
    sketchInPlaceBuilder1.PlaneOption = NXOpen.Sketch.PlaneOption.Inferred
    
    theSession.Preferences.Sketch.CreateInferredConstraints = True
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = True
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = True
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    nXObject5 = sketchInPlaceBuilder1.Commit()
    
    sketchInPlaceBuilder1.Destroy()
    
    sketch27 = nXObject5
    sketch27.Activate(NXOpen.Sketch.ViewReorient.FalseValue)
    
    rotMatrix11 = NXOpen.Matrix3x3()
    
    rotMatrix11.Xx = -0.97127863562228711
    rotMatrix11.Xy = -0.047386719622658918
    rotMatrix11.Xz = -0.23317870997824433
    rotMatrix11.Yx = -0.23399566695293419
    rotMatrix11.Yy = 0.012416159521434694
    rotMatrix11.Yz = 0.97215835481159696
    rotMatrix11.Zx = -0.043172211328190414
    rotMatrix11.Zy = 0.9987994482307998
    rotMatrix11.Zz = -0.023147837542463332
    translation11 = NXOpen.Point3d(-146.89113161123342, -9.7584733738041933, 30.678516316208999)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix11, translation11, 0.36738246376426498)
    
    markId22 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    theSession.ActiveSketch.Deactivate(NXOpen.Sketch.ViewReorient.FalseValue, NXOpen.Sketch.UpdateLevel.Model)
    
    markId23 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "")
    
    nErrs1 = theSession.UpdateManager.AddToDeleteList(sketch27)
    
    datumCsys4 = feature2
    nErrs2 = theSession.UpdateManager.AddToDeleteList(datumCsys4)
    
    nErrs3 = theSession.UpdateManager.AddToDeleteList(point4)
    
    nErrs4 = theSession.UpdateManager.DoUpdate(markId23)
    
    theSession.DeleteUndoMark(markId23, "")
    
    theSession.UndoToMark(markId21, "Curve")
    
    theSession.DeleteUndoMark(markId21, "Curve")
    
    rotMatrix12 = NXOpen.Matrix3x3()
    
    rotMatrix12.Xx = -0.9339889074943839
    rotMatrix12.Xy = 0.23287029992067398
    rotMatrix12.Xz = -0.27099104061261658
    rotMatrix12.Yx = -0.29889273689657386
    rotMatrix12.Yy = -0.093646725136742659
    rotMatrix12.Yz = 0.94968069512949538
    rotMatrix12.Zx = 0.19577500480890994
    rotMatrix12.Zy = 0.96798848871566012
    rotMatrix12.Zz = 0.15706824378610873
    translation12 = NXOpen.Point3d(-127.23655806774728, -11.066644226074715, -0.8196816724478353)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix12, translation12, 0.36738246376426498)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Curve->Arc...
    # ----------------------------------------------
    markId24 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId25 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    scalar2 = workPart.Scalars.CreateScalar(1.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    point5 = workPart.Points.CreatePoint(line31, scalar2, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    direction4 = workPart.Directions.CreateDirection(datumAxis2, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    xform3 = workPart.Xforms.CreateXformByPlaneXDirPoint(datumPlane2, direction4, point5, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem4 = workPart.CoordinateSystems.CreateCoordinateSystem(xform3, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    datumCsysBuilder2 = workPart.Features.CreateDatumCsysBuilder(NXOpen.Features.Feature.Null)
    
    datumCsysBuilder2.Csys = cartesianCoordinateSystem4
    
    datumCsysBuilder2.DisplayScaleFactor = 1.25
    
    feature3 = datumCsysBuilder2.CommitFeature()
    
    datumCsysBuilder2.Destroy()
    
    sketchInPlaceBuilder2 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    sketchInPlaceBuilder2.Csystem = cartesianCoordinateSystem4
    
    sketchInPlaceBuilder2.PlaneOption = NXOpen.Sketch.PlaneOption.Inferred
    
    theSession.Preferences.Sketch.CreateInferredConstraints = True
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = True
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = True
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    nXObject6 = sketchInPlaceBuilder2.Commit()
    
    sketchInPlaceBuilder2.Destroy()
    
    sketch28 = nXObject6
    sketch28.Activate(NXOpen.Sketch.ViewReorient.FalseValue)
    
    rotMatrix13 = NXOpen.Matrix3x3()
    
    rotMatrix13.Xx = -0.94372488443421754
    rotMatrix13.Xy = -0.12123256348970372
    rotMatrix13.Xz = -0.3077109163636304
    rotMatrix13.Yx = -0.29939590684827044
    rotMatrix13.Yy = -0.082143383769126568
    rotMatrix13.Yz = 0.9505864271414054
    rotMatrix13.Zx = -0.14051844527367768
    rotMatrix13.Zy = 0.98921945495055985
    rotMatrix13.Zz = 0.041224222069013917
    translation13 = NXOpen.Point3d(-148.21559362191698, -10.273715439017636, 46.237437386739479)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix13, translation13, 0.36738246376426498)
    
    theSession.SetUndoMarkVisibility(markId25, "Curve", NXOpen.Session.MarkVisibility.Visible)
    
    nXMatrix1 = theSession.ActiveSketch.Orientation
    
    center1 = NXOpen.Point3d(268.61117255584622, 0.0, 140.0)
    arc1 = workPart.Curves.CreateArc(center1, nXMatrix1, 128.61117255584625, ( 180.0 * math.pi/180.0 ), ( 255.70614869331791 * math.pi/180.0 ))
    
    theSession.ActiveSketch.AddGeometry(arc1, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    geom1_6 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_6.Geometry = arc1
    geom1_6.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom1_6.SplineDefiningPointIndex = 0
    geom2_6 = NXOpen.Sketch.ConstraintGeometry()
    
    datumCsys5 = feature3
    point6 = datumCsys5.FindObject("POINT 1")
    geom2_6.Geometry = point6
    geom2_6.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    geom2_6.SplineDefiningPointIndex = 0
    sketchGeometricConstraint1 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_6, geom2_6)
    
    geom1_7 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_7.Geometry = arc1
    geom1_7.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    geom1_7.SplineDefiningPointIndex = 0
    geom1Help1 = NXOpen.Sketch.ConstraintGeometryHelp()
    
    geom1Help1.Type = NXOpen.Sketch.ConstraintGeometryHelpType.Point
    geom1Help1.Point.X = 139.99999999999997
    geom1Help1.Point.Y = 0.0
    geom1Help1.Point.Z = 151.82916216890368
    geom1Help1.Parameter = 0.0
    geom2_7 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_7.Geometry = line31
    geom2_7.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    geom2_7.SplineDefiningPointIndex = 0
    geom2Help1 = NXOpen.Sketch.ConstraintGeometryHelp()
    
    geom2Help1.Type = NXOpen.Sketch.ConstraintGeometryHelpType.Point
    geom2Help1.Point.X = 139.99999999999997
    geom2Help1.Point.Y = 0.0
    geom2Help1.Point.Z = 151.82916216890368
    geom2Help1.Parameter = 0.0
    sketchTangentConstraint1 = theSession.ActiveSketch.CreateTangentConstraint(geom1_7, geom1Help1, geom2_7, geom2Help1)
    
    dimObject1_3 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_3.Geometry = arc1
    dimObject1_3.AssocType = NXOpen.Sketch.AssocType.NotSet
    dimObject1_3.AssocValue = 0
    dimObject1_3.HelpPoint.X = 0.0
    dimObject1_3.HelpPoint.Y = 0.0
    dimObject1_3.HelpPoint.Z = 0.0
    dimObject1_3.View = NXOpen.NXObject.Null
    dimOrigin3 = NXOpen.Point3d(225.9778182221757, 0.0, 91.170837898907635)
    sketchDimensionalConstraint1 = theSession.ActiveSketch.CreateRadialDimension(dimObject1_3, dimOrigin3, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    dimension1 = sketchDimensionalConstraint1.AssociatedDimension
    
    expression7 = sketchDimensionalConstraint1.AssociatedExpression
    
    theSession.ActiveSketch.Update()
    
    # ----------------------------------------------
    #   Dialog Begin Arc
    # ----------------------------------------------
    rotMatrix14 = NXOpen.Matrix3x3()
    
    rotMatrix14.Xx = -0.9509923224438529
    rotMatrix14.Xy = 0.10281360856287744
    rotMatrix14.Xz = -0.29162126902392832
    rotMatrix14.Yx = -0.29754922707404513
    rotMatrix14.Yy = -0.047675349630212555
    rotMatrix14.Yz = 0.9535153478079289
    rotMatrix14.Zx = 0.084131207767898286
    rotMatrix14.Zy = 0.99355745829414244
    rotMatrix14.Zz = 0.075931001228736125
    translation14 = NXOpen.Point3d(-132.91263943295786, -8.3558764905307257, 13.443659646473641)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix14, translation14, 0.36738246376426498)
    
    rotMatrix15 = NXOpen.Matrix3x3()
    
    rotMatrix15.Xx = -0.95171093895087966
    rotMatrix15.Xy = -0.064243768683504052
    rotMatrix15.Xz = -0.30019831256450419
    rotMatrix15.Yx = -0.29754922707404513
    rotMatrix15.Yy = -0.047675349630212555
    rotMatrix15.Yz = 0.9535153478079289
    rotMatrix15.Zx = -0.075569478950656049
    rotMatrix15.Zy = 0.99679476283885926
    rotMatrix15.Zz = 0.02625746804528066
    translation15 = NXOpen.Point3d(-143.78710852249762, -8.3558764905307257, 39.306376850767485)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix15, translation15, 0.36738246376426498)
    
    markId26 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    radiusDimension1 = dimension1
    sketchRadialDimensionBuilder1 = workPart.Sketches.CreateRadialDimensionBuilder(radiusDimension1)
    
    sketchRadialDimensionBuilder1.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Inferred
    
    sketchRadialDimensionBuilder1.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId26, "Radial Dimension Dialog")
    
    sketchRadialDimensionBuilder1.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits37 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits38 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRadialDimensionBuilder1.Style.OrdinateStyle.DoglegCreationOption = NXOpen.Annotations.OrdinateDoglegCreationOption.No
    
    dimensionlinearunits39 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits40 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits41 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits42 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRadialDimensionBuilder1.Origin.SetInferRelativeToGeometry(True)
    
    sketchRadialDimensionBuilder1.Origin.SetInferRelativeToGeometry(True)
    
    sketchRadialDimensionBuilder1.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRadialDimensionBuilder1.Measurement.DirectionView = NXOpen.View.Null
    
    dimensionlinearunits43 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits44 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits45 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits46 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits47 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits48 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits49 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits50 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits51 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits52 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits53 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits54 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    # ----------------------------------------------
    #   Dialog Begin Radial Dimension
    # ----------------------------------------------
    markId27 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Radial Dimension")
    
    theSession.DeleteUndoMark(markId27, None)
    
    markId28 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Radial Dimension")
    
    sketchRadialDimensionBuilder1.Driving.ExpressionValue.SetFormula("140")
    
    sketchRadialDimensionBuilder1.Driving.ExpressionMode = NXOpen.Annotations.DrivingValueBuilder.DrivingExpressionMode.KeepExpression
    
    nXObject7 = sketchRadialDimensionBuilder1.Commit()
    
    point1_7 = NXOpen.Point3d(280.0, 0.0, 140.0)
    point2_7 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRadialDimensionBuilder1.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, arc1, NXOpen.View.Null, point1_7, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_7)
    
    sketchRadialDimensionBuilder1.Driving.ExpressionValue.SetFormula("140")
    
    theSession.SetUndoMarkName(markId28, "Radial Dimension - =")
    
    theSession.SetUndoMarkVisibility(markId28, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId26, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId29 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Radial Dimension")
    
    markId30 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Radial Dimension")
    
    nXObject8 = sketchRadialDimensionBuilder1.Commit()
    
    theSession.DeleteUndoMark(markId30, None)
    
    theSession.SetUndoMarkName(markId26, "Radial Dimension")
    
    expression8 = sketchRadialDimensionBuilder1.Driving.ExpressionValue
    sketchRadialDimensionBuilder1.Destroy()
    
    theSession.DeleteUndoMark(markId29, None)
    
    theSession.SetUndoMarkVisibility(markId26, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId28, None)
    
    rotMatrix16 = NXOpen.Matrix3x3()
    
    rotMatrix16.Xx = -0.95286095654898861
    rotMatrix16.Xy = 0.062654512014519562
    rotMatrix16.Xz = -0.29686766346095939
    rotMatrix16.Yx = -0.2975424771610316
    rotMatrix16.Yy = -0.0015140189422972183
    rotMatrix16.Yz = 0.95470738031688007
    rotMatrix16.Zx = 0.05936726176457903
    rotMatrix16.Zy = 0.99803412760830279
    rotMatrix16.Zz = 0.020085028247706353
    translation16 = NXOpen.Point3d(-135.02399559951445, -5.2260150494915578, 21.022316964667759)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix16, translation16, 0.36738246376426498)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Curve->Line...
    # ----------------------------------------------
    markId31 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId32 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    theSession.SetUndoMarkVisibility(markId32, "Curve", NXOpen.Session.MarkVisibility.Visible)
    
    startPoint5 = NXOpen.Point3d(248.24654179535395, 0.0, 3.648550091882754)
    endPoint5 = NXOpen.Point3d(139.99999999999997, 0.0, 1.1368683772161603e-13)
    line32 = workPart.Curves.CreateLine(startPoint5, endPoint5)
    
    theSession.ActiveSketch.AddGeometry(line32, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    geom1_8 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_8.Geometry = line32
    geom1_8.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom1_8.SplineDefiningPointIndex = 0
    geom2_8 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_8.Geometry = arc1
    geom2_8.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom2_8.SplineDefiningPointIndex = 0
    sketchGeometricConstraint2 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_8, geom2_8)
    
    geom1_9 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_9.Geometry = line32
    geom1_9.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_9.SplineDefiningPointIndex = 0
    geom2_9 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_9.Geometry = line30
    geom2_9.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom2_9.SplineDefiningPointIndex = 0
    sketchGeometricConstraint3 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_9, geom2_9)
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = False
    
    theSession.ActiveSketch.Update()
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = True
    
    # ----------------------------------------------
    #   Dialog Begin Line
    # ----------------------------------------------
    rotMatrix17 = NXOpen.Matrix3x3()
    
    rotMatrix17.Xx = -0.95402722167474296
    rotMatrix17.Xy = 0.096269755450992867
    rotMatrix17.Xz = -0.2838383245599122
    rotMatrix17.Yx = -0.29367285590257242
    rotMatrix17.Yy = -0.11097868891899984
    rotMatrix17.Yz = 0.94944193309114355
    rotMatrix17.Zx = 0.059902537588977622
    rotMatrix17.Zy = 0.9891490609565522
    rotMatrix17.Zz = 0.13414850427483418
    translation17 = NXOpen.Point3d(-133.60600699029536, -12.986418884132895, 10.710027785402197)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix17, translation17, 0.36738246376426498)
    
    # ----------------------------------------------
    #   Menu: Insert->Design Feature->Extrude...
    # ----------------------------------------------
    markId33 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder2 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section2 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder2.Section = section2
    
    extrudeBuilder2.AllowSelfIntersectingSection(True)
    
    expression9 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit1)
    
    extrudeBuilder2.DistanceTolerance = 0.01
    
    extrudeBuilder2.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies2 = [NXOpen.Body.Null] * 1 
    targetBodies2[0] = NXOpen.Body.Null
    extrudeBuilder2.BooleanOperation.SetTargetBodies(targetBodies2)
    
    extrudeBuilder2.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder2.Limits.EndExtend.Value.SetFormula("140")
    
    extrudeBuilder2.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies3 = [NXOpen.Body.Null] * 1 
    targetBodies3[0] = NXOpen.Body.Null
    extrudeBuilder2.BooleanOperation.SetTargetBodies(targetBodies3)
    
    extrudeBuilder2.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder2.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder2.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder2.Offset.EndOffset.SetFormula("5")
    
    smartVolumeProfileBuilder2 = extrudeBuilder2.SmartVolumeProfile
    
    smartVolumeProfileBuilder2.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder2.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId33, "Extrude Dialog")
    
    section2.DistanceTolerance = 0.01
    
    section2.ChainingTolerance = 0.0094999999999999998
    
    section2.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    markId34 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    features1 = [NXOpen.Features.Feature.Null] * 1 
    sketchFeature27 = workPart.Features.FindObject("SKETCH(3)")
    features1[0] = sketchFeature27
    curveFeatureRule1 = workPart.ScRuleFactory.CreateRuleCurveFeature(features1)
    
    section2.AllowSelfIntersection(True)
    
    rules2 = [None] * 1 
    rules2[0] = curveFeatureRule1
    helpPoint2 = NXOpen.Point3d(0.0, 0.0, 0.0)
    section2.AddToSection(rules2, NXOpen.NXObject.Null, NXOpen.NXObject.Null, NXOpen.NXObject.Null, helpPoint2, NXOpen.Section.Mode.Create, False)
    
    theSession.DeleteUndoMark(markId34, None)
    
    markId35 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId36 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    theSession.DeleteUndoMark(markId36, None)
    
    direction5 = workPart.Directions.CreateDirection(theSession.ActiveSketch, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrudeBuilder2.Direction = direction5
    
    extrudeBuilder2.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies4 = [NXOpen.Body.Null] * 1 
    targetBodies4[0] = NXOpen.Body.Null
    extrudeBuilder2.BooleanOperation.SetTargetBodies(targetBodies4)
    
    targetBodies5 = []
    extrudeBuilder2.BooleanOperation.SetTargetBodies(targetBodies5)
    
    theSession.DeleteUndoMark(markId35, None)
    
    extrudeBuilder2.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies6 = [NXOpen.Body.Null] * 1 
    targetBodies6[0] = NXOpen.Body.Null
    extrudeBuilder2.BooleanOperation.SetTargetBodies(targetBodies6)
    
    targetBodies7 = []
    extrudeBuilder2.BooleanOperation.SetTargetBodies(targetBodies7)
    
    rotMatrix18 = NXOpen.Matrix3x3()
    
    rotMatrix18.Xx = -0.34089044683101916
    rotMatrix18.Xy = 0.9400925210266512
    rotMatrix18.Xz = 0.0044446787404746335
    rotMatrix18.Yx = -0.29367285590257242
    rotMatrix18.Yy = -0.11097868891899984
    rotMatrix18.Yz = 0.94944193309114355
    rotMatrix18.Zx = 0.89305652506735311
    rotMatrix18.Zy = 0.32235040331226211
    rotMatrix18.Zz = 0.31391123031686385
    translation18 = NXOpen.Point3d(-184.67942698000394, -12.986418884132895, -167.76118981756355)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix18, translation18, 0.36738246376426498)
    
    markId37 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    theSession.DeleteUndoMark(markId37, None)
    
    markId38 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    extrudeBuilder2.ParentFeatureInternal = False
    
    markId39 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    feature4 = extrudeBuilder2.CommitFeature()
    
    theSession.DeleteUndoMark(markId38, None)
    
    theSession.SetUndoMarkName(markId33, "Extrude")
    
    expression10 = extrudeBuilder2.Limits.StartExtend.Value
    expression11 = extrudeBuilder2.Limits.EndExtend.Value
    extrudeBuilder2.Destroy()
    
    workPart.Expressions.Delete(expression9)
    
    rotMatrix19 = NXOpen.Matrix3x3()
    
    rotMatrix19.Xx = -0.95137936561579539
    rotMatrix19.Xy = 0.13047904660160037
    rotMatrix19.Xz = -0.27902064633002743
    rotMatrix19.Yx = -0.29367285590257242
    rotMatrix19.Yy = -0.11097868891899984
    rotMatrix19.Yz = 0.94944193309114355
    rotMatrix19.Zx = 0.092916932722274498
    rotMatrix19.Zy = 0.98522025405680802
    rotMatrix19.Zz = 0.14390098891156727
    translation19 = NXOpen.Point3d(-145.73391598846965, -12.986418884132895, -10.143639990469566)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix19, translation19, 0.36738246376426498)
    
    # ----------------------------------------------
    #   Menu: Edit->Undo
    # ----------------------------------------------
    marksRecycled1, undoUnavailable1 = theSession.UndoLastNVisibleMarks(1)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Curve->Line...
    # ----------------------------------------------
    markId40 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId41 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    theSession.SetUndoMarkVisibility(markId41, "Curve", NXOpen.Session.MarkVisibility.Visible)
    
    startPoint6 = NXOpen.Point3d(139.99999999999997, 0.0, 140.0)
    endPoint6 = NXOpen.Point3d(139.99999999999969, 0.0, 1.8242750459413628)
    line33 = workPart.Curves.CreateLine(startPoint6, endPoint6)
    
    theSession.ActiveSketch.AddGeometry(line33, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    geom1_10 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_10.Geometry = line33
    geom1_10.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom1_10.SplineDefiningPointIndex = 0
    geom2_10 = NXOpen.Sketch.ConstraintGeometry()
    
    extrude1 = feature1
    edge1 = extrude1.FindObject("EDGE * 160 * 170 {(140,-140,140)(140,-70,140)(140,0,140) EXTRUDE(2)}")
    geom2_10.Geometry = edge1
    geom2_10.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom2_10.SplineDefiningPointIndex = 0
    sketchGeometricConstraint4 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_10, geom2_10)
    
    conGeom1_5 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_5.Geometry = line33
    conGeom1_5.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_5.SplineDefiningPointIndex = 0
    conGeom2_5 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_5.Geometry = line31
    conGeom2_5.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_5.SplineDefiningPointIndex = 0
    sketchGeometricConstraint5 = theSession.ActiveSketch.CreateCollinearConstraint(conGeom1_5, conGeom2_5)
    
    conGeom1_6 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_6.Geometry = line33
    conGeom1_6.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_6.SplineDefiningPointIndex = 0
    conGeom2_6 = NXOpen.Sketch.ConstraintGeometry()
    
    edge2 = extrude1.FindObject("EDGE * 120 * 150 {(-0,0,-0)(70,0,0)(140,0,0) EXTRUDE(2)}")
    conGeom2_6.Geometry = edge2
    conGeom2_6.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_6.SplineDefiningPointIndex = 0
    sketchGeometricConstraint6 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_6, conGeom2_6)
    
    geom1_11 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_11.Geometry = line33
    geom1_11.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_11.SplineDefiningPointIndex = 0
    geom2_11 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_11.Geometry = line32
    geom2_11.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom2_11.SplineDefiningPointIndex = 0
    sketchGeometricConstraint7 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_11, geom2_11)
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = False
    
    theSession.ActiveSketch.Update()
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = True
    
    # ----------------------------------------------
    #   Dialog Begin Line
    # ----------------------------------------------
    # ----------------------------------------------
    #   Menu: Insert->Design Feature->Extrude...
    # ----------------------------------------------
    markId42 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder3 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section3 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder3.Section = section3
    
    extrudeBuilder3.AllowSelfIntersectingSection(True)
    
    expression12 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit1)
    
    extrudeBuilder3.DistanceTolerance = 0.01
    
    extrudeBuilder3.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies8 = [NXOpen.Body.Null] * 1 
    targetBodies8[0] = NXOpen.Body.Null
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies8)
    
    extrudeBuilder3.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder3.Limits.EndExtend.Value.SetFormula("140")
    
    extrudeBuilder3.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies9 = [NXOpen.Body.Null] * 1 
    targetBodies9[0] = NXOpen.Body.Null
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies9)
    
    extrudeBuilder3.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder3.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder3.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder3.Offset.EndOffset.SetFormula("5")
    
    smartVolumeProfileBuilder3 = extrudeBuilder3.SmartVolumeProfile
    
    smartVolumeProfileBuilder3.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder3.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId42, "Extrude Dialog")
    
    section3.DistanceTolerance = 0.01
    
    section3.ChainingTolerance = 0.0094999999999999998
    
    section3.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    markId43 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    curves2 = [NXOpen.ICurve.Null] * 3 
    curves2[0] = line33
    curves2[1] = arc1
    curves2[2] = line32
    seedPoint2 = NXOpen.Point3d(193.54570879528495, 0.0, 11.482925837168956)
    regionBoundaryRule2 = workPart.ScRuleFactory.CreateRuleRegionBoundary(theSession.ActiveSketch, curves2, seedPoint2, 0.01)
    
    section3.AllowSelfIntersection(True)
    
    rules3 = [None] * 1 
    rules3[0] = regionBoundaryRule2
    helpPoint3 = NXOpen.Point3d(0.0, 0.0, 0.0)
    section3.AddToSection(rules3, NXOpen.NXObject.Null, NXOpen.NXObject.Null, NXOpen.NXObject.Null, helpPoint3, NXOpen.Section.Mode.Create, False)
    
    theSession.DeleteUndoMark(markId43, None)
    
    markId44 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId45 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    theSession.DeleteUndoMark(markId45, None)
    
    direction6 = workPart.Directions.CreateDirection(theSession.ActiveSketch, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrudeBuilder3.Direction = direction6
    
    targetBodies10 = [NXOpen.Body.Null] * 1 
    body1 = workPart.Bodies.FindObject("EXTRUDE(2)")
    targetBodies10[0] = body1
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies10)
    
    extrudeBuilder3.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies11 = [NXOpen.Body.Null] * 1 
    targetBodies11[0] = body1
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies11)
    
    expression13 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit2)
    
    theSession.DeleteUndoMark(markId44, None)
    
    extrudeBuilder3.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies12 = [NXOpen.Body.Null] * 1 
    targetBodies12[0] = body1
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies12)
    
    rotMatrix20 = NXOpen.Matrix3x3()
    
    rotMatrix20.Xx = -0.56575924290764146
    rotMatrix20.Xy = 0.81997334318140358
    rotMatrix20.Xz = -0.086949384911497909
    rotMatrix20.Yx = -0.23540567560917092
    rotMatrix20.Yy = -0.059557902402276243
    rotMatrix20.Yz = 0.97007062843508041
    rotMatrix20.Zx = 0.7902535333395001
    rotMatrix20.Zy = 0.56929480300926472
    rotMatrix20.Zz = 0.22672181260540769
    translation20 = NXOpen.Point3d(-167.64747852005962, -19.283340030686979, -143.86722844798885)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix20, translation20, 0.36738246376426498)
    
    markId46 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    theSession.DeleteUndoMark(markId46, None)
    
    markId47 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    extrudeBuilder3.ParentFeatureInternal = False
    
    markId48 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    feature5 = extrudeBuilder3.CommitFeature()
    
    theSession.DeleteUndoMark(markId47, None)
    
    theSession.SetUndoMarkName(markId42, "Extrude")
    
    expression14 = extrudeBuilder3.Limits.StartExtend.Value
    expression15 = extrudeBuilder3.Limits.EndExtend.Value
    extrudeBuilder3.Destroy()
    
    workPart.Expressions.Delete(expression12)
    
    workPart.Expressions.Delete(expression13)
    
    rotMatrix21 = NXOpen.Matrix3x3()
    
    rotMatrix21.Xx = -0.87388466690785238
    rotMatrix21.Xy = 0.44966621777765692
    rotMatrix21.Xz = -0.18473191801334937
    rotMatrix21.Yx = -0.24053280082431663
    rotMatrix21.Yy = -0.069724538367505459
    rotMatrix21.Yz = 0.96813349310776831
    rotMatrix21.Zx = 0.42245657844441659
    rotMatrix21.Zy = 0.89047110078821756
    rotMatrix21.Zz = 0.16909067978472803
    translation21 = NXOpen.Point3d(-148.47866450755254, -19.223009523335342, -71.698547238231441)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix21, translation21, 0.36738246376426498)
    
    rotMatrix22 = NXOpen.Matrix3x3()
    
    rotMatrix22.Xx = -0.95645423338534707
    rotMatrix22.Xy = -0.2131052341584746
    rotMatrix22.Xz = -0.19945289823292267
    rotMatrix22.Yx = -0.21801769777208199
    rotMatrix22.Yy = 0.067251438426780247
    rotMatrix22.Yz = 0.97362494189892856
    rotMatrix22.Zx = -0.1940710769213467
    rotMatrix22.Zy = 0.97471195909550457
    rotMatrix22.Zz = -0.11078363551895867
    translation22 = NXOpen.Point3d(-183.59339285992178, -12.813740798558193, 30.314944097411001)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix22, translation22, 0.36738246376426498)
    
    scaleAboutPoint1 = NXOpen.Point3d(-304.63824770856201, 1.44036996552528, 0.0)
    viewCenter1 = NXOpen.Point3d(304.63824770856223, -1.4403699655250344, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint1, viewCenter1)
    
    scaleAboutPoint2 = NXOpen.Point3d(-369.99503489426405, -17.104393340610631, 0.0)
    viewCenter2 = NXOpen.Point3d(369.99503489426451, 17.104393340610859, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint2, viewCenter2)
    
    scaleAboutPoint3 = NXOpen.Point3d(-293.83547296712356, -14.403699655251019, 0.0)
    viewCenter3 = NXOpen.Point3d(293.83547296712391, 14.403699655251266, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint3, viewCenter3)
    
    scaleAboutPoint4 = NXOpen.Point3d(-233.91608240127871, -12.099107710410879, 0.0)
    viewCenter4 = NXOpen.Point3d(233.91608240127911, 12.099107710411076, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint4, viewCenter4)
    
    scaleAboutPoint5 = NXOpen.Point3d(-186.67194753205499, -9.6792861683286642, 0.0)
    viewCenter5 = NXOpen.Point3d(186.67194753205521, 9.6792861683289004, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint5, viewCenter5)
    
    rotMatrix23 = NXOpen.Matrix3x3()
    
    rotMatrix23.Xx = -0.97703529182851567
    rotMatrix23.Xy = -0.0071059711790142817
    rotMatrix23.Xz = -0.21295901881623513
    rotMatrix23.Yx = -0.21285365862285019
    rotMatrix23.Yy = -0.013254554081784676
    rotMatrix23.Yz = 0.97699418463313437
    rotMatrix23.Zx = -0.0097651693501702476
    rotMatrix23.Zy = 0.99988690458956553
    rotMatrix23.Zz = 0.011437635151831702
    translation23 = NXOpen.Point3d(-24.949282086221373, -8.3085948294967977, 0.6450492415405904)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix23, translation23, 0.71754387453958002)
    
    scaleAboutPoint6 = NXOpen.Point3d(-158.92466051617916, -32.079919872175296, 0.0)
    viewCenter6 = NXOpen.Point3d(158.92466051617933, 32.079919872175516, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint6, viewCenter6)
    
    scaleAboutPoint7 = NXOpen.Point3d(-197.73398886728788, -40.099899840219123, 0.0)
    viewCenter7 = NXOpen.Point3d(197.7339888672881, 40.099899840219358, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint7, viewCenter7)
    
    scaleAboutPoint8 = NXOpen.Point3d(-157.44972167148143, -31.342450449826416, 0.0)
    viewCenter8 = NXOpen.Point3d(157.44972167148163, 31.342450449826636, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint8, viewCenter8)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Curve->Circle...
    # ----------------------------------------------
    markId49 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId50 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    scalar3 = workPart.Scalars.CreateScalar(0.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    point7 = workPart.Points.CreatePoint(line31, scalar3, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    direction7 = workPart.Directions.CreateDirection(datumAxis2, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    xform4 = workPart.Xforms.CreateXformByPlaneXDirPoint(datumPlane2, direction7, point7, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem5 = workPart.CoordinateSystems.CreateCoordinateSystem(xform4, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    datumCsysBuilder3 = workPart.Features.CreateDatumCsysBuilder(NXOpen.Features.Feature.Null)
    
    datumCsysBuilder3.Csys = cartesianCoordinateSystem5
    
    datumCsysBuilder3.DisplayScaleFactor = 1.25
    
    feature6 = datumCsysBuilder3.CommitFeature()
    
    datumCsysBuilder3.Destroy()
    
    sketchInPlaceBuilder3 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    sketchInPlaceBuilder3.Csystem = cartesianCoordinateSystem5
    
    sketchInPlaceBuilder3.PlaneOption = NXOpen.Sketch.PlaneOption.Inferred
    
    theSession.Preferences.Sketch.CreateInferredConstraints = True
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = True
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = True
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    nXObject9 = sketchInPlaceBuilder3.Commit()
    
    sketchInPlaceBuilder3.Destroy()
    
    sketch29 = nXObject9
    sketch29.Activate(NXOpen.Sketch.ViewReorient.FalseValue)
    
    expression16 = workPart.Expressions.CreateSystemExpression("3")
    
    theSession.SetUndoMarkVisibility(markId50, "Curve", NXOpen.Session.MarkVisibility.Visible)
    
    nXMatrix2 = theSession.ActiveSketch.Orientation
    
    center2 = NXOpen.Point3d(139.99999999999997, 0.0, 0.0)
    arc2 = workPart.Curves.CreateArc(center2, nXMatrix2, 1.5, 0.0, ( 360.0 * math.pi/180.0 ))
    
    theSession.ActiveSketch.AddGeometry(arc2, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    geom1_12 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_12.Geometry = arc2
    geom1_12.PointType = NXOpen.Sketch.ConstraintPointType.ArcCenter
    geom1_12.SplineDefiningPointIndex = 0
    geom2_12 = NXOpen.Sketch.ConstraintGeometry()
    
    datumCsys6 = feature6
    point8 = datumCsys6.FindObject("POINT 1")
    geom2_12.Geometry = point8
    geom2_12.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    geom2_12.SplineDefiningPointIndex = 0
    sketchGeometricConstraint8 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_12, geom2_12)
    
    dimObject1_4 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_4.Geometry = arc2
    dimObject1_4.AssocType = NXOpen.Sketch.AssocType.NotSet
    dimObject1_4.AssocValue = 0
    dimObject1_4.HelpPoint.X = 0.0
    dimObject1_4.HelpPoint.Y = 0.0
    dimObject1_4.HelpPoint.Z = 0.0
    dimObject1_4.View = NXOpen.NXObject.Null
    dimOrigin4 = NXOpen.Point3d(139.99999999999997, 0.0, 3.3447432068735683)
    sketchDimensionalConstraint2 = theSession.ActiveSketch.CreateDiameterDimension(dimObject1_4, dimOrigin4, expression16, NXOpen.Sketch.DimensionOption.CreateAsDriving)
    
    dimension2 = sketchDimensionalConstraint2.AssociatedDimension
    
    theSession.ActiveSketch.Update()
    
    markId51 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    scaleAboutPoint9 = NXOpen.Point3d(-128.90965502658057, -30.678727969712455, 0.0)
    viewCenter9 = NXOpen.Point3d(128.90965502658082, 30.678727969712657, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint9, viewCenter9)
    
    scaleAboutPoint10 = NXOpen.Point3d(-160.39959936087686, -42.035757073884866, 0.0)
    viewCenter10 = NXOpen.Point3d(160.39959936087703, 42.035757073885115, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint10, viewCenter10)
    
    rotMatrix24 = NXOpen.Matrix3x3()
    
    rotMatrix24.Xx = -0.97104055982554416
    rotMatrix24.Xy = 0.11391019766868506
    rotMatrix24.Xz = -0.21001118551348152
    rotMatrix24.Yx = -0.21285365862285019
    rotMatrix24.Yy = -0.013254554081784676
    rotMatrix24.Yz = 0.97699418463313437
    rotMatrix24.Zx = 0.10850599607654852
    rotMatrix24.Zy = 0.99340262918072697
    rotMatrix24.Zz = 0.037116911944045872
    translation24 = NXOpen.Point3d(-58.430948521141318, -20.218726000430912, -16.117845392013059)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix24, translation24, 0.57403509963166399)
    
    markId52 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    expression17 = workPart.Expressions.CreateSystemExpression("30")
    
    rotMatrix25 = NXOpen.Matrix3x3()
    
    rotMatrix25.Xx = -0.96792309668114729
    rotMatrix25.Xy = -0.13374254770334115
    rotMatrix25.Xz = -0.21269181894234129
    rotMatrix25.Yx = -0.21285365862285019
    rotMatrix25.Yy = -0.013254554081784676
    rotMatrix25.Yz = 0.97699418463313437
    rotMatrix25.Zx = -0.13348482656110691
    rotMatrix25.Zy = 0.99092746845060198
    rotMatrix25.Zz = -0.015638201560228358
    translation25 = NXOpen.Point3d(-75.983562546784768, -20.218726000430912, 17.09175003264599)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix25, translation25, 0.57403509963166399)
    
    workPart.Expressions.Delete(expression17)
    
    theSession.DeleteUndoMark(markId52, "Curve")
    
    markId53 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Delete")
    
    notifyOnDelete1 = theSession.Preferences.Modeling.NotifyOnDelete
    
    theSession.UpdateManager.ClearErrorList()
    
    markId54 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Delete")
    
    objects1 = [NXOpen.TaggedObject.Null] * 1 
    objects1[0] = theSession.ActiveSketch
    nErrs5 = theSession.UpdateManager.AddObjectsToDeleteList(objects1)
    
    notifyOnDelete2 = theSession.Preferences.Modeling.NotifyOnDelete
    
    id1 = theSession.NewestVisibleUndoMark
    
    nErrs6 = theSession.UpdateManager.DoUpdate(id1)
    
    theSession.DeleteUndoMark(markId53, None)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Curve->Circle...
    # ----------------------------------------------
    markId55 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId56 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    scalar4 = workPart.Scalars.CreateScalar(1.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    point9 = workPart.Points.CreatePoint(line32, scalar4, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    datumAxis3 = workPart.Datums.FindObject("SKETCH(3:1B) X axis")
    direction8 = workPart.Directions.CreateDirection(datumAxis3, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    datumPlane3 = workPart.Datums.FindObject("SKETCH(3:1B) XY plane")
    xform5 = workPart.Xforms.CreateXformByPlaneXDirPoint(datumPlane3, direction8, point9, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem6 = workPart.CoordinateSystems.CreateCoordinateSystem(xform5, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    datumCsysBuilder4 = workPart.Features.CreateDatumCsysBuilder(NXOpen.Features.Feature.Null)
    
    datumCsysBuilder4.Csys = cartesianCoordinateSystem6
    
    datumCsysBuilder4.DisplayScaleFactor = 1.25
    
    feature7 = datumCsysBuilder4.CommitFeature()
    
    datumCsysBuilder4.Destroy()
    
    sketchInPlaceBuilder4 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    sketchInPlaceBuilder4.Csystem = cartesianCoordinateSystem6
    
    sketchInPlaceBuilder4.PlaneOption = NXOpen.Sketch.PlaneOption.Inferred
    
    theSession.Preferences.Sketch.CreateInferredConstraints = True
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = True
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = True
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    nXObject10 = sketchInPlaceBuilder4.Commit()
    
    sketchInPlaceBuilder4.Destroy()
    
    sketch30 = nXObject10
    sketch30.Activate(NXOpen.Sketch.ViewReorient.FalseValue)
    
    expression18 = workPart.Expressions.CreateSystemExpression("40")
    
    theSession.SetUndoMarkVisibility(markId56, "Curve", NXOpen.Session.MarkVisibility.Visible)
    
    nXMatrix3 = theSession.ActiveSketch.Orientation
    
    center3 = NXOpen.Point3d(139.99999999999997, 0.0, 0.0)
    arc3 = workPart.Curves.CreateArc(center3, nXMatrix3, 20.0, 0.0, ( 360.0 * math.pi/180.0 ))
    
    theSession.ActiveSketch.AddGeometry(arc3, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    geom1_13 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_13.Geometry = arc3
    geom1_13.PointType = NXOpen.Sketch.ConstraintPointType.ArcCenter
    geom1_13.SplineDefiningPointIndex = 0
    geom2_13 = NXOpen.Sketch.ConstraintGeometry()
    
    datumCsys7 = feature7
    point10 = datumCsys7.FindObject("POINT 1")
    geom2_13.Geometry = point10
    geom2_13.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    geom2_13.SplineDefiningPointIndex = 0
    sketchGeometricConstraint9 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_13, geom2_13)
    
    dimObject1_5 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_5.Geometry = arc3
    dimObject1_5.AssocType = NXOpen.Sketch.AssocType.NotSet
    dimObject1_5.AssocValue = 0
    dimObject1_5.HelpPoint.X = 0.0
    dimObject1_5.HelpPoint.Y = 0.0
    dimObject1_5.HelpPoint.Z = 0.0
    dimObject1_5.View = NXOpen.NXObject.Null
    dimOrigin5 = NXOpen.Point3d(139.99999999999997, 0.0, 5.2261612607399499)
    sketchDimensionalConstraint3 = theSession.ActiveSketch.CreateDiameterDimension(dimObject1_5, dimOrigin5, expression18, NXOpen.Sketch.DimensionOption.CreateAsDriving)
    
    dimension3 = sketchDimensionalConstraint3.AssociatedDimension
    
    theSession.ActiveSketch.Update()
    
    markId57 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    markId58 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    expression19 = workPart.Expressions.CreateSystemExpression("50")
    
    workPart.Expressions.Delete(expression19)
    
    theSession.DeleteUndoMark(markId58, "Curve")
    
    # ----------------------------------------------
    #   Menu: Edit->Undo
    # ----------------------------------------------
    marksRecycled2, undoUnavailable2 = theSession.UndoLastNVisibleMarks(1)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Curve->Circle...
    # ----------------------------------------------
    markId59 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId60 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    scalar5 = workPart.Scalars.CreateScalar(0.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    point11 = workPart.Points.CreatePoint(line31, scalar5, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    direction9 = workPart.Directions.CreateDirection(datumAxis2, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    xform6 = workPart.Xforms.CreateXformByPlaneXDirPoint(datumPlane2, direction9, point11, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem7 = workPart.CoordinateSystems.CreateCoordinateSystem(xform6, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    datumCsysBuilder5 = workPart.Features.CreateDatumCsysBuilder(NXOpen.Features.Feature.Null)
    
    datumCsysBuilder5.Csys = cartesianCoordinateSystem7
    
    datumCsysBuilder5.DisplayScaleFactor = 1.25
    
    feature8 = datumCsysBuilder5.CommitFeature()
    
    datumCsysBuilder5.Destroy()
    
    sketchInPlaceBuilder5 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    sketchInPlaceBuilder5.Csystem = cartesianCoordinateSystem7
    
    sketchInPlaceBuilder5.PlaneOption = NXOpen.Sketch.PlaneOption.Inferred
    
    theSession.Preferences.Sketch.CreateInferredConstraints = True
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = True
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = True
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    nXObject11 = sketchInPlaceBuilder5.Commit()
    
    sketchInPlaceBuilder5.Destroy()
    
    sketch31 = nXObject11
    sketch31.Activate(NXOpen.Sketch.ViewReorient.FalseValue)
    
    rotMatrix26 = NXOpen.Matrix3x3()
    
    rotMatrix26.Xx = -0.97622522338707207
    rotMatrix26.Xy = 0.050591215625863779
    rotMatrix26.Xz = -0.21077201456636074
    rotMatrix26.Yx = -0.21270177640627849
    rotMatrix26.Yy = -0.03633723674859575
    rotMatrix26.Yz = 0.97644127295966598
    rotMatrix26.Zx = 0.041740478393019913
    rotMatrix26.Zy = 0.99805818173440197
    rotMatrix26.Zz = 0.046234168496341113
    translation26 = NXOpen.Point3d(-62.143979680044055, -21.82621641687664, -7.1967420065337535)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix26, translation26, 0.57403509963166399)
    
    expression20 = workPart.Expressions.CreateSystemExpression("80")
    
    theSession.SetUndoMarkVisibility(markId60, "Curve", NXOpen.Session.MarkVisibility.Visible)
    
    nXMatrix4 = theSession.ActiveSketch.Orientation
    
    center4 = NXOpen.Point3d(139.99999999999997, 0.0, 0.0)
    arc4 = workPart.Curves.CreateArc(center4, nXMatrix4, 40.0, 0.0, ( 360.0 * math.pi/180.0 ))
    
    theSession.ActiveSketch.AddGeometry(arc4, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    geom1_14 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_14.Geometry = arc4
    geom1_14.PointType = NXOpen.Sketch.ConstraintPointType.ArcCenter
    geom1_14.SplineDefiningPointIndex = 0
    geom2_14 = NXOpen.Sketch.ConstraintGeometry()
    
    datumCsys8 = feature8
    point12 = datumCsys8.FindObject("POINT 1")
    geom2_14.Geometry = point12
    geom2_14.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    geom2_14.SplineDefiningPointIndex = 0
    sketchGeometricConstraint10 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_14, geom2_14)
    
    dimObject1_6 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_6.Geometry = arc4
    dimObject1_6.AssocType = NXOpen.Sketch.AssocType.NotSet
    dimObject1_6.AssocValue = 0
    dimObject1_6.HelpPoint.X = 0.0
    dimObject1_6.HelpPoint.Y = 0.0
    dimObject1_6.HelpPoint.Z = 0.0
    dimObject1_6.View = NXOpen.NXObject.Null
    dimOrigin6 = NXOpen.Point3d(139.99999999999997, 0.0, 5.2261612607399499)
    sketchDimensionalConstraint4 = theSession.ActiveSketch.CreateDiameterDimension(dimObject1_6, dimOrigin6, expression20, NXOpen.Sketch.DimensionOption.CreateAsDriving)
    
    dimension4 = sketchDimensionalConstraint4.AssociatedDimension
    
    theSession.ActiveSketch.Update()
    
    markId61 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    markId62 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    expression21 = workPart.Expressions.CreateSystemExpression("80")
    
    theSession.SetUndoMarkVisibility(markId62, "Curve", NXOpen.Session.MarkVisibility.Visible)
    
    nXMatrix5 = theSession.ActiveSketch.Orientation
    
    center5 = NXOpen.Point3d(0.0, 0.0, 0.0)
    arc5 = workPart.Curves.CreateArc(center5, nXMatrix5, 40.0, 0.0, ( 360.0 * math.pi/180.0 ))
    
    theSession.ActiveSketch.AddGeometry(arc5, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    geom1_15 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_15.Geometry = arc5
    geom1_15.PointType = NXOpen.Sketch.ConstraintPointType.ArcCenter
    geom1_15.SplineDefiningPointIndex = 0
    geom2_15 = NXOpen.Sketch.ConstraintGeometry()
    
    datumCsys9 = workPart.Features.FindObject("DATUM_CSYS(0)")
    point13 = datumCsys9.FindObject("POINT 1")
    geom2_15.Geometry = point13
    geom2_15.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    geom2_15.SplineDefiningPointIndex = 0
    sketchGeometricConstraint11 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_15, geom2_15)
    
    dimObject1_7 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_7.Geometry = arc5
    dimObject1_7.AssocType = NXOpen.Sketch.AssocType.NotSet
    dimObject1_7.AssocValue = 0
    dimObject1_7.HelpPoint.X = 0.0
    dimObject1_7.HelpPoint.Y = 0.0
    dimObject1_7.HelpPoint.Z = 0.0
    dimObject1_7.View = NXOpen.NXObject.Null
    dimOrigin7 = NXOpen.Point3d(0.0, 0.0, 5.2261612607399499)
    sketchDimensionalConstraint5 = theSession.ActiveSketch.CreateDiameterDimension(dimObject1_7, dimOrigin7, expression21, NXOpen.Sketch.DimensionOption.CreateAsDriving)
    
    dimension5 = sketchDimensionalConstraint5.AssociatedDimension
    
    theSession.ActiveSketch.Update()
    
    markId63 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    rotMatrix27 = NXOpen.Matrix3x3()
    
    rotMatrix27.Xx = 0.59605513923656372
    rotMatrix27.Xy = -0.79668499122880243
    rotMatrix27.Xz = 0.10005646276202586
    rotMatrix27.Yx = -0.13113377919751451
    rotMatrix27.Yy = 0.026352234738856402
    rotMatrix27.Yz = 0.99101437511150636
    rotMatrix27.Zx = -0.79216299013717018
    rotMatrix27.Zy = -0.60381999343764592
    rotMatrix27.Zz = -0.088764928783308189
    translation27 = NXOpen.Point3d(-300.70571215084874, -26.659735190296104, -25.749502648313189)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix27, translation27, 0.57403509963166399)
    
    rotMatrix28 = NXOpen.Matrix3x3()
    
    rotMatrix28.Xx = 0.97375399243860683
    rotMatrix28.Xy = -0.21569988077405988
    rotMatrix28.Xz = 0.072641060316699965
    rotMatrix28.Yx = -0.037284669175045179
    rotMatrix28.Yy = 0.16367268647615163
    rotMatrix28.Yz = 0.98580987271694087
    rotMatrix28.Zx = -0.22452842950144614
    rotMatrix28.Zy = -0.9626446972459487
    rotMatrix28.Zz = 0.15133463321354657
    translation28 = NXOpen.Point3d(-297.99322430644872, -26.558954755332628, -121.97617714269447)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix28, translation28, 0.57403509963166399)
    
    rotMatrix29 = NXOpen.Matrix3x3()
    
    rotMatrix29.Xx = 0.99912959475787777
    rotMatrix29.Xy = -0.012360358085171755
    rotMatrix29.Xz = 0.039840612783586769
    rotMatrix29.Yx = -0.037284669175045179
    rotMatrix29.Yy = 0.16367268647615163
    rotMatrix29.Yz = 0.98580987271694087
    rotMatrix29.Zx = -0.018705783155825939
    rotMatrix29.Zy = -0.98643726270335863
    rotMatrix29.Zz = 0.16306937304975891
    translation29 = NXOpen.Point3d(-284.76162605605202, -26.558954755332628, -145.65932087884556)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix29, translation29, 0.57403509963166399)
    
    rotMatrix30 = NXOpen.Matrix3x3()
    
    rotMatrix30.Xx = 0.31043989155459661
    rotMatrix30.Xy = -0.93412940297956215
    rotMatrix30.Xz = 0.17615144683089187
    rotMatrix30.Yx = -0.02286213657321369
    rotMatrix30.Yy = 0.17791641000093672
    rotMatrix30.Yz = 0.98377999256118553
    rotMatrix30.Zx = -0.95031805015104165
    rotMatrix30.Zy = -0.30943175263929351
    rotMatrix30.Zz = 0.033876157038500637
    translation30 = NXOpen.Point3d(-284.39237636994852, -26.962121369940988, 5.193242074143761)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix30, translation30, 0.57403509963166399)
    
    rotMatrix31 = NXOpen.Matrix3x3()
    
    rotMatrix31.Xx = -0.97976243955068365
    rotMatrix31.Xy = -0.19971813612036374
    rotMatrix31.Xz = 0.013350211620088322
    rotMatrix31.Yx = -0.02286213657321369
    rotMatrix31.Yy = 0.17791641000093672
    rotMatrix31.Yz = 0.98377999256118553
    rotMatrix31.Zx = -0.19885392819102393
    rotMatrix31.Zy = 0.96356547113156077
    rotMatrix31.Zz = -0.17888179920274877
    translation31 = NXOpen.Point3d(-90.503439094775018, -26.962121369940988, 26.696043209438123)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix31, translation31, 0.57403509963166399)
    
    rotMatrix32 = NXOpen.Matrix3x3()
    
    rotMatrix32.Xx = -0.71361818489511752
    rotMatrix32.Xy = 0.68777078401459846
    rotMatrix32.Xz = -0.13311812364567072
    rotMatrix32.Yx = -0.15682332257960072
    rotMatrix32.Yy = 0.028359480521330492
    rotMatrix32.Yz = 0.98721942108107674
    rotMatrix32.Zx = 0.6827558360659356
    rotMatrix32.Zy = 0.72537375781076263
    rotMatrix32.Zz = 0.087620658508145655
    translation32 = NXOpen.Point3d(-48.76760824740154, -23.654600999190848, -95.098591918327003)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix32, translation32, 0.57403509963166399)
    
    theSession.DeleteUndoMark(markId63, "Curve")
    
    rotMatrix33 = NXOpen.Matrix3x3()
    
    rotMatrix33.Xx = -0.75874855277981379
    rotMatrix33.Xy = 0.63588968881390651
    rotMatrix33.Xz = -0.1412265460694023
    rotMatrix33.Yx = -0.21623669226778439
    rotMatrix33.Yy = -0.041371738092727109
    rotMatrix33.Yz = 0.97546402916984898
    rotMatrix33.Zx = 0.61444473028225088
    rotMatrix33.Zy = 0.7706702816038401
    rotMatrix33.Zz = 0.16889342936015167
    translation33 = NXOpen.Point3d(-47.294742269293351, -21.761702319626917, -88.878698022577396)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix33, translation33, 0.57403509963166399)
    
    # ----------------------------------------------
    #   Menu: Insert->Design Feature->Extrude...
    # ----------------------------------------------
    markId64 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder4 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section4 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder4.Section = section4
    
    extrudeBuilder4.AllowSelfIntersectingSection(True)
    
    expression22 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit1)
    
    extrudeBuilder4.DistanceTolerance = 0.01
    
    extrudeBuilder4.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies13 = [NXOpen.Body.Null] * 1 
    targetBodies13[0] = NXOpen.Body.Null
    extrudeBuilder4.BooleanOperation.SetTargetBodies(targetBodies13)
    
    extrudeBuilder4.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder4.Limits.EndExtend.Value.SetFormula("140")
    
    extrudeBuilder4.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies14 = [NXOpen.Body.Null] * 1 
    targetBodies14[0] = NXOpen.Body.Null
    extrudeBuilder4.BooleanOperation.SetTargetBodies(targetBodies14)
    
    extrudeBuilder4.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder4.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder4.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder4.Offset.EndOffset.SetFormula("5")
    
    smartVolumeProfileBuilder4 = extrudeBuilder4.SmartVolumeProfile
    
    smartVolumeProfileBuilder4.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder4.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId64, "Extrude Dialog")
    
    section4.DistanceTolerance = 0.01
    
    section4.ChainingTolerance = 0.0094999999999999998
    
    section4.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    markId65 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    curves3 = [NXOpen.ICurve.Null] * 2 
    curves3[0] = arc4
    curves3[1] = arc5
    seedPoint3 = NXOpen.Point3d(21.64653069144979, 0.0, 10.424419766240396)
    regionBoundaryRule3 = workPart.ScRuleFactory.CreateRuleRegionBoundary(theSession.ActiveSketch, curves3, seedPoint3, 0.01)
    
    curves4 = [NXOpen.ICurve.Null] * 2 
    curves4[0] = arc4
    curves4[1] = arc5
    seedPoint4 = NXOpen.Point3d(161.64653069144973, 0.0, 10.424419766240396)
    regionBoundaryRule4 = workPart.ScRuleFactory.CreateRuleRegionBoundary(theSession.ActiveSketch, curves4, seedPoint4, 0.01)
    
    section4.AllowSelfIntersection(True)
    
    rules4 = [None] * 2 
    rules4[0] = regionBoundaryRule3
    rules4[1] = regionBoundaryRule4
    helpPoint4 = NXOpen.Point3d(0.0, 0.0, 0.0)
    section4.AddToSection(rules4, NXOpen.NXObject.Null, NXOpen.NXObject.Null, NXOpen.NXObject.Null, helpPoint4, NXOpen.Section.Mode.Create, False)
    
    theSession.DeleteUndoMark(markId65, None)
    
    markId66 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId67 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    theSession.DeleteUndoMark(markId67, None)
    
    direction10 = workPart.Directions.CreateDirection(theSession.ActiveSketch, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrudeBuilder4.Direction = direction10
    
    targetBodies15 = [NXOpen.Body.Null] * 1 
    targetBodies15[0] = body1
    extrudeBuilder4.BooleanOperation.SetTargetBodies(targetBodies15)
    
    extrudeBuilder4.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies16 = [NXOpen.Body.Null] * 1 
    targetBodies16[0] = body1
    extrudeBuilder4.BooleanOperation.SetTargetBodies(targetBodies16)
    
    expression23 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit2)
    
    expression24 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit2)
    
    theSession.DeleteUndoMark(markId66, None)
    
    extrudeBuilder4.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies17 = [NXOpen.Body.Null] * 1 
    targetBodies17[0] = body1
    extrudeBuilder4.BooleanOperation.SetTargetBodies(targetBodies17)
    
    rotMatrix34 = NXOpen.Matrix3x3()
    
    rotMatrix34.Xx = -0.36884984722474384
    rotMatrix34.Xy = 0.92550757095036518
    rotMatrix34.Xz = -0.085939084913906907
    rotMatrix34.Yx = -0.0019278874697482313
    rotMatrix34.Yy = 0.091696454250693102
    rotMatrix34.Yz = 0.99578513923825773
    rotMatrix34.Zx = 0.92948699477302565
    rotMatrix34.Zy = 0.36746087736166921
    rotMatrix34.Zz = -0.032037948692226641
    translation34 = NXOpen.Point3d(-70.383392118680163, -35.77751809675123, -139.86001846670101)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix34, translation34, 0.57403509963166399)
    
    extrudeBuilder4.Limits.SymmetricOption = True
    
    extrudeBuilder4.Limits.StartExtend.Value.SetFormula("140")
    
    extrudeBuilder4.Limits.StartExtend.TrimType = NXOpen.GeometricUtilities.Extend.ExtendType.Symmetric
    
    extrudeBuilder4.Limits.EndExtend.TrimType = NXOpen.GeometricUtilities.Extend.ExtendType.Symmetric
    
    extrudeBuilder4.Limits.StartExtend.Target = NXOpen.DisplayableObject.Null
    
    extrudeBuilder4.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies18 = [NXOpen.Body.Null] * 1 
    targetBodies18[0] = body1
    extrudeBuilder4.BooleanOperation.SetTargetBodies(targetBodies18)
    
    extrudeBuilder4.Limits.EndExtend.Value.SetFormula("20")
    
    extrudeBuilder4.Limits.StartExtend.Value.SetFormula("20")
    
    extrudeBuilder4.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies19 = [NXOpen.Body.Null] * 1 
    targetBodies19[0] = body1
    extrudeBuilder4.BooleanOperation.SetTargetBodies(targetBodies19)
    
    rotMatrix35 = NXOpen.Matrix3x3()
    
    rotMatrix35.Xx = -0.55213709664839139
    rotMatrix35.Xy = 0.83037367699359443
    rotMatrix35.Xz = -0.074994553541078757
    rotMatrix35.Yx = -0.1019047293691365
    rotMatrix35.Yy = 0.022062853016388922
    rotMatrix35.Yz = 0.99454947420879147
    rotMatrix35.Zx = 0.82750229766260697
    rotMatrix35.Zy = 0.55676995884558855
    rotMatrix35.Zz = 0.07243728522103747
    translation35 = NXOpen.Point3d(-58.505523340466979, -30.180171139094988, -121.21316421384421)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix35, translation35, 0.57403509963166399)
    
    extrudeBuilder4.Limits.EndExtend.Value.SetFormula("20")
    
    extrudeBuilder4.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies20 = [NXOpen.Body.Null] * 1 
    targetBodies20[0] = body1
    extrudeBuilder4.BooleanOperation.SetTargetBodies(targetBodies20)
    
    extrudeBuilder4.Limits.EndExtend.Value.SetFormula("20")
    
    extrudeBuilder4.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies21 = [NXOpen.Body.Null] * 1 
    targetBodies21[0] = body1
    extrudeBuilder4.BooleanOperation.SetTargetBodies(targetBodies21)
    
    markId68 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    theSession.DeleteUndoMark(markId68, None)
    
    markId69 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    extrudeBuilder4.ParentFeatureInternal = False
    
    markId70 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    feature9 = extrudeBuilder4.CommitFeature()
    
    theSession.DeleteUndoMark(markId69, None)
    
    theSession.SetUndoMarkName(markId64, "Extrude")
    
    expression25 = extrudeBuilder4.Limits.EndExtend.Value
    extrudeBuilder4.Destroy()
    
    workPart.Expressions.Delete(expression22)
    
    workPart.Expressions.Delete(expression23)
    
    workPart.Expressions.Delete(expression24)
    
    rotMatrix36 = NXOpen.Matrix3x3()
    
    rotMatrix36.Xx = -0.99256080469794394
    rotMatrix36.Xy = -0.087474590940813335
    rotMatrix36.Xz = 0.084683203276177885
    rotMatrix36.Yx = 0.081244114639513768
    rotMatrix36.Yy = 0.042160698454435153
    rotMatrix36.Yz = 0.9958021235879545
    rotMatrix36.Zx = -0.090677686416330908
    rotMatrix36.Zy = 0.99527416898338927
    rotMatrix36.Zz = -0.034740261090121238
    translation36 = NXOpen.Point3d(-75.701950194391316, -48.106989581079446, 6.0598689250577529)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix36, translation36, 0.57403509963166399)
    
    rotMatrix37 = NXOpen.Matrix3x3()
    
    rotMatrix37.Xx = 0.4533905299371645
    rotMatrix37.Xy = -0.89131165741022389
    rotMatrix37.Xz = 0.00074614203837313929
    rotMatrix37.Yx = 0.081244114639513768
    rotMatrix37.Yy = 0.042160698454435153
    rotMatrix37.Yz = 0.9958021235879545
    rotMatrix37.Zx = -0.88760149909728447
    rotMatrix37.Zy = -0.45142663287679302
    rotMatrix37.Zz = 0.091529087888948382
    translation37 = NXOpen.Point3d(-270.2925036417347, -48.106989581079446, -4.0773326029181476)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix37, translation37, 0.57403509963166399)
    
    rotMatrix38 = NXOpen.Matrix3x3()
    
    rotMatrix38.Xx = 0.99613986011887912
    rotMatrix38.Xy = 0.029883759417386316
    rotMatrix38.Xz = -0.082536900871259436
    rotMatrix38.Yx = 0.081244114639513768
    rotMatrix38.Yy = 0.042160698454435153
    rotMatrix38.Yz = 0.9958021235879545
    rotMatrix38.Zx = 0.033238124477620555
    rotMatrix38.Zy = -0.99866382553335886
    rotMatrix38.Zz = 0.039570072684949227
    translation38 = NXOpen.Point3d(-267.36946202263982, -48.106989581079446, -130.19444698091689)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix38, translation38, 0.57403509963166399)
    
    rotMatrix39 = NXOpen.Matrix3x3()
    
    rotMatrix39.Xx = 0.9965528524747721
    rotMatrix39.Xy = 0.00098380913677549066
    rotMatrix39.Xz = -0.082954471512913588
    rotMatrix39.Yx = 0.0829342287041753
    rotMatrix39.Yy = 0.013254917582095653
    rotMatrix39.Yz = 0.99646686892698022
    rotMatrix39.Zx = 0.0020798878931133739
    rotMatrix39.Zy = -0.99991166573826995
    rotMatrix39.Zz = 0.013127634473804722
    translation39 = NXOpen.Point3d(-269.12558262234506, -50.050553904973832, -125.70289797407182)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix39, translation39, 0.57403509963166399)
    
    origin1 = NXOpen.Point3d(221.85523331068273, -124.92300643568942, 25.099152996714079)
    workPart.ModelingViews.WorkView.SetOrigin(origin1)
    
    origin2 = NXOpen.Point3d(221.85523331068273, -124.92300643568942, 25.099152996714079)
    workPart.ModelingViews.WorkView.SetOrigin(origin2)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Curve->Circle...
    # ----------------------------------------------
    markId71 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId72 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    rotMatrix40 = NXOpen.Matrix3x3()
    
    rotMatrix40.Xx = 0.9819927867772823
    rotMatrix40.Xy = -0.17139989262057884
    rotMatrix40.Xz = -0.079449628866660363
    rotMatrix40.Yx = 0.0829342287041753
    rotMatrix40.Yy = 0.013254917582095653
    rotMatrix40.Yz = 0.99646686892698022
    rotMatrix40.Zx = -0.16974121605149387
    rotMatrix40.Zy = -0.98511237123972495
    rotMatrix40.Zz = 0.027231151349411339
    translation40 = NXOpen.Point3d(-227.88770079767204, -41.754022903548311, -107.62954079597719)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix40, translation40, 0.57403509963166399)
    
    scalar6 = workPart.Scalars.CreateScalar(0.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    edge3 = extrude1.FindObject("EDGE * 130 * 150 {(-0,-140,-0)(70,-140,0)(140,-140,0) EXTRUDE(2)}")
    point14 = workPart.Points.CreatePoint(edge3, scalar6, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    direction11 = workPart.Directions.CreateDirection(edge3, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    face1 = extrude1.FindObject("FACE 130 {(124.868010523063,-140,70) EXTRUDE(2)}")
    xform7 = workPart.Xforms.CreateXformByPlaneXDirPoint(face1, direction11, point14, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem8 = workPart.CoordinateSystems.CreateCoordinateSystem(xform7, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    datumCsysBuilder6 = workPart.Features.CreateDatumCsysBuilder(NXOpen.Features.Feature.Null)
    
    datumCsysBuilder6.Csys = cartesianCoordinateSystem8
    
    datumCsysBuilder6.DisplayScaleFactor = 1.25
    
    feature10 = datumCsysBuilder6.CommitFeature()
    
    datumCsysBuilder6.Destroy()
    
    sketchInPlaceBuilder6 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    sketchInPlaceBuilder6.Csystem = cartesianCoordinateSystem8
    
    sketchInPlaceBuilder6.PlaneOption = NXOpen.Sketch.PlaneOption.Inferred
    
    theSession.Preferences.Sketch.CreateInferredConstraints = True
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = True
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = True
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    nXObject12 = sketchInPlaceBuilder6.Commit()
    
    sketchInPlaceBuilder6.Destroy()
    
    sketch32 = nXObject12
    sketch32.Activate(NXOpen.Sketch.ViewReorient.FalseValue)
    
    expression26 = workPart.Expressions.CreateSystemExpression("80")
    
    theSession.SetUndoMarkVisibility(markId72, "Curve", NXOpen.Session.MarkVisibility.Visible)
    
    nXMatrix6 = theSession.ActiveSketch.Orientation
    
    center6 = NXOpen.Point3d(0.0, -140.0, 0.0)
    arc6 = workPart.Curves.CreateArc(center6, nXMatrix6, 40.0, 0.0, ( 360.0 * math.pi/180.0 ))
    
    theSession.ActiveSketch.AddGeometry(arc6, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    geom1_16 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_16.Geometry = arc6
    geom1_16.PointType = NXOpen.Sketch.ConstraintPointType.ArcCenter
    geom1_16.SplineDefiningPointIndex = 0
    geom2_16 = NXOpen.Sketch.ConstraintGeometry()
    
    datumCsys10 = feature10
    point15 = datumCsys10.FindObject("POINT 1")
    geom2_16.Geometry = point15
    geom2_16.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    geom2_16.SplineDefiningPointIndex = 0
    sketchGeometricConstraint12 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_16, geom2_16)
    
    dimObject1_8 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_8.Geometry = arc6
    dimObject1_8.AssocType = NXOpen.Sketch.AssocType.NotSet
    dimObject1_8.AssocValue = 0
    dimObject1_8.HelpPoint.X = 0.0
    dimObject1_8.HelpPoint.Y = 0.0
    dimObject1_8.HelpPoint.Z = 0.0
    dimObject1_8.View = NXOpen.NXObject.Null
    dimOrigin8 = NXOpen.Point3d(0.0, -140.0, 5.2261612607399499)
    sketchDimensionalConstraint6 = theSession.ActiveSketch.CreateDiameterDimension(dimObject1_8, dimOrigin8, expression26, NXOpen.Sketch.DimensionOption.CreateAsDriving)
    
    dimension6 = sketchDimensionalConstraint6.AssociatedDimension
    
    theSession.ActiveSketch.Update()
    
    markId73 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    rotMatrix41 = NXOpen.Matrix3x3()
    
    rotMatrix41.Xx = 0.98694391317317764
    rotMatrix41.Xy = 0.12735546704941961
    rotMatrix41.Xz = -0.098601710243993945
    rotMatrix41.Yx = 0.092723669228888889
    rotMatrix41.Yy = 0.051301006958227313
    rotMatrix41.Yz = 0.99436941216521946
    rotMatrix41.Zx = 0.13169674792927855
    rotMatrix41.Zy = -0.99052955114812069
    rotMatrix41.Zz = 0.038822350355896193
    translation41 = NXOpen.Point3d(-209.69088234645073, -40.40437445651439, -139.8176002742897)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix41, translation41, 0.57403509963166399)
    
    rotMatrix42 = NXOpen.Matrix3x3()
    
    rotMatrix42.Xx = 0.99499650000852669
    rotMatrix42.Xy = 0.023834953912213842
    rotMatrix42.Xz = -0.097025048017435944
    rotMatrix42.Yx = 0.095869203696594407
    rotMatrix42.Yy = 0.045612507490083574
    rotMatrix42.Yz = 0.99434832676635454
    rotMatrix42.Zx = 0.028125802270584015
    rotMatrix42.Zy = -0.99867481901391264
    rotMatrix42.Zz = 0.043099247257536867
    translation42 = NXOpen.Point3d(-216.80536524359405, -41.072341291146358, -129.69792299523178)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix42, translation42, 0.57403509963166399)
    
    # ----------------------------------------------
    #   Menu: Insert->Design Feature->Extrude...
    # ----------------------------------------------
    theSession.DeleteUndoMark(markId73, "Curve")
    
    markId74 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder5 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section5 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder5.Section = section5
    
    extrudeBuilder5.AllowSelfIntersectingSection(True)
    
    expression27 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit1)
    
    extrudeBuilder5.DistanceTolerance = 0.01
    
    extrudeBuilder5.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies22 = [NXOpen.Body.Null] * 1 
    targetBodies22[0] = NXOpen.Body.Null
    extrudeBuilder5.BooleanOperation.SetTargetBodies(targetBodies22)
    
    extrudeBuilder5.Limits.StartExtend.Value.SetFormula("20")
    
    extrudeBuilder5.Limits.EndExtend.Value.SetFormula("20")
    
    extrudeBuilder5.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies23 = [NXOpen.Body.Null] * 1 
    targetBodies23[0] = NXOpen.Body.Null
    extrudeBuilder5.BooleanOperation.SetTargetBodies(targetBodies23)
    
    extrudeBuilder5.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder5.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder5.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder5.Offset.EndOffset.SetFormula("5")
    
    extrudeBuilder5.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder5.Limits.EndExtend.Value.SetFormula("20")
    
    smartVolumeProfileBuilder5 = extrudeBuilder5.SmartVolumeProfile
    
    smartVolumeProfileBuilder5.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder5.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId74, "Extrude Dialog")
    
    section5.DistanceTolerance = 0.01
    
    section5.ChainingTolerance = 0.0094999999999999998
    
    section5.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    markId75 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    curves5 = [NXOpen.ICurve.Null] * 1 
    curves5[0] = arc6
    seedPoint5 = NXOpen.Point3d(21.646530691449783, -140.0, 10.424419766240396)
    regionBoundaryRule5 = workPart.ScRuleFactory.CreateRuleRegionBoundary(theSession.ActiveSketch, curves5, seedPoint5, 0.01)
    
    section5.AllowSelfIntersection(True)
    
    rules5 = [None] * 1 
    rules5[0] = regionBoundaryRule5
    helpPoint5 = NXOpen.Point3d(0.0, 0.0, 0.0)
    section5.AddToSection(rules5, NXOpen.NXObject.Null, NXOpen.NXObject.Null, NXOpen.NXObject.Null, helpPoint5, NXOpen.Section.Mode.Create, False)
    
    theSession.DeleteUndoMark(markId75, None)
    
    markId76 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId77 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    theSession.DeleteUndoMark(markId77, None)
    
    direction12 = workPart.Directions.CreateDirection(theSession.ActiveSketch, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrudeBuilder5.Direction = direction12
    
    targetBodies24 = [NXOpen.Body.Null] * 1 
    targetBodies24[0] = body1
    extrudeBuilder5.BooleanOperation.SetTargetBodies(targetBodies24)
    
    extrudeBuilder5.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies25 = [NXOpen.Body.Null] * 1 
    targetBodies25[0] = body1
    extrudeBuilder5.BooleanOperation.SetTargetBodies(targetBodies25)
    
    expression28 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit2)
    
    theSession.DeleteUndoMark(markId76, None)
    
    extrudeBuilder5.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies26 = [NXOpen.Body.Null] * 1 
    targetBodies26[0] = body1
    extrudeBuilder5.BooleanOperation.SetTargetBodies(targetBodies26)
    
    rotMatrix43 = NXOpen.Matrix3x3()
    
    rotMatrix43.Xx = 0.20409784951437474
    rotMatrix43.Xy = -0.97880273256199879
    rotMatrix43.Xz = 0.017008190755461054
    rotMatrix43.Yx = 0.08958059140890251
    rotMatrix43.Yy = 0.035974524568474636
    rotMatrix43.Yz = 0.99532966961952085
    rotMatrix43.Zx = -0.97484326199981564
    rotMatrix43.Zy = -0.20162104134052775
    rotMatrix43.Zz = 0.095024050757281417
    translation43 = NXOpen.Point3d(-210.34071079742404, -41.141276357515501, 27.932020847934382)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix43, translation43, 0.57403509963166399)
    
    extrudeBuilder5.Limits.SymmetricOption = True
    
    extrudeBuilder5.Limits.StartExtend.Value.SetFormula("20")
    
    extrudeBuilder5.Limits.StartExtend.TrimType = NXOpen.GeometricUtilities.Extend.ExtendType.Symmetric
    
    extrudeBuilder5.Limits.EndExtend.TrimType = NXOpen.GeometricUtilities.Extend.ExtendType.Symmetric
    
    extrudeBuilder5.Limits.StartExtend.Target = NXOpen.DisplayableObject.Null
    
    extrudeBuilder5.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies27 = [NXOpen.Body.Null] * 1 
    targetBodies27[0] = body1
    extrudeBuilder5.BooleanOperation.SetTargetBodies(targetBodies27)
    
    markId78 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    theSession.DeleteUndoMark(markId78, None)
    
    markId79 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    extrudeBuilder5.ParentFeatureInternal = False
    
    markId80 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    feature11 = extrudeBuilder5.CommitFeature()
    
    theSession.DeleteUndoMark(markId79, None)
    
    theSession.SetUndoMarkName(markId74, "Extrude")
    
    expression29 = extrudeBuilder5.Limits.EndExtend.Value
    extrudeBuilder5.Destroy()
    
    workPart.Expressions.Delete(expression27)
    
    workPart.Expressions.Delete(expression28)
    
    rotMatrix44 = NXOpen.Matrix3x3()
    
    rotMatrix44.Xx = 0.99334648004416692
    rotMatrix44.Xy = 0.064302067096907611
    rotMatrix44.Xz = -0.095540644497154381
    rotMatrix44.Yx = 0.091814666149891477
    rotMatrix44.Yy = 0.058604789533127463
    rotMatrix44.Yz = 0.9940500720404194
    rotMatrix44.Zx = 0.069518613792643763
    rotMatrix44.Zy = -0.99620817242725224
    rotMatrix44.Zz = 0.052310988573210856
    translation44 = NXOpen.Point3d(-213.87508202094403, -39.725797100496379, -134.29579972727714)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix44, translation44, 0.57403509963166399)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Curve->Circle...
    # ----------------------------------------------
    markId81 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId82 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    rotMatrix45 = NXOpen.Matrix3x3()
    
    rotMatrix45.Xx = 0.99441850161632661
    rotMatrix45.Xy = 0.041289453257052113
    rotMatrix45.Xz = -0.097092866333614275
    rotMatrix45.Yx = 0.10014122408858714
    rotMatrix45.Yy = -0.079614647439577524
    rotMatrix45.Yz = 0.99178286088796364
    rotMatrix45.Zx = 0.03322015775373012
    rotMatrix45.Zy = -0.99597022493787946
    rotMatrix45.Zz = -0.083305054804686141
    translation45 = NXOpen.Point3d(-215.51997629047705, -50.154785578858963, -123.71882726281896)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix45, translation45, 0.57403509963166399)
    
    scalar7 = workPart.Scalars.CreateScalar(1.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    point16 = workPart.Points.CreatePoint(edge3, scalar7, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    direction13 = workPart.Directions.CreateDirection(edge3, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    xform8 = workPart.Xforms.CreateXformByPlaneXDirPoint(face1, direction13, point16, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem9 = workPart.CoordinateSystems.CreateCoordinateSystem(xform8, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    datumCsysBuilder7 = workPart.Features.CreateDatumCsysBuilder(NXOpen.Features.Feature.Null)
    
    datumCsysBuilder7.Csys = cartesianCoordinateSystem9
    
    datumCsysBuilder7.DisplayScaleFactor = 1.25
    
    feature12 = datumCsysBuilder7.CommitFeature()
    
    datumCsysBuilder7.Destroy()
    
    sketchInPlaceBuilder7 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    sketchInPlaceBuilder7.Csystem = cartesianCoordinateSystem9
    
    sketchInPlaceBuilder7.PlaneOption = NXOpen.Sketch.PlaneOption.Inferred
    
    theSession.Preferences.Sketch.CreateInferredConstraints = True
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = True
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = True
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    nXObject13 = sketchInPlaceBuilder7.Commit()
    
    sketchInPlaceBuilder7.Destroy()
    
    sketch33 = nXObject13
    sketch33.Activate(NXOpen.Sketch.ViewReorient.FalseValue)
    
    expression30 = workPart.Expressions.CreateSystemExpression("80")
    
    theSession.SetUndoMarkVisibility(markId82, "Curve", NXOpen.Session.MarkVisibility.Visible)
    
    nXMatrix7 = theSession.ActiveSketch.Orientation
    
    center7 = NXOpen.Point3d(138.57150336648874, -140.0, 3.9623280748713867)
    arc7 = workPart.Curves.CreateArc(center7, nXMatrix7, 40.0, 0.0, ( 360.0 * math.pi/180.0 ))
    
    theSession.ActiveSketch.AddGeometry(arc7, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    dimObject1_9 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_9.Geometry = arc7
    dimObject1_9.AssocType = NXOpen.Sketch.AssocType.NotSet
    dimObject1_9.AssocValue = 0
    dimObject1_9.HelpPoint.X = 0.0
    dimObject1_9.HelpPoint.Y = 0.0
    dimObject1_9.HelpPoint.Z = 0.0
    dimObject1_9.View = NXOpen.NXObject.Null
    dimOrigin9 = NXOpen.Point3d(138.57150336648874, -140.0, 9.1884893356113366)
    sketchDimensionalConstraint7 = theSession.ActiveSketch.CreateDiameterDimension(dimObject1_9, dimOrigin9, expression30, NXOpen.Sketch.DimensionOption.CreateAsDriving)
    
    dimension7 = sketchDimensionalConstraint7.AssociatedDimension
    
    theSession.ActiveSketch.Update()
    
    markId83 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    rotMatrix46 = NXOpen.Matrix3x3()
    
    rotMatrix46.Xx = 0.91755155519427245
    rotMatrix46.Xy = 0.38740901790548604
    rotMatrix46.Xz = -0.089517575961841192
    rotMatrix46.Yx = -0.02602215640159385
    rotMatrix46.Yy = 0.28316045121454886
    rotMatrix46.Yz = 0.95871946170096489
    rotMatrix46.Zx = 0.39676440230543453
    rotMatrix46.Zy = -0.87734509271636452
    rotMatrix46.Zz = 0.2698955304367448
    translation46 = NXOpen.Point3d(-183.61012551944296, -10.217887761007443, -168.28915081218042)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix46, translation46, 0.57403509963166399)
    
    # ----------------------------------------------
    #   Menu: Insert->Design Feature->Extrude...
    # ----------------------------------------------
    theSession.DeleteUndoMark(markId83, "Curve")
    
    markId84 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder6 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section6 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder6.Section = section6
    
    extrudeBuilder6.AllowSelfIntersectingSection(True)
    
    expression31 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit1)
    
    extrudeBuilder6.DistanceTolerance = 0.01
    
    extrudeBuilder6.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies28 = [NXOpen.Body.Null] * 1 
    targetBodies28[0] = NXOpen.Body.Null
    extrudeBuilder6.BooleanOperation.SetTargetBodies(targetBodies28)
    
    extrudeBuilder6.Limits.StartExtend.Value.SetFormula("20")
    
    extrudeBuilder6.Limits.EndExtend.Value.SetFormula("20")
    
    extrudeBuilder6.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies29 = [NXOpen.Body.Null] * 1 
    targetBodies29[0] = NXOpen.Body.Null
    extrudeBuilder6.BooleanOperation.SetTargetBodies(targetBodies29)
    
    extrudeBuilder6.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder6.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder6.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder6.Offset.EndOffset.SetFormula("5")
    
    extrudeBuilder6.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder6.Limits.EndExtend.Value.SetFormula("20")
    
    smartVolumeProfileBuilder6 = extrudeBuilder6.SmartVolumeProfile
    
    smartVolumeProfileBuilder6.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder6.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId84, "Extrude Dialog")
    
    section6.DistanceTolerance = 0.01
    
    section6.ChainingTolerance = 0.0094999999999999998
    
    section6.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    markId85 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    curves6 = [NXOpen.ICurve.Null] * 1 
    curves6[0] = arc7
    seedPoint6 = NXOpen.Point3d(160.2180340579385, -140.0, 14.386747841111768)
    regionBoundaryRule6 = workPart.ScRuleFactory.CreateRuleRegionBoundary(theSession.ActiveSketch, curves6, seedPoint6, 0.01)
    
    section6.AllowSelfIntersection(True)
    
    rules6 = [None] * 1 
    rules6[0] = regionBoundaryRule6
    helpPoint6 = NXOpen.Point3d(0.0, 0.0, 0.0)
    section6.AddToSection(rules6, NXOpen.NXObject.Null, NXOpen.NXObject.Null, NXOpen.NXObject.Null, helpPoint6, NXOpen.Section.Mode.Create, False)
    
    theSession.DeleteUndoMark(markId85, None)
    
    markId86 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId87 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    theSession.DeleteUndoMark(markId87, None)
    
    direction14 = workPart.Directions.CreateDirection(theSession.ActiveSketch, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrudeBuilder6.Direction = direction14
    
    targetBodies30 = [NXOpen.Body.Null] * 1 
    targetBodies30[0] = body1
    extrudeBuilder6.BooleanOperation.SetTargetBodies(targetBodies30)
    
    extrudeBuilder6.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies31 = [NXOpen.Body.Null] * 1 
    targetBodies31[0] = body1
    extrudeBuilder6.BooleanOperation.SetTargetBodies(targetBodies31)
    
    expression32 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit2)
    
    theSession.DeleteUndoMark(markId86, None)
    
    extrudeBuilder6.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies32 = [NXOpen.Body.Null] * 1 
    targetBodies32[0] = body1
    extrudeBuilder6.BooleanOperation.SetTargetBodies(targetBodies32)
    
    rotMatrix47 = NXOpen.Matrix3x3()
    
    rotMatrix47.Xx = 0.99913956288743566
    rotMatrix47.Xy = 0.011800585594762832
    rotMatrix47.Xz = -0.039760282352242722
    rotMatrix47.Yx = 0.039543684697942977
    rotMatrix47.Yy = 0.018053238369548041
    rotMatrix47.Yz = 0.99905474203613465
    rotMatrix47.Zx = 0.012507232852197526
    rotMatrix47.Zy = -0.99976738632744033
    rotMatrix47.Zz = 0.01757106605724271
    translation47 = NXOpen.Point3d(-220.88579068871047, -37.619086511357104, -124.2323747966266)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix47, translation47, 0.57403509963166399)
    
    extrudeBuilder6.Destroy()
    
    section6.Destroy()
    
    workPart.Expressions.Delete(expression31)
    
    workPart.Expressions.Delete(expression32)
    
    theSession.UndoToMark(markId84, None)
    
    theSession.DeleteUndoMark(markId84, None)
    
    # ----------------------------------------------
    #   Menu: Edit->Undo
    # ----------------------------------------------
    marksRecycled3, undoUnavailable3 = theSession.UndoLastNVisibleMarks(1)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Curve->Circle...
    # ----------------------------------------------
    markId88 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId89 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    scalar8 = workPart.Scalars.CreateScalar(1.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    point17 = workPart.Points.CreatePoint(edge3, scalar8, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    direction15 = workPart.Directions.CreateDirection(edge3, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    xform9 = workPart.Xforms.CreateXformByPlaneXDirPoint(face1, direction15, point17, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem10 = workPart.CoordinateSystems.CreateCoordinateSystem(xform9, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    datumCsysBuilder8 = workPart.Features.CreateDatumCsysBuilder(NXOpen.Features.Feature.Null)
    
    datumCsysBuilder8.Csys = cartesianCoordinateSystem10
    
    datumCsysBuilder8.DisplayScaleFactor = 1.25
    
    feature13 = datumCsysBuilder8.CommitFeature()
    
    datumCsysBuilder8.Destroy()
    
    sketchInPlaceBuilder8 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    sketchInPlaceBuilder8.Csystem = cartesianCoordinateSystem10
    
    sketchInPlaceBuilder8.PlaneOption = NXOpen.Sketch.PlaneOption.Inferred
    
    theSession.Preferences.Sketch.CreateInferredConstraints = True
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = True
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = True
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    nXObject14 = sketchInPlaceBuilder8.Commit()
    
    sketchInPlaceBuilder8.Destroy()
    
    sketch34 = nXObject14
    sketch34.Activate(NXOpen.Sketch.ViewReorient.FalseValue)
    
    expression33 = workPart.Expressions.CreateSystemExpression("80")
    
    theSession.SetUndoMarkVisibility(markId89, "Curve", NXOpen.Session.MarkVisibility.Visible)
    
    nXMatrix8 = theSession.ActiveSketch.Orientation
    
    center8 = NXOpen.Point3d(139.99999999999997, -140.0, 0.0)
    arc8 = workPart.Curves.CreateArc(center8, nXMatrix8, 40.0, 0.0, ( 360.0 * math.pi/180.0 ))
    
    theSession.ActiveSketch.AddGeometry(arc8, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    geom1_17 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_17.Geometry = arc8
    geom1_17.PointType = NXOpen.Sketch.ConstraintPointType.ArcCenter
    geom1_17.SplineDefiningPointIndex = 0
    geom2_17 = NXOpen.Sketch.ConstraintGeometry()
    
    datumCsys11 = feature13
    point18 = datumCsys11.FindObject("POINT 1")
    geom2_17.Geometry = point18
    geom2_17.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    geom2_17.SplineDefiningPointIndex = 0
    sketchGeometricConstraint13 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_17, geom2_17)
    
    dimObject1_10 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_10.Geometry = arc8
    dimObject1_10.AssocType = NXOpen.Sketch.AssocType.NotSet
    dimObject1_10.AssocValue = 0
    dimObject1_10.HelpPoint.X = 0.0
    dimObject1_10.HelpPoint.Y = 0.0
    dimObject1_10.HelpPoint.Z = 0.0
    dimObject1_10.View = NXOpen.NXObject.Null
    dimOrigin10 = NXOpen.Point3d(139.99999999999997, -140.0, 5.2261612607399499)
    sketchDimensionalConstraint8 = theSession.ActiveSketch.CreateDiameterDimension(dimObject1_10, dimOrigin10, expression33, NXOpen.Sketch.DimensionOption.CreateAsDriving)
    
    dimension8 = sketchDimensionalConstraint8.AssociatedDimension
    
    theSession.ActiveSketch.Update()
    
    markId90 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    rotMatrix48 = NXOpen.Matrix3x3()
    
    rotMatrix48.Xx = 0.97774446298647899
    rotMatrix48.Xy = -0.20615005686430563
    rotMatrix48.Xz = -0.038960481954554857
    rotMatrix48.Yx = 0.038755894558438843
    rotMatrix48.Yy = -0.0050320447190615354
    rotMatrix48.Yz = 0.99923603776231273
    rotMatrix48.Zx = -0.20618861689303392
    rotMatrix48.Zy = -0.97850745146922513
    rotMatrix48.Zz = 0.0030694760054866474
    translation48 = NXOpen.Point3d(-233.68658129437563, -39.15126545879955, -96.65149325388461)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix48, translation48, 0.57403509963166399)
    
    theSession.DeleteUndoMark(markId90, "Curve")
    
    # ----------------------------------------------
    #   Menu: Insert->Design Feature->Extrude...
    # ----------------------------------------------
    markId91 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder7 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section7 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder7.Section = section7
    
    extrudeBuilder7.AllowSelfIntersectingSection(True)
    
    expression34 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit1)
    
    extrudeBuilder7.DistanceTolerance = 0.01
    
    extrudeBuilder7.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies33 = [NXOpen.Body.Null] * 1 
    targetBodies33[0] = NXOpen.Body.Null
    extrudeBuilder7.BooleanOperation.SetTargetBodies(targetBodies33)
    
    extrudeBuilder7.Limits.StartExtend.Value.SetFormula("20")
    
    extrudeBuilder7.Limits.EndExtend.Value.SetFormula("20")
    
    extrudeBuilder7.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies34 = [NXOpen.Body.Null] * 1 
    targetBodies34[0] = NXOpen.Body.Null
    extrudeBuilder7.BooleanOperation.SetTargetBodies(targetBodies34)
    
    extrudeBuilder7.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder7.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder7.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder7.Offset.EndOffset.SetFormula("5")
    
    extrudeBuilder7.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder7.Limits.EndExtend.Value.SetFormula("20")
    
    smartVolumeProfileBuilder7 = extrudeBuilder7.SmartVolumeProfile
    
    smartVolumeProfileBuilder7.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder7.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId91, "Extrude Dialog")
    
    section7.DistanceTolerance = 0.01
    
    section7.ChainingTolerance = 0.0094999999999999998
    
    section7.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    markId92 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    curves7 = [NXOpen.ICurve.Null] * 1 
    curves7[0] = arc8
    seedPoint7 = NXOpen.Point3d(161.64653069144973, -140.0, 10.424419766240396)
    regionBoundaryRule7 = workPart.ScRuleFactory.CreateRuleRegionBoundary(theSession.ActiveSketch, curves7, seedPoint7, 0.01)
    
    section7.AllowSelfIntersection(True)
    
    rules7 = [None] * 1 
    rules7[0] = regionBoundaryRule7
    helpPoint7 = NXOpen.Point3d(0.0, 0.0, 0.0)
    section7.AddToSection(rules7, NXOpen.NXObject.Null, NXOpen.NXObject.Null, NXOpen.NXObject.Null, helpPoint7, NXOpen.Section.Mode.Create, False)
    
    theSession.DeleteUndoMark(markId92, None)
    
    markId93 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId94 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    theSession.DeleteUndoMark(markId94, None)
    
    direction16 = workPart.Directions.CreateDirection(theSession.ActiveSketch, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrudeBuilder7.Direction = direction16
    
    targetBodies35 = [NXOpen.Body.Null] * 1 
    targetBodies35[0] = body1
    extrudeBuilder7.BooleanOperation.SetTargetBodies(targetBodies35)
    
    extrudeBuilder7.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies36 = [NXOpen.Body.Null] * 1 
    targetBodies36[0] = body1
    extrudeBuilder7.BooleanOperation.SetTargetBodies(targetBodies36)
    
    expression35 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit2)
    
    theSession.DeleteUndoMark(markId93, None)
    
    extrudeBuilder7.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies37 = [NXOpen.Body.Null] * 1 
    targetBodies37[0] = body1
    extrudeBuilder7.BooleanOperation.SetTargetBodies(targetBodies37)
    
    extrudeBuilder7.Limits.SymmetricOption = True
    
    extrudeBuilder7.Limits.StartExtend.Value.SetFormula("20")
    
    extrudeBuilder7.Limits.StartExtend.TrimType = NXOpen.GeometricUtilities.Extend.ExtendType.Symmetric
    
    extrudeBuilder7.Limits.EndExtend.TrimType = NXOpen.GeometricUtilities.Extend.ExtendType.Symmetric
    
    extrudeBuilder7.Limits.StartExtend.Target = NXOpen.DisplayableObject.Null
    
    extrudeBuilder7.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies38 = [NXOpen.Body.Null] * 1 
    targetBodies38[0] = body1
    extrudeBuilder7.BooleanOperation.SetTargetBodies(targetBodies38)
    
    markId95 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    theSession.DeleteUndoMark(markId95, None)
    
    markId96 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    extrudeBuilder7.ParentFeatureInternal = False
    
    markId97 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    feature14 = extrudeBuilder7.CommitFeature()
    
    theSession.DeleteUndoMark(markId96, None)
    
    theSession.SetUndoMarkName(markId91, "Extrude")
    
    expression36 = extrudeBuilder7.Limits.EndExtend.Value
    extrudeBuilder7.Destroy()
    
    workPart.Expressions.Delete(expression34)
    
    workPart.Expressions.Delete(expression35)
    
    rotMatrix49 = NXOpen.Matrix3x3()
    
    rotMatrix49.Xx = 0.98784159666985238
    rotMatrix49.Xy = 0.028288235520748543
    rotMatrix49.Xz = 0.15286842584354721
    rotMatrix49.Yx = -0.15259297440952568
    rotMatrix49.Yy = -0.011665268450732007
    rotMatrix49.Yz = 0.98822027183863648
    rotMatrix49.Zx = 0.02973825902125523
    rotMatrix49.Zy = -0.99953173898736336
    rotMatrix49.Zz = -0.0072068514130451834
    translation49 = NXOpen.Point3d(-227.91869280313102, -19.140932704317201, -122.17485502209382)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix49, translation49, 0.57403509963166399)
    
    rotMatrix50 = NXOpen.Matrix3x3()
    
    rotMatrix50.Xx = -0.95152741712848288
    rotMatrix50.Xy = -0.28960385254108034
    rotMatrix50.Xz = -0.10356245963749086
    rotMatrix50.Yx = -0.12255600562890522
    rotMatrix50.Yy = 0.048185996555375497
    rotMatrix50.Yz = 0.99129114553709996
    rotMatrix50.Zx = -0.28209147441404558
    rotMatrix50.Zy = 0.95593290472152792
    rotMatrix50.Zz = -0.081342988226275489
    translation50 = NXOpen.Point3d(-35.416149499122369, -18.232435276102464, 50.883208686624293)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix50, translation50, 0.57403509963166399)
    
    rotMatrix51 = NXOpen.Matrix3x3()
    
    rotMatrix51.Xx = -0.86235777318319151
    rotMatrix51.Xy = 0.50573206951929506
    rotMatrix51.Xz = -0.023961320712007877
    rotMatrix51.Yx = -0.17193846075675612
    rotMatrix51.Yy = -0.24801336181589873
    rotMatrix51.Yz = 0.95337638846018036
    rotMatrix51.Zx = 0.47621028626346301
    rotMatrix51.Zy = 0.82627141195887621
    rotMatrix51.Zz = 0.30083104400371052
    translation51 = NXOpen.Point3d(6.9926731064647925, -31.92878975537608, -56.258657067470295)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix51, translation51, 0.57403509963166399)
    
    rotMatrix52 = NXOpen.Matrix3x3()
    
    rotMatrix52.Xx = -0.9971330718635586
    rotMatrix52.Xy = 0.067309504231618286
    rotMatrix52.Xz = -0.03456975030340536
    rotMatrix52.Yx = -0.038704639260175984
    rotMatrix52.Yy = -0.061128455573854421
    rotMatrix52.Yz = 0.99737919710554235
    rotMatrix52.Zx = 0.065019903842482643
    rotMatrix52.Zy = 0.99585779233746596
    rotMatrix52.Zz = 0.063558394764698531
    translation52 = NXOpen.Point3d(-9.1332400492915014, -34.919728039122234, 10.290509600320707)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix52, translation52, 0.57403509963166399)
    
    rotMatrix53 = NXOpen.Matrix3x3()
    
    rotMatrix53.Xx = -0.97927573116747946
    rotMatrix53.Xy = -0.16742831312521678
    rotMatrix53.Xz = -0.1139596521162231
    rotMatrix53.Yx = -0.10981435342806976
    rotMatrix53.Yy = -0.033842718308263853
    rotMatrix53.Yz = 0.99337579908043094
    rotMatrix53.Zx = -0.17017593874452838
    rotMatrix53.Zy = 0.9853032174825983
    rotMatrix53.Zz = 0.014755320764621278
    translation53 = NXOpen.Point3d(-23.454756896439029, -25.405380497515338, 36.481203492178579)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix53, translation53, 0.57403509963166399)
    
    rotMatrix54 = NXOpen.Matrix3x3()
    
    rotMatrix54.Xx = -0.93088811720471887
    rotMatrix54.Xy = 0.3546441644491215
    rotMatrix54.Xz = -0.087606106346800355
    rotMatrix54.Yx = -0.1424855125226302
    rotMatrix54.Yy = -0.13167142304479576
    rotMatrix54.Yz = 0.98099975284121488
    rotMatrix54.Zx = 0.33637061698106924
    rotMatrix54.Zy = 0.925683613863588
    rotMatrix54.Zz = 0.17310301862252719
    translation54 = NXOpen.Point3d(6.7343626085567578, -28.232759568167744, -28.352837898149097)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix54, translation54, 0.57403509963166399)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Curve->Circle...
    # ----------------------------------------------
    markId98 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId99 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    scalar9 = workPart.Scalars.CreateScalar(0.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    point19 = workPart.Points.CreatePoint(line29, scalar9, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    direction17 = workPart.Directions.CreateDirection(datumAxis2, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    xform10 = workPart.Xforms.CreateXformByPlaneXDirPoint(datumPlane2, direction17, point19, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem11 = workPart.CoordinateSystems.CreateCoordinateSystem(xform10, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    datumCsysBuilder9 = workPart.Features.CreateDatumCsysBuilder(NXOpen.Features.Feature.Null)
    
    datumCsysBuilder9.Csys = cartesianCoordinateSystem11
    
    datumCsysBuilder9.DisplayScaleFactor = 1.25
    
    feature15 = datumCsysBuilder9.CommitFeature()
    
    datumCsysBuilder9.Destroy()
    
    sketchInPlaceBuilder9 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    sketchInPlaceBuilder9.Csystem = cartesianCoordinateSystem11
    
    sketchInPlaceBuilder9.PlaneOption = NXOpen.Sketch.PlaneOption.Inferred
    
    theSession.Preferences.Sketch.CreateInferredConstraints = True
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = True
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = True
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    nXObject15 = sketchInPlaceBuilder9.Commit()
    
    sketchInPlaceBuilder9.Destroy()
    
    sketch35 = nXObject15
    sketch35.Activate(NXOpen.Sketch.ViewReorient.FalseValue)
    
    markId100 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    theSession.ActiveSketch.Deactivate(NXOpen.Sketch.ViewReorient.FalseValue, NXOpen.Sketch.UpdateLevel.Model)
    
    markId101 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "")
    
    nErrs7 = theSession.UpdateManager.AddToDeleteList(sketch35)
    
    datumCsys12 = feature15
    nErrs8 = theSession.UpdateManager.AddToDeleteList(datumCsys12)
    
    nErrs9 = theSession.UpdateManager.AddToDeleteList(point19)
    
    nErrs10 = theSession.UpdateManager.DoUpdate(markId101)
    
    theSession.DeleteUndoMark(markId101, "")
    
    rotMatrix55 = NXOpen.Matrix3x3()
    
    rotMatrix55.Xx = -0.44868767210629995
    rotMatrix55.Xy = -0.35766437745873086
    rotMatrix55.Xz = 0.81899668253106417
    rotMatrix55.Yx = 0.88747821622718759
    rotMatrix55.Yy = -0.070471507217005333
    rotMatrix55.Yz = 0.45542966788822181
    rotMatrix55.Zx = -0.10517503801778549
    rotMatrix55.Zy = 0.93118739240156456
    rotMatrix55.Zz = 0.34903904023810256
    translation55 = NXOpen.Point3d(-138.66566234084922, -104.91345355597156, 9.2108033678684365)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix55, translation55, 0.57403509963166399)
    
    rotMatrix56 = NXOpen.Matrix3x3()
    
    rotMatrix56.Xx = -0.72403770995361472
    rotMatrix56.Xy = -0.65934638076124252
    rotMatrix56.Xz = 0.20256294019927884
    rotMatrix56.Yx = 0.37774091063015947
    rotMatrix56.Yy = -0.13331001488361166
    rotMatrix56.Yz = 0.91626428740185506
    rotMatrix56.Zx = -0.57713187314635805
    rotMatrix56.Zy = 0.73992620585351765
    rotMatrix56.Zz = 0.34558358017966423
    translation56 = NXOpen.Point3d(-100.29136887297426, -79.278364510984346, 45.136982708529715)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix56, translation56, 0.57403509963166399)
    
    rotMatrix57 = NXOpen.Matrix3x3()
    
    rotMatrix57.Xx = 0.91664891496115397
    rotMatrix57.Xy = -0.31860837007453308
    rotMatrix57.Xz = -0.24133684596221314
    rotMatrix57.Yx = 0.23723253830402929
    rotMatrix57.Yy = -0.052255374783246225
    rotMatrix57.Yz = 0.97004644145323782
    rotMatrix57.Zx = -0.32167606294277967
    rotMatrix57.Zy = -0.9464449705739435
    rotMatrix57.Zz = 0.027684439761739822
    translation57 = NXOpen.Point3d(-225.07837672102585, -61.663456091422589, -83.612937148709079)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix57, translation57, 0.57403509963166399)
    
    rotMatrix58 = NXOpen.Matrix3x3()
    
    rotMatrix58.Xx = 0.74157723676335896
    rotMatrix58.Xy = -0.667100716448353
    rotMatrix58.Xz = -0.070991802544495775
    rotMatrix58.Yx = 0.1415914943938639
    rotMatrix58.Yy = 0.052199355325207246
    rotMatrix58.Yz = 0.98854796343877294
    rotMatrix58.Zx = -0.6557553283273696
    rotMatrix58.Zy = -0.74313650254696195
    rotMatrix58.Zz = 0.13316564103603554
    translation58 = NXOpen.Point3d(-239.76105736257901, -45.318242759112827, -39.869978599598596)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix58, translation58, 0.57403509963166399)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Curve->Arc...
    # ----------------------------------------------
    theSession.UndoToMark(markId99, "Curve")
    
    theSession.DeleteUndoMark(markId99, "Curve")
    
    markId102 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId103 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    rotMatrix59 = NXOpen.Matrix3x3()
    
    rotMatrix59.Xx = 0.97159137670374074
    rotMatrix59.Xy = -0.19862803055366784
    rotMatrix59.Xz = -0.12867440380007003
    rotMatrix59.Yx = 0.1415914943938639
    rotMatrix59.Yy = 0.052199355325207246
    rotMatrix59.Yz = 0.98854796343877294
    rotMatrix59.Zx = -0.18963661416046526
    rotMatrix59.Zy = -0.97868387785944877
    rotMatrix59.Zz = 0.078840483178069617
    translation59 = NXOpen.Point3d(-228.03366389048094, -45.318242759112827, -102.17584212425186)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix59, translation59, 0.57403509963166388)
    
    scalar10 = workPart.Scalars.CreateScalar(0.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    edge4 = extrude1.FindObject("EDGE * 130 * 140 {(-0,-140,140)(-0,-140,90)(-0,-140,40) EXTRUDE(2)}")
    point20 = workPart.Points.CreatePoint(edge4, scalar10, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    direction18 = workPart.Directions.CreateDirection(edge3, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    xform11 = workPart.Xforms.CreateXformByPlaneXDirPoint(face1, direction18, point20, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem12 = workPart.CoordinateSystems.CreateCoordinateSystem(xform11, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    datumCsysBuilder10 = workPart.Features.CreateDatumCsysBuilder(NXOpen.Features.Feature.Null)
    
    datumCsysBuilder10.Csys = cartesianCoordinateSystem12
    
    datumCsysBuilder10.DisplayScaleFactor = 1.25
    
    feature16 = datumCsysBuilder10.CommitFeature()
    
    datumCsysBuilder10.Destroy()
    
    sketchInPlaceBuilder10 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    sketchInPlaceBuilder10.Csystem = cartesianCoordinateSystem12
    
    sketchInPlaceBuilder10.PlaneOption = NXOpen.Sketch.PlaneOption.Inferred
    
    theSession.Preferences.Sketch.CreateInferredConstraints = True
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = True
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = True
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    nXObject16 = sketchInPlaceBuilder10.Commit()
    
    sketchInPlaceBuilder10.Destroy()
    
    sketch36 = nXObject16
    sketch36.Activate(NXOpen.Sketch.ViewReorient.FalseValue)
    
    rotMatrix60 = NXOpen.Matrix3x3()
    
    rotMatrix60.Xx = 0.97237601162152498
    rotMatrix60.Xy = 0.19123839041929794
    rotMatrix60.Xz = -0.13383859702214532
    rotMatrix60.Yx = 0.14607470138188403
    rotMatrix60.Yy = -0.051322576859946185
    rotMatrix60.Yz = 0.98794138222905137
    rotMatrix60.Zx = 0.18206337808360198
    rotMatrix60.Zy = -0.98020093406112185
    rotMatrix60.Zz = -0.077839933366464595
    translation60 = NXOpen.Point3d(-200.55667844756488, -52.945117155806173, -128.49626879848066)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix60, translation60, 0.57403509963166388)
    
    rotMatrix61 = NXOpen.Matrix3x3()
    
    rotMatrix61.Xx = 0.68058662974453421
    rotMatrix61.Xy = -0.72904109467120304
    rotMatrix61.Xz = -0.072807428835219581
    rotMatrix61.Yx = 0.15992810295989116
    rotMatrix61.Yy = 0.050847669197962797
    rotMatrix61.Yz = 0.98581819643420332
    rotMatrix61.Zx = -0.714999889018616
    rotMatrix61.Zy = -0.68257863782699502
    rotMatrix61.Zz = 0.15120040306037427
    translation61 = NXOpen.Point3d(-241.2994740182292, -46.956032139293889, -36.94244018726998)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix61, translation61, 0.57403509963166388)
    
    rotMatrix62 = NXOpen.Matrix3x3()
    
    rotMatrix62.Xx = 0.98711987034831694
    rotMatrix62.Xy = -0.0040222554896230545
    rotMatrix62.Xz = -0.15993180741899315
    rotMatrix62.Yx = 0.15992810295989116
    rotMatrix62.Yy = 0.050847669197962797
    rotMatrix62.Yz = 0.98581819643420332
    rotMatrix62.Zx = 0.004166946985493556
    rotMatrix62.Zy = -0.9986983208146083
    rotMatrix62.Zz = 0.050836016316282255
    translation62 = NXOpen.Point3d(-214.27082179339342, -46.956032139293889, -119.92931456025774)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix62, translation62, 0.57403509963166388)
    
    markId104 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    theSession.ActiveSketch.Deactivate(NXOpen.Sketch.ViewReorient.FalseValue, NXOpen.Sketch.UpdateLevel.Model)
    
    markId105 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "")
    
    nErrs11 = theSession.UpdateManager.AddToDeleteList(sketch36)
    
    datumCsys13 = feature16
    nErrs12 = theSession.UpdateManager.AddToDeleteList(datumCsys13)
    
    nErrs13 = theSession.UpdateManager.AddToDeleteList(point20)
    
    nErrs14 = theSession.UpdateManager.DoUpdate(markId105)
    
    theSession.DeleteUndoMark(markId105, "")
    
    theSession.UndoToMark(markId103, "Curve")
    
    theSession.DeleteUndoMark(markId103, "Curve")
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Curve->Polygon...
    # ----------------------------------------------
    markId106 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchPolygonBuilder1 = workPart.Sketches.CreateSketchPolygonBuilder(NXOpen.SketchPolygon.Null)
    
    theSession.SetUndoMarkName(markId106, "Polygon Dialog")
    
    expression37 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit2)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Curve->Ellipse...
    # ----------------------------------------------
    sketchPolygonBuilder1.Destroy()
    
    workPart.Expressions.Delete(expression37)
    
    theSession.UndoToMark(markId106, None)
    
    theSession.DeleteUndoMark(markId106, None)
    
    markId107 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchEllipseBuilder1 = workPart.Sketches.CreateSketchEllipseBuilder(NXOpen.NXObject.Null)
    
    theSession.SetUndoMarkName(markId107, "Ellipse Dialog")
    
    expression38 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit2)
    
    scalar11 = workPart.Scalars.CreateScalar(0.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    point21 = workPart.Points.CreatePoint(edge4, scalar11, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    direction19 = workPart.Directions.CreateDirection(edge3, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    xform12 = workPart.Xforms.CreateXformByPlaneXDirPoint(face1, direction19, point21, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem13 = workPart.CoordinateSystems.CreateCoordinateSystem(xform12, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    datumCsysBuilder11 = workPart.Features.CreateDatumCsysBuilder(NXOpen.Features.Feature.Null)
    
    datumCsysBuilder11.Csys = cartesianCoordinateSystem13
    
    datumCsysBuilder11.DisplayScaleFactor = 1.25
    
    feature17 = datumCsysBuilder11.CommitFeature()
    
    datumCsysBuilder11.Destroy()
    
    sketchInPlaceBuilder11 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    sketchInPlaceBuilder11.Csystem = cartesianCoordinateSystem13
    
    sketchInPlaceBuilder11.PlaneOption = NXOpen.Sketch.PlaneOption.Inferred
    
    theSession.Preferences.Sketch.CreateInferredConstraints = True
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = True
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = True
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    nXObject17 = sketchInPlaceBuilder11.Commit()
    
    sketchInPlaceBuilder11.Destroy()
    
    sketch37 = nXObject17
    sketch37.Activate(NXOpen.Sketch.ViewReorient.FalseValue)
    
    scalar12 = workPart.Scalars.CreateScalar(0.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    point22 = workPart.Points.CreatePoint(edge4, scalar12, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    point22.RemoveViewDependency()
    
    sketchEllipseBuilder1.CenterPoint = point22
    
    coordinates1 = NXOpen.Point3d(49.999999999999979, -140.0, 140.0)
    point23 = workPart.Points.CreatePoint(coordinates1)
    
    sketchEllipseBuilder1.MajorPoint = point23
    
    coordinates2 = NXOpen.Point3d(-1.8369701987210301e-14, -140.0, 165.0)
    point24 = workPart.Points.CreatePoint(coordinates2)
    
    sketchEllipseBuilder1.MinorPoint = point24
    
    coordinates3 = NXOpen.Point3d(49.999999999999979, -140.0, 140.0)
    point25 = workPart.Points.CreatePoint(coordinates3)
    
    sketchEllipseBuilder1.MajorPoint = point25
    
    workPart.Points.DeletePoint(point23)
    
    coordinates4 = NXOpen.Point3d(-1.8369701987210301e-14, -140.0, 165.0)
    point26 = workPart.Points.CreatePoint(coordinates4)
    
    sketchEllipseBuilder1.MinorPoint = point26
    
    workPart.Points.DeletePoint(point24)
    
    rotMatrix63 = NXOpen.Matrix3x3()
    
    rotMatrix63.Xx = -0.98017479502555038
    rotMatrix63.Xy = -0.14070644961650938
    rotMatrix63.Xz = 0.13949575704280678
    rotMatrix63.Yx = 0.13734350078079005
    rotMatrix63.Yy = 0.02494111346538545
    rotMatrix63.Yz = 0.99020942413834079
    rotMatrix63.Zx = -0.14280803195165656
    rotMatrix63.Zy = 0.98973715495349124
    rotMatrix63.Zz = -0.0051215344058757545
    translation63 = NXOpen.Point3d(-50.249160852205598, -46.844893004935024, 37.831906152234893)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix63, translation63, 0.57403509963166388)
    
    sketchEllipseBuilder1.Destroy()
    
    workPart.Expressions.Delete(expression38)
    
    theSession.UndoToMark(markId107, None)
    
    theSession.DeleteUndoMark(markId107, None)
    
    rotMatrix64 = NXOpen.Matrix3x3()
    
    rotMatrix64.Xx = -0.83167374296536667
    rotMatrix64.Xy = 0.55086793523754451
    rotMatrix64.Xz = 0.069737387311981286
    rotMatrix64.Yx = -0.047131599560912778
    rotMatrix64.Yy = -0.19517441794922927
    rotMatrix64.Yz = 0.97963542142013782
    rotMatrix64.Zx = 0.55326069586118876
    rotMatrix64.Zy = 0.81145022306072823
    rotMatrix64.Zz = 0.18828472564148518
    translation64 = NXOpen.Point3d(-13.813450698133089, -42.516129221292637, -56.795444792084822)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix64, translation64, 0.57403509963166388)
    
    rotMatrix65 = NXOpen.Matrix3x3()
    
    rotMatrix65.Xx = -0.97345579501649182
    rotMatrix65.Xy = 0.21808917115200321
    rotMatrix65.Xz = -0.069432907004132127
    rotMatrix65.Yx = -0.08464046847424167
    rotMatrix65.Yy = -0.061169910111070841
    rotMatrix65.Yz = 0.99453216800336186
    rotMatrix65.Zx = 0.2126494915236648
    rotMatrix65.Zy = 0.97400993604954644
    rotMatrix65.Zz = 0.078005373093725239
    translation65 = NXOpen.Point3d(-15.386638454167461, -29.975104882854744, -4.4367445554595335)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix65, translation65, 0.57403509963166388)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Curve->Studio Spline...
    # ----------------------------------------------
    markId108 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchSplineBuilder1 = workPart.Features.CreateSketchSplineBuilder(NXOpen.Spline.Null)
    
    origin3 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal1 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane1 = workPart.Planes.CreatePlane(origin3, normal1, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchSplineBuilder1.DrawingPlane = plane1
    
    expression39 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit2)
    
    expression40 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit2)
    
    origin4 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal2 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane2 = workPart.Planes.CreatePlane(origin4, normal2, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchSplineBuilder1.MovementPlane = plane2
    
    expression41 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit2)
    
    expression42 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit2)
    
    sketchSplineBuilder1.OrientExpress.ReferenceOption = NXOpen.GeometricUtilities.OrientXpressBuilder.Reference.WcsDisplayPart
    
    sketchSplineBuilder1.Degree = 5
    
    sketchSplineBuilder1.IsAssociative = True
    
    sketchSplineBuilder1.Degree = 3
    
    theSession.SetUndoMarkName(markId108, "Studio Spline Dialog")
    
    sketchSplineBuilder1.MatchKnotsType = NXOpen.Features.StudioSplineBuilderEx.MatchKnotsTypes.NotSet
    
    sketchSplineBuilder1.OrientExpress.AxisOption = NXOpen.GeometricUtilities.OrientXpressBuilder.Axis.Passive
    
    sketchSplineBuilder1.OrientExpress.PlaneOption = NXOpen.GeometricUtilities.OrientXpressBuilder.Plane.Passive
    
    sketchSplineBuilder1.IsAssociative = False
    
    markId109 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Studio Spline")
    
    expression43 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit2)
    
    theSession.DeleteUndoMark(markId109, None)
    
    markId110 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Studio Spline")
    
    scalar13 = workPart.Scalars.CreateScalar(0.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    point27 = workPart.Points.CreatePoint(arc1, scalar13, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    direction20 = workPart.Directions.CreateDirection(datumAxis3, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    xform13 = workPart.Xforms.CreateXformByPlaneXDirPoint(datumPlane3, direction20, point27, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem14 = workPart.CoordinateSystems.CreateCoordinateSystem(xform13, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    datumCsysBuilder12 = workPart.Features.CreateDatumCsysBuilder(NXOpen.Features.Feature.Null)
    
    datumCsysBuilder12.Csys = cartesianCoordinateSystem14
    
    datumCsysBuilder12.DisplayScaleFactor = 1.25
    
    feature18 = datumCsysBuilder12.CommitFeature()
    
    datumCsysBuilder12.Destroy()
    
    sketchInPlaceBuilder12 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    sketchInPlaceBuilder12.Csystem = cartesianCoordinateSystem14
    
    sketchInPlaceBuilder12.PlaneOption = NXOpen.Sketch.PlaneOption.Inferred
    
    theSession.Preferences.Sketch.CreateInferredConstraints = True
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = True
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = True
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    nXObject18 = sketchInPlaceBuilder12.Commit()
    
    sketchInPlaceBuilder12.Destroy()
    
    sketch38 = nXObject18
    sketch38.Activate(NXOpen.Sketch.ViewReorient.FalseValue)
    
    scalar14 = workPart.Scalars.CreateScalar(0.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    point28 = workPart.Points.CreatePoint(arc1, scalar14, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    point28.RemoveViewDependency()
    
    geometricConstraintData1 = sketchSplineBuilder1.ConstraintManager.CreateGeometricConstraintData()
    
    geometricConstraintData1.Point = point28
    
    sketchSplineBuilder1.ConstraintManager.Append(geometricConstraintData1)
    
    theSession.SetUndoMarkName(markId110, "Studio Spline - Specify Point")
    
    theSession.SetUndoMarkVisibility(markId110, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId108, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId111 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Studio Spline")
    
    theSession.DeleteUndoMark(markId111, None)
    
    markId112 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Studio Spline")
    
    sketchSplineBuilder1.Destroy()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression40)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression42)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    workPart.Expressions.Delete(expression43)
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression39)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression41)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    theSession.UndoToMark(markId108, None)
    
    theSession.DeleteUndoMark(markId108, None)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Curve->Studio Spline...
    # ----------------------------------------------
    markId113 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchSplineBuilder2 = workPart.Features.CreateSketchSplineBuilder(NXOpen.Spline.Null)
    
    origin5 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal3 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane3 = workPart.Planes.CreatePlane(origin5, normal3, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchSplineBuilder2.DrawingPlane = plane3
    
    expression44 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit2)
    
    expression45 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit2)
    
    origin6 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal4 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane4 = workPart.Planes.CreatePlane(origin6, normal4, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchSplineBuilder2.MovementPlane = plane4
    
    expression46 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit2)
    
    expression47 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit2)
    
    sketchSplineBuilder2.OrientExpress.ReferenceOption = NXOpen.GeometricUtilities.OrientXpressBuilder.Reference.WcsDisplayPart
    
    sketchSplineBuilder2.Degree = 5
    
    sketchSplineBuilder2.IsAssociative = True
    
    sketchSplineBuilder2.Degree = 3
    
    theSession.SetUndoMarkName(markId113, "Studio Spline Dialog")
    
    sketchSplineBuilder2.MatchKnotsType = NXOpen.Features.StudioSplineBuilderEx.MatchKnotsTypes.NotSet
    
    sketchSplineBuilder2.OrientExpress.AxisOption = NXOpen.GeometricUtilities.OrientXpressBuilder.Axis.Passive
    
    sketchSplineBuilder2.OrientExpress.PlaneOption = NXOpen.GeometricUtilities.OrientXpressBuilder.Plane.Passive
    
    sketchSplineBuilder2.IsAssociative = False
    
    markId114 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Studio Spline")
    
    expression48 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit2)
    
    theSession.DeleteUndoMark(markId114, None)
    
    markId115 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Studio Spline")
    
    scalar15 = workPart.Scalars.CreateScalar(1.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    point29 = workPart.Points.CreatePoint(line31, scalar15, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    direction21 = workPart.Directions.CreateDirection(datumAxis2, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    xform14 = workPart.Xforms.CreateXformByPlaneXDirPoint(datumPlane2, direction21, point29, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem15 = workPart.CoordinateSystems.CreateCoordinateSystem(xform14, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    datumCsysBuilder13 = workPart.Features.CreateDatumCsysBuilder(NXOpen.Features.Feature.Null)
    
    datumCsysBuilder13.Csys = cartesianCoordinateSystem15
    
    datumCsysBuilder13.DisplayScaleFactor = 1.25
    
    feature19 = datumCsysBuilder13.CommitFeature()
    
    datumCsysBuilder13.Destroy()
    
    sketchInPlaceBuilder13 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    sketchInPlaceBuilder13.Csystem = cartesianCoordinateSystem15
    
    sketchInPlaceBuilder13.PlaneOption = NXOpen.Sketch.PlaneOption.Inferred
    
    theSession.Preferences.Sketch.CreateInferredConstraints = True
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = True
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = True
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    nXObject19 = sketchInPlaceBuilder13.Commit()
    
    sketchInPlaceBuilder13.Destroy()
    
    sketch39 = nXObject19
    sketch39.Activate(NXOpen.Sketch.ViewReorient.FalseValue)
    
    scalar16 = workPart.Scalars.CreateScalar(1.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    point30 = workPart.Points.CreatePoint(line31, scalar16, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    point30.RemoveViewDependency()
    
    geometricConstraintData2 = sketchSplineBuilder2.ConstraintManager.CreateGeometricConstraintData()
    
    geometricConstraintData2.Point = point30
    
    sketchSplineBuilder2.ConstraintManager.Append(geometricConstraintData2)
    
    theSession.SetUndoMarkName(markId115, "Studio Spline - Specify Point")
    
    theSession.SetUndoMarkVisibility(markId115, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId113, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId116 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Studio Spline")
    
    theSession.DeleteUndoMark(markId116, None)
    
    markId117 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Studio Spline")
    
    rotMatrix66 = NXOpen.Matrix3x3()
    
    rotMatrix66.Xx = -0.91056219467735033
    rotMatrix66.Xy = -0.39544023567303338
    rotMatrix66.Xz = -0.12043051787328751
    rotMatrix66.Yx = -0.065187651389810308
    rotMatrix66.Yy = -0.15032730540491412
    rotMatrix66.Yz = 0.98648480543593797
    rotMatrix66.Zx = -0.40819977918986167
    rotMatrix66.Zy = 0.90610635206942514
    rotMatrix66.Zz = 0.11110454090087321
    translation66 = NXOpen.Point3d(-62.332503774304918, -37.839245368057782, 53.799902976704317)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix66, translation66, 0.57403509963166388)
    
    sketchSplineBuilder2.Destroy()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression45)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression47)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    workPart.Expressions.Delete(expression48)
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression44)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression46)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    theSession.UndoToMark(markId113, None)
    
    theSession.DeleteUndoMark(markId113, None)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Curve->Arc...
    # ----------------------------------------------
    markId118 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId119 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    scalar17 = workPart.Scalars.CreateScalar(0.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    point31 = workPart.Points.CreatePoint(line29, scalar17, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    direction22 = workPart.Directions.CreateDirection(datumAxis2, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    xform15 = workPart.Xforms.CreateXformByPlaneXDirPoint(datumPlane2, direction22, point31, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem16 = workPart.CoordinateSystems.CreateCoordinateSystem(xform15, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    datumCsysBuilder14 = workPart.Features.CreateDatumCsysBuilder(NXOpen.Features.Feature.Null)
    
    datumCsysBuilder14.Csys = cartesianCoordinateSystem16
    
    datumCsysBuilder14.DisplayScaleFactor = 1.25
    
    feature20 = datumCsysBuilder14.CommitFeature()
    
    datumCsysBuilder14.Destroy()
    
    sketchInPlaceBuilder14 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    sketchInPlaceBuilder14.Csystem = cartesianCoordinateSystem16
    
    sketchInPlaceBuilder14.PlaneOption = NXOpen.Sketch.PlaneOption.Inferred
    
    theSession.Preferences.Sketch.CreateInferredConstraints = True
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = True
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = True
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    nXObject20 = sketchInPlaceBuilder14.Commit()
    
    sketchInPlaceBuilder14.Destroy()
    
    sketch40 = nXObject20
    sketch40.Activate(NXOpen.Sketch.ViewReorient.FalseValue)
    
    rotMatrix67 = NXOpen.Matrix3x3()
    
    rotMatrix67.Xx = -0.98518543504886824
    rotMatrix67.Xy = 0.15385396564202281
    rotMatrix67.Xz = -0.075753652214272216
    rotMatrix67.Yx = -0.12013202858745076
    rotMatrix67.Yy = -0.30391054115999772
    rotMatrix67.Yz = 0.94509612139681531
    rotMatrix67.Zx = 0.12238445275050922
    rotMatrix67.Zy = 0.94019537343472914
    rotMatrix67.Zz = 0.31789102770744893
    translation67 = NXOpen.Point3d(-18.34573709273571, -40.79964939770344, -9.3993555844163268)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix67, translation67, 0.57403509963166388)
    
    rotMatrix68 = NXOpen.Matrix3x3()
    
    rotMatrix68.Xx = -0.98245298925488167
    rotMatrix68.Xy = -0.13251888196661277
    rotMatrix68.Xz = -0.13124355156146333
    rotMatrix68.Yx = -0.1342370156823042
    rotMatrix68.Yy = 0.013874292767441265
    rotMatrix68.Yz = 0.99085212197426931
    rotMatrix68.Zx = -0.1294857039400735
    rotMatrix68.Zy = 0.99108337183232087
    rotMatrix68.Zz = -0.031419779639923692
    translation68 = NXOpen.Point3d(-35.901852651601153, -19.37385365936975, 37.853889226917616)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix68, translation68, 0.57403509963166388)
    
    markId120 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    theSession.ActiveSketch.Deactivate(NXOpen.Sketch.ViewReorient.FalseValue, NXOpen.Sketch.UpdateLevel.Model)
    
    markId121 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "")
    
    nErrs15 = theSession.UpdateManager.AddToDeleteList(sketch40)
    
    datumCsys14 = feature20
    nErrs16 = theSession.UpdateManager.AddToDeleteList(datumCsys14)
    
    nErrs17 = theSession.UpdateManager.AddToDeleteList(point31)
    
    nErrs18 = theSession.UpdateManager.DoUpdate(markId121)
    
    theSession.DeleteUndoMark(markId121, "")
    
    theSession.UndoToMark(markId119, "Curve")
    
    theSession.DeleteUndoMark(markId119, "Curve")
    
    rotMatrix69 = NXOpen.Matrix3x3()
    
    rotMatrix69.Xx = -0.97996656927121162
    rotMatrix69.Xy = 0.15503425162435497
    rotMatrix69.Xz = -0.12501961419749091
    rotMatrix69.Yx = -0.13664766397738487
    rotMatrix69.Yy = -0.066723977822539637
    rotMatrix69.Yz = 0.98837003531726997
    rotMatrix69.Zx = 0.1448894027882543
    rotMatrix69.Zy = 0.98565323091177215
    rotMatrix69.Zz = 0.086572335955832636
    translation69 = NXOpen.Point3d(-16.34322434995709, -24.640623682350736, 3.0053400172386802)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix69, translation69, 0.57403509963166388)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Curve->Circle...
    # ----------------------------------------------
    markId122 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId123 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Curve->Arc...
    # ----------------------------------------------
    theSession.UndoToMark(markId123, "Curve")
    
    theSession.DeleteUndoMark(markId123, "Curve")
    
    markId124 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId125 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    scalar18 = workPart.Scalars.CreateScalar(0.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    point32 = workPart.Points.CreatePoint(line28, scalar18, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    direction23 = workPart.Directions.CreateDirection(datumAxis2, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    xform16 = workPart.Xforms.CreateXformByPlaneXDirPoint(datumPlane2, direction23, point32, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem17 = workPart.CoordinateSystems.CreateCoordinateSystem(xform16, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    datumCsysBuilder15 = workPart.Features.CreateDatumCsysBuilder(NXOpen.Features.Feature.Null)
    
    datumCsysBuilder15.Csys = cartesianCoordinateSystem17
    
    datumCsysBuilder15.DisplayScaleFactor = 1.25
    
    feature21 = datumCsysBuilder15.CommitFeature()
    
    datumCsysBuilder15.Destroy()
    
    sketchInPlaceBuilder15 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    sketchInPlaceBuilder15.Csystem = cartesianCoordinateSystem17
    
    sketchInPlaceBuilder15.PlaneOption = NXOpen.Sketch.PlaneOption.Inferred
    
    theSession.Preferences.Sketch.CreateInferredConstraints = True
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = True
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = True
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    nXObject21 = sketchInPlaceBuilder15.Commit()
    
    sketchInPlaceBuilder15.Destroy()
    
    sketch41 = nXObject21
    sketch41.Activate(NXOpen.Sketch.ViewReorient.FalseValue)
    
    rotMatrix70 = NXOpen.Matrix3x3()
    
    rotMatrix70.Xx = -0.96613170086615563
    rotMatrix70.Xy = -0.21149388117111978
    rotMatrix70.Xz = -0.14785085325640573
    rotMatrix70.Yx = -0.13664766397738487
    rotMatrix70.Yy = -0.066723977822539637
    rotMatrix70.Yz = 0.98837003531726997
    rotMatrix70.Zx = -0.21889941185621009
    rotMatrix70.Zy = 0.97509909702076702
    rotMatrix70.Zz = 0.035564005374701668
    translation70 = NXOpen.Point3d(-42.29916344346794, -24.640623682350736, 42.695848470695267)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix70, translation70, 0.57403509963166388)
    
    markId126 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    theSession.ActiveSketch.Deactivate(NXOpen.Sketch.ViewReorient.FalseValue, NXOpen.Sketch.UpdateLevel.Model)
    
    markId127 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "")
    
    nErrs19 = theSession.UpdateManager.AddToDeleteList(sketch41)
    
    datumCsys15 = feature21
    nErrs20 = theSession.UpdateManager.AddToDeleteList(datumCsys15)
    
    nErrs21 = theSession.UpdateManager.AddToDeleteList(point32)
    
    nErrs22 = theSession.UpdateManager.DoUpdate(markId127)
    
    theSession.DeleteUndoMark(markId127, "")
    
    theSession.UndoToMark(markId125, "Curve")
    
    theSession.DeleteUndoMark(markId125, "Curve")
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Curve->Arc...
    # ----------------------------------------------
    markId128 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId129 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    scalar19 = workPart.Scalars.CreateScalar(0.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    point33 = workPart.Points.CreatePoint(line28, scalar19, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    direction24 = workPart.Directions.CreateDirection(datumAxis2, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    xform17 = workPart.Xforms.CreateXformByPlaneXDirPoint(datumPlane2, direction24, point33, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem18 = workPart.CoordinateSystems.CreateCoordinateSystem(xform17, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    datumCsysBuilder16 = workPart.Features.CreateDatumCsysBuilder(NXOpen.Features.Feature.Null)
    
    datumCsysBuilder16.Csys = cartesianCoordinateSystem18
    
    datumCsysBuilder16.DisplayScaleFactor = 1.25
    
    feature22 = datumCsysBuilder16.CommitFeature()
    
    datumCsysBuilder16.Destroy()
    
    sketchInPlaceBuilder16 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    sketchInPlaceBuilder16.Csystem = cartesianCoordinateSystem18
    
    sketchInPlaceBuilder16.PlaneOption = NXOpen.Sketch.PlaneOption.Inferred
    
    theSession.Preferences.Sketch.CreateInferredConstraints = True
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = True
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = True
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    nXObject22 = sketchInPlaceBuilder16.Commit()
    
    sketchInPlaceBuilder16.Destroy()
    
    sketch42 = nXObject22
    sketch42.Activate(NXOpen.Sketch.ViewReorient.FalseValue)
    
    scaleAboutPoint11 = NXOpen.Point3d(-153.94674191532434, 70.059595123141747, 0.0)
    viewCenter11 = NXOpen.Point3d(153.94674191532459, -70.059595123141591, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint11, viewCenter11)
    
    scaleAboutPoint12 = NXOpen.Point3d(-192.43342739415542, 87.574493903927234, 0.0)
    viewCenter12 = NXOpen.Point3d(192.43342739415567, -87.574493903926992, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint12, viewCenter12)
    
    scaleAboutPoint13 = NXOpen.Point3d(-240.54178424269426, 109.46811737990897, 0.0)
    viewCenter13 = NXOpen.Point3d(240.54178424269463, -109.46811737990873, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint13, viewCenter13)
    
    scaleAboutPoint14 = NXOpen.Point3d(-300.67723030336782, 136.83514672488613, 0.0)
    viewCenter14 = NXOpen.Point3d(300.67723030336816, -136.8351467248859, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint14, viewCenter14)
    
    scaleAboutPoint15 = NXOpen.Point3d(-375.84653787920979, 171.04393340610764, 0.0)
    viewCenter15 = NXOpen.Point3d(375.84653787921036, -171.04393340610744, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint15, viewCenter15)
    
    scaleAboutPoint16 = NXOpen.Point3d(-469.80817234901224, 213.80491675763454, 0.0)
    viewCenter16 = NXOpen.Point3d(469.80817234901275, -213.80491675763432, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint16, viewCenter16)
    
    scaleAboutPoint17 = NXOpen.Point3d(-587.26021543626541, 267.25614594704314, 0.0)
    viewCenter17 = NXOpen.Point3d(587.26021543626564, -267.25614594704285, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint17, viewCenter17)
    
    scaleAboutPoint18 = NXOpen.Point3d(-734.07526929533151, 334.07018243380389, 0.0)
    viewCenter18 = NXOpen.Point3d(734.07526929533185, -334.07018243380372, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint18, viewCenter18)
    
    scaleAboutPoint19 = NXOpen.Point3d(-917.59408661916473, 417.58772804225458, 0.0)
    viewCenter19 = NXOpen.Point3d(917.59408661916473, -417.58772804225458, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint19, viewCenter19)
    
    scaleAboutPoint20 = NXOpen.Point3d(-1146.9926082739555, 521.98466005281819, 0.0)
    viewCenter20 = NXOpen.Point3d(1146.992608273956, -521.98466005281819, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint20, viewCenter20)
    
    scaleAboutPoint21 = NXOpen.Point3d(-1433.740760342444, 652.48082506602259, 0.0)
    viewCenter21 = NXOpen.Point3d(1433.7407603424444, -652.48082506602259, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint21, viewCenter21)
    
    scaleAboutPoint22 = NXOpen.Point3d(-1792.1759504280549, 815.60103133252892, 0.0)
    viewCenter22 = NXOpen.Point3d(1792.1759504280558, -815.6010313325279, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint22, viewCenter22)
    
    scaleAboutPoint23 = NXOpen.Point3d(-2079.246050272071, 1066.452006429869, 0.0)
    viewCenter23 = NXOpen.Point3d(2079.246050272071, -1066.4520064298679, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint23, viewCenter23)
    
    scaleAboutPoint24 = NXOpen.Point3d(-1663.3968402176579, 853.16160514389537, 0.0)
    viewCenter24 = NXOpen.Point3d(1663.3968402176561, -853.16160514389446, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint24, viewCenter24)
    
    scaleAboutPoint25 = NXOpen.Point3d(-1407.9849383003664, 635.31027703796997, 0.0)
    viewCenter25 = NXOpen.Point3d(1407.9849383003641, -635.31027703796917, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint25, viewCenter25)
    
    scaleAboutPoint26 = NXOpen.Point3d(-1136.6902794571251, 508.24822163037601, 0.0)
    viewCenter26 = NXOpen.Point3d(1136.6902794571233, -508.24822163037516, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint26, viewCenter26)
    
    scaleAboutPoint27 = NXOpen.Point3d(-928.58323735711974, 398.35671425083547, 0.0)
    viewCenter27 = NXOpen.Point3d(928.58323735711792, -398.35671425083456, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint27, viewCenter27)
    
    scaleAboutPoint28 = NXOpen.Point3d(-742.86658988569582, 318.68537140066837, 0.0)
    viewCenter28 = NXOpen.Point3d(742.86658988569411, -318.68537140066763, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint28, viewCenter28)
    
    scaleAboutPoint29 = NXOpen.Point3d(-594.2932719085569, 254.94829712053482, 0.0)
    viewCenter29 = NXOpen.Point3d(594.29327190855508, -254.94829712053394, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint29, viewCenter29)
    
    scaleAboutPoint30 = NXOpen.Point3d(-475.43461752684578, 203.95863769642799, 0.0)
    viewCenter30 = NXOpen.Point3d(475.43461752684385, -203.95863769642705, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint30, viewCenter30)
    
    scaleAboutPoint31 = NXOpen.Point3d(-381.47298305704311, 163.16691015714241, 0.0)
    viewCenter31 = NXOpen.Point3d(381.47298305704135, -163.16691015714156, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint31, viewCenter31)
    
    scaleAboutPoint32 = NXOpen.Point3d(-305.17838644563489, 130.53352812571404, 0.0)
    viewCenter32 = NXOpen.Point3d(305.17838644563273, -130.53352812571313, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint32, viewCenter32)
    
    scaleAboutPoint33 = NXOpen.Point3d(-244.14270915650812, 106.58737744885903, 0.0)
    viewCenter33 = NXOpen.Point3d(244.14270915650604, -106.58737744885811, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint33, viewCenter33)
    
    scaleAboutPoint34 = NXOpen.Point3d(-185.51965155963586, 100.82589758675849, 0.0)
    viewCenter34 = NXOpen.Point3d(185.51965155963381, -100.82589758675761, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint34, viewCenter34)
    
    scaleAboutPoint35 = NXOpen.Point3d(-147.95480285874089, 81.582554847342934, 0.0)
    viewCenter35 = NXOpen.Point3d(147.9548028587387, -81.582554847342038, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint35, viewCenter35)
    
    scaleAboutPoint36 = NXOpen.Point3d(-21.017878536943545, 136.06310842336489, 0.0)
    viewCenter36 = NXOpen.Point3d(21.017878536941407, -136.06310842336404, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint36, viewCenter36)
    
    scaleAboutPoint37 = NXOpen.Point3d(-16.81430282955499, 108.85048673869201, 0.0)
    viewCenter37 = NXOpen.Point3d(16.814302829552879, -108.85048673869119, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint37, viewCenter37)
    
    scaleAboutPoint38 = NXOpen.Point3d(-21.017878536943549, 136.06310842336489, 0.0)
    viewCenter38 = NXOpen.Point3d(21.017878536941378, -136.06310842336404, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint38, viewCenter38)
    
    scaleAboutPoint39 = NXOpen.Point3d(-26.2723481711792, 170.07888552920602, 0.0)
    viewCenter39 = NXOpen.Point3d(26.272348171177001, -170.07888552920517, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint39, viewCenter39)
    
    scaleAboutPoint40 = NXOpen.Point3d(-32.840435213973699, 212.59860691150743, 0.0)
    viewCenter40 = NXOpen.Point3d(32.840435213971631, -212.59860691150655, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint40, viewCenter40)
    
    scaleAboutPoint41 = NXOpen.Point3d(-41.050544017466756, 265.74825863938412, 0.0)
    viewCenter41 = NXOpen.Point3d(41.05054401746473, -265.74825863938321, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint41, viewCenter41)
    
    scaleAboutPoint42 = NXOpen.Point3d(-51.31318002183329, 332.18532329923011, 0.0)
    viewCenter42 = NXOpen.Point3d(51.313180021831137, -332.18532329922908, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint42, viewCenter42)
    
    scaleAboutPoint43 = NXOpen.Point3d(-64.141475027291406, 415.2316541240375, 0.0)
    viewCenter43 = NXOpen.Point3d(64.141475027289303, -415.23165412403637, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint43, viewCenter43)
    
    scaleAboutPoint44 = NXOpen.Point3d(-80.176843784114013, 519.03956765504677, 0.0)
    viewCenter44 = NXOpen.Point3d(80.176843784111625, -519.03956765504552, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint44, viewCenter44)
    
    scaleAboutPoint45 = NXOpen.Point3d(-100.22105473014221, 648.79945956880817, 0.0)
    viewCenter45 = NXOpen.Point3d(100.22105473013981, -648.79945956880704, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint45, viewCenter45)
    
    scaleAboutPoint46 = NXOpen.Point3d(-125.2763184126774, 810.99932446101013, 0.0)
    viewCenter46 = NXOpen.Point3d(125.27631841267497, -810.999324461009, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint46, viewCenter46)
    
    scaleAboutPoint47 = NXOpen.Point3d(-156.59539801584674, 1013.7491555762625, 0.0)
    viewCenter47 = NXOpen.Point3d(156.59539801584393, -1013.7491555762612, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint47, viewCenter47)
    
    scaleAboutPoint48 = NXOpen.Point3d(-195.74424751980843, 1267.1864444703283, 0.0)
    viewCenter48 = NXOpen.Point3d(195.7442475198055, -1267.1864444703265, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint48, viewCenter48)
    
    scaleAboutPoint49 = NXOpen.Point3d(-244.68030939975981, 1583.98305558791, 0.0)
    viewCenter49 = NXOpen.Point3d(244.68030939975688, -1583.983055587908, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint49, viewCenter49)
    
    scaleAboutPoint50 = NXOpen.Point3d(-305.85038674969877, 1979.978819484887, 0.0)
    viewCenter50 = NXOpen.Point3d(305.8503867496965, -1979.9788194848852, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint50, viewCenter50)
    
    scaleAboutPoint51 = NXOpen.Point3d(-382.31298343712342, 2474.9735243561086, 0.0)
    viewCenter51 = NXOpen.Point3d(382.31298343712115, -2474.9735243561067, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint51, viewCenter51)
    
    scaleAboutPoint52 = NXOpen.Point3d(-477.89122929640428, 3093.7169054451351, 0.0)
    viewCenter52 = NXOpen.Point3d(477.89122929640143, -3093.7169054451329, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint52, viewCenter52)
    
    scaleAboutPoint53 = NXOpen.Point3d(-597.36403662050338, 3867.146131806418, 0.0)
    viewCenter53 = NXOpen.Point3d(597.36403662050259, -3867.1461318064162, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint53, viewCenter53)
    
    scaleAboutPoint54 = NXOpen.Point3d(-746.70504577562929, 4833.9326647580219, 0.0)
    viewCenter54 = NXOpen.Point3d(746.70504577562929, -4833.9326647580201, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint54, viewCenter54)
    
    scaleAboutPoint55 = NXOpen.Point3d(-933.38130721953655, 6042.4158309475279, 0.0)
    viewCenter55 = NXOpen.Point3d(933.38130721953655, -6042.4158309475251, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint55, viewCenter55)
    
    scaleAboutPoint56 = NXOpen.Point3d(-1166.7266340244191, 7553.019788684408, 0.0)
    viewCenter56 = NXOpen.Point3d(1166.7266340244191, -7553.0197886844071, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint56, viewCenter56)
    
    scaleAboutPoint57 = NXOpen.Point3d(-933.38130721953519, 6042.415830947526, 0.0)
    viewCenter57 = NXOpen.Point3d(933.38130721953792, -6042.4158309475251, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint57, viewCenter57)
    
    scaleAboutPoint58 = NXOpen.Point3d(-746.70504577562929, 4833.9326647580219, 0.0)
    viewCenter58 = NXOpen.Point3d(746.70504577562929, -4833.9326647580201, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint58, viewCenter58)
    
    scaleAboutPoint59 = NXOpen.Point3d(-597.36403662050509, 3867.1461318064171, 0.0)
    viewCenter59 = NXOpen.Point3d(597.36403662050327, -3867.1461318064153, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint59, viewCenter59)
    
    scaleAboutPoint60 = NXOpen.Point3d(-477.89122929640263, 3093.7169054451338, 0.0)
    viewCenter60 = NXOpen.Point3d(477.89122929640121, -3093.7169054451324, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint60, viewCenter60)
    
    scaleAboutPoint61 = NXOpen.Point3d(-382.31298343712331, 2474.9735243561072, 0.0)
    viewCenter61 = NXOpen.Point3d(382.31298343712103, -2474.9735243561054, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint61, viewCenter61)
    
    scaleAboutPoint62 = NXOpen.Point3d(-305.85038674969866, 1979.9788194848861, 0.0)
    viewCenter62 = NXOpen.Point3d(305.85038674969678, -1979.9788194848843, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint62, viewCenter62)
    
    scaleAboutPoint63 = NXOpen.Point3d(-244.6803093997589, 1583.9830555879091, 0.0)
    viewCenter63 = NXOpen.Point3d(244.68030939975705, -1583.9830555879073, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint63, viewCenter63)
    
    scaleAboutPoint64 = NXOpen.Point3d(-195.74424751980715, 1267.1864444703276, 0.0)
    viewCenter64 = NXOpen.Point3d(195.74424751980567, -1267.1864444703258, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint64, viewCenter64)
    
    scaleAboutPoint65 = NXOpen.Point3d(-156.59539801584617, 1013.7491555762622, 0.0)
    viewCenter65 = NXOpen.Point3d(156.5953980158443, -1013.7491555762603, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint65, viewCenter65)
    
    scaleAboutPoint66 = NXOpen.Point3d(-125.27631841267693, 810.99932446101002, 0.0)
    viewCenter66 = NXOpen.Point3d(125.27631841267542, -810.99932446100797, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint66, viewCenter66)
    
    scaleAboutPoint67 = NXOpen.Point3d(-100.22105473014155, 648.79945956880817, 0.0)
    viewCenter67 = NXOpen.Point3d(100.2210547301402, -648.79945956880601, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint67, viewCenter67)
    
    scaleAboutPoint68 = NXOpen.Point3d(-80.176843784113487, 519.03956765504688, 0.0)
    viewCenter68 = NXOpen.Point3d(80.176843784112052, -519.03956765504461, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint68, viewCenter68)
    
    scaleAboutPoint69 = NXOpen.Point3d(-64.14147502729098, 415.23165412403773, 0.0)
    viewCenter69 = NXOpen.Point3d(64.141475027289445, -415.23165412403551, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint69, viewCenter69)
    
    scaleAboutPoint70 = NXOpen.Point3d(-51.313180021832785, 332.18532329923045, 0.0)
    viewCenter70 = NXOpen.Point3d(51.313180021831478, -332.18532329922817, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint70, viewCenter70)
    
    scaleAboutPoint71 = NXOpen.Point3d(-41.050544017466351, 265.74825863938463, 0.0)
    viewCenter71 = NXOpen.Point3d(41.050544017465064, -265.7482586393823, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint71, viewCenter71)
    
    scaleAboutPoint72 = NXOpen.Point3d(-32.840435213973279, 212.59860691150794, 0.0)
    viewCenter72 = NXOpen.Point3d(32.840435213971901, -212.59860691150558, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint72, viewCenter72)
    
    scaleAboutPoint73 = NXOpen.Point3d(-31.34245044982713, 166.3915384174623, 0.0)
    viewCenter73 = NXOpen.Point3d(31.342450449825794, -166.39153841745991, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint73, viewCenter73)
    
    scaleAboutPoint74 = NXOpen.Point3d(-25.811429782210737, 133.11323073397006, 0.0)
    viewCenter74 = NXOpen.Point3d(25.811429782209355, -133.1132307339677, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint74, viewCenter74)
    
    scaleAboutPoint75 = NXOpen.Point3d(-20.649143825768743, 106.49058458717633, 0.0)
    viewCenter75 = NXOpen.Point3d(20.649143825767336, -106.49058458717394, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint75, viewCenter75)
    
    scaleAboutPoint76 = NXOpen.Point3d(-18.643226996979866, 84.720487239438043, 0.0)
    viewCenter76 = NXOpen.Point3d(18.643226996978395, -84.720487239435599, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint76, viewCenter76)
    
    scaleAboutPoint77 = NXOpen.Point3d(-26.619696269105091, 61.357455939426195, 0.0)
    viewCenter77 = NXOpen.Point3d(26.619696269103674, -61.357455939423815, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint77, viewCenter77)
    
    scaleAboutPoint78 = NXOpen.Point3d(-44.838140878811267, 67.25721131821706, 0.0)
    viewCenter78 = NXOpen.Point3d(44.83814087880986, -67.257211318214701, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint78, viewCenter78)
    
    markId130 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    theSession.ActiveSketch.Deactivate(NXOpen.Sketch.ViewReorient.FalseValue, NXOpen.Sketch.UpdateLevel.Model)
    
    markId131 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "")
    
    nErrs23 = theSession.UpdateManager.AddToDeleteList(sketch42)
    
    datumCsys16 = feature22
    nErrs24 = theSession.UpdateManager.AddToDeleteList(datumCsys16)
    
    nErrs25 = theSession.UpdateManager.AddToDeleteList(point33)
    
    nErrs26 = theSession.UpdateManager.DoUpdate(markId131)
    
    theSession.DeleteUndoMark(markId131, "")
    
    theSession.UndoToMark(markId129, "Curve")
    
    theSession.DeleteUndoMark(markId129, "Curve")
    
    rotMatrix71 = NXOpen.Matrix3x3()
    
    rotMatrix71.Xx = 0.96997021283366114
    rotMatrix71.Xy = -0.21166550724511768
    rotMatrix71.Xz = 0.11981443676824254
    rotMatrix71.Yx = -0.13664766397738487
    rotMatrix71.Yy = -0.066723977822539637
    rotMatrix71.Yz = 0.98837003531726997
    rotMatrix71.Zx = -0.20120934904956067
    rotMatrix71.Zy = -0.97506185641025156
    rotMatrix71.Zz = -0.093643868079270748
    translation71 = NXOpen.Point3d(-288.83770904495822, -71.536133690466926, -89.196971798591079)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix71, translation71, 0.89692984317447721)
    
    rotMatrix72 = NXOpen.Matrix3x3()
    
    rotMatrix72.Xx = -0.77975439556428394
    rotMatrix72.Xy = -0.25756351730972649
    rotMatrix72.Xz = -0.57065236103009609
    rotMatrix72.Yx = -0.39622075365245391
    rotMatrix72.Yy = -0.50271021247726055
    rotMatrix72.Yz = 0.76830433855741698
    rotMatrix72.Zx = -0.48475993746726109
    rotMatrix72.Zy = 0.82519299368215249
    rotMatrix72.Zz = 0.28993848693236091
    translation72 = NXOpen.Point3d(-75.340180463012743, -64.024286144320513, 47.165964688307554)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix72, translation72, 0.89692984317447721)
    
    rotMatrix73 = NXOpen.Matrix3x3()
    
    rotMatrix73.Xx = -0.83810579814624164
    rotMatrix73.Xy = 0.51986758408623268
    rotMatrix73.Xz = 0.1652766351605662
    rotMatrix73.Yx = 0.033488560710770943
    rotMatrix73.Yy = -0.25337342299158849
    rotMatrix73.Yz = 0.96678871777811293
    rotMatrix73.Zx = 0.54447882182429896
    rotMatrix73.Zy = 0.81580610658285246
    rotMatrix73.Zz = 0.19494411775417617
    translation73 = NXOpen.Point3d(-51.640714276528158, -101.23766918805538, -55.909105101838307)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix73, translation73, 0.89692984317447721)
    
    origin7 = NXOpen.Point3d(75.549828078372983, -2.1434829648017995, 84.755007758551869)
    workPart.ModelingViews.WorkView.SetOrigin(origin7)
    
    origin8 = NXOpen.Point3d(75.549828078372983, -2.1434829648017995, 84.755007758551869)
    workPart.ModelingViews.WorkView.SetOrigin(origin8)
    
    rotMatrix74 = NXOpen.Matrix3x3()
    
    rotMatrix74.Xx = -0.9907499426050167
    rotMatrix74.Xy = 0.10646370621501652
    rotMatrix74.Xz = 0.084142917034790432
    rotMatrix74.Yx = 0.071753769431232753
    rotMatrix74.Yy = -0.1152835440278857
    rotMatrix74.Yz = 0.99073765500700639
    rotMatrix74.Zx = 0.11517789631943512
    rotMatrix74.Zy = 0.98761084630300455
    rotMatrix74.Zz = 0.10657799240038329
    translation74 = NXOpen.Point3d(41.43727583626432, -80.528795923912284, 5.2357495092283983)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix74, translation74, 0.89692984317447721)
    
    rotMatrix75 = NXOpen.Matrix3x3()
    
    rotMatrix75.Xx = -0.99955875211077827
    rotMatrix75.Xy = 0.013846965917660166
    rotMatrix75.Xz = 0.026278558058331212
    rotMatrix75.Yx = 0.025748604639430423
    rotMatrix75.Yy = -0.037152792247582833
    rotMatrix75.Yz = 0.99897781726489465
    rotMatrix75.Zx = 0.014809133596272299
    rotMatrix75.Zy = 0.9992136566135843
    rotMatrix75.Zz = 0.036779858605555195
    translation75 = NXOpen.Point3d(38.764524022726789, -70.681443175876439, 19.988576791398941)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix75, translation75, 0.89692984317447721)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Curve->Rectangle...
    # ----------------------------------------------
    markId132 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId133 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Rectangle")
    
    scalar20 = workPart.Scalars.CreateScalar(0.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    point34 = workPart.Points.CreatePoint(line28, scalar20, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    direction25 = workPart.Directions.CreateDirection(datumAxis2, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    xform18 = workPart.Xforms.CreateXformByPlaneXDirPoint(datumPlane2, direction25, point34, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem19 = workPart.CoordinateSystems.CreateCoordinateSystem(xform18, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    datumCsysBuilder17 = workPart.Features.CreateDatumCsysBuilder(NXOpen.Features.Feature.Null)
    
    datumCsysBuilder17.Csys = cartesianCoordinateSystem19
    
    datumCsysBuilder17.DisplayScaleFactor = 1.25
    
    feature23 = datumCsysBuilder17.CommitFeature()
    
    datumCsysBuilder17.Destroy()
    
    sketchInPlaceBuilder17 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    sketchInPlaceBuilder17.Csystem = cartesianCoordinateSystem19
    
    sketchInPlaceBuilder17.PlaneOption = NXOpen.Sketch.PlaneOption.Inferred
    
    theSession.Preferences.Sketch.CreateInferredConstraints = True
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = True
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = True
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    nXObject23 = sketchInPlaceBuilder17.Commit()
    
    sketchInPlaceBuilder17.Destroy()
    
    sketch43 = nXObject23
    sketch43.Activate(NXOpen.Sketch.ViewReorient.FalseValue)
    
    rotMatrix76 = NXOpen.Matrix3x3()
    
    rotMatrix76.Xx = -0.99122295323972143
    rotMatrix76.Xy = -0.13005643780880294
    rotMatrix76.Xz = 0.023714551549974917
    rotMatrix76.Yx = 0.017457011290701419
    rotMatrix76.Yy = 0.049044896077148771
    rotMatrix76.Yz = 0.99864400610306692
    rotMatrix76.Zx = -0.13104315978916226
    rotMatrix76.Zy = 0.9902928461587891
    rotMatrix76.Zz = -0.046344030027669784
    translation76 = NXOpen.Point3d(27.969483488851083, -63.76522993649796, 39.288799566876165)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix76, translation76, 0.89692984317447721)
    
    rotMatrix77 = NXOpen.Matrix3x3()
    
    rotMatrix77.Xx = -0.99974226830700708
    rotMatrix77.Xy = -0.009248938082215781
    rotMatrix77.Xz = 0.020732923207256202
    rotMatrix77.Yx = 0.020966538152553702
    rotMatrix77.Yy = -0.025920419472806766
    rotMatrix77.Yz = 0.9994441135612615
    rotMatrix77.Zx = -0.0087063906565341305
    rotMatrix77.Zy = 0.99962122276325927
    rotMatrix77.Zz = 0.026107657172384176
    translation77 = NXOpen.Point3d(37.483020235860792, -69.423831566271247, 23.073935205642812)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix77, translation77, 0.89692984317447721)
    
    expression49 = workPart.Expressions.CreateSystemExpression("10")
    
    expression50 = workPart.Expressions.CreateSystemExpression("12.8477166477148e-14")
    
    workPart.Expressions.Delete(expression49)
    
    workPart.Expressions.Delete(expression50)
    
    markId134 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    theSession.ActiveSketch.Deactivate(NXOpen.Sketch.ViewReorient.FalseValue, NXOpen.Sketch.UpdateLevel.Model)
    
    markId135 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "")
    
    nErrs27 = theSession.UpdateManager.AddToDeleteList(sketch43)
    
    datumCsys17 = feature23
    nErrs28 = theSession.UpdateManager.AddToDeleteList(datumCsys17)
    
    nErrs29 = theSession.UpdateManager.AddToDeleteList(point34)
    
    nErrs30 = theSession.UpdateManager.DoUpdate(markId135)
    
    theSession.DeleteUndoMark(markId135, "")
    
    theSession.UndoToMark(markId133, "Create Rectangle")
    
    theSession.DeleteUndoMark(markId133, "Create Rectangle")
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Curve->Rectangle...
    # ----------------------------------------------
    markId136 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId137 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Rectangle")
    
    scalar21 = workPart.Scalars.CreateScalar(0.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    point35 = workPart.Points.CreatePoint(line28, scalar21, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    direction26 = workPart.Directions.CreateDirection(datumAxis2, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    xform19 = workPart.Xforms.CreateXformByPlaneXDirPoint(datumPlane2, direction26, point35, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem20 = workPart.CoordinateSystems.CreateCoordinateSystem(xform19, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    datumCsysBuilder18 = workPart.Features.CreateDatumCsysBuilder(NXOpen.Features.Feature.Null)
    
    datumCsysBuilder18.Csys = cartesianCoordinateSystem20
    
    datumCsysBuilder18.DisplayScaleFactor = 1.25
    
    feature24 = datumCsysBuilder18.CommitFeature()
    
    datumCsysBuilder18.Destroy()
    
    sketchInPlaceBuilder18 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    sketchInPlaceBuilder18.Csystem = cartesianCoordinateSystem20
    
    sketchInPlaceBuilder18.PlaneOption = NXOpen.Sketch.PlaneOption.Inferred
    
    theSession.Preferences.Sketch.CreateInferredConstraints = True
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = True
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = True
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    nXObject24 = sketchInPlaceBuilder18.Commit()
    
    sketchInPlaceBuilder18.Destroy()
    
    sketch44 = nXObject24
    sketch44.Activate(NXOpen.Sketch.ViewReorient.FalseValue)
    
    markId138 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    theSession.ActiveSketch.Deactivate(NXOpen.Sketch.ViewReorient.FalseValue, NXOpen.Sketch.UpdateLevel.Model)
    
    markId139 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "")
    
    nErrs31 = theSession.UpdateManager.AddToDeleteList(sketch44)
    
    datumCsys18 = feature24
    nErrs32 = theSession.UpdateManager.AddToDeleteList(datumCsys18)
    
    nErrs33 = theSession.UpdateManager.AddToDeleteList(point35)
    
    nErrs34 = theSession.UpdateManager.DoUpdate(markId139)
    
    theSession.DeleteUndoMark(markId139, "")
    
    scalar22 = workPart.Scalars.CreateScalar(0.92843783011593262, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    point36 = workPart.Points.CreatePoint(line29, scalar22, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    direction27 = workPart.Directions.CreateDirection(datumAxis2, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    xform20 = workPart.Xforms.CreateXformByPlaneXDirPoint(datumPlane2, direction27, point36, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem21 = workPart.CoordinateSystems.CreateCoordinateSystem(xform20, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    datumCsysBuilder19 = workPart.Features.CreateDatumCsysBuilder(NXOpen.Features.Feature.Null)
    
    datumCsysBuilder19.Csys = cartesianCoordinateSystem21
    
    datumCsysBuilder19.DisplayScaleFactor = 1.25
    
    feature25 = datumCsysBuilder19.CommitFeature()
    
    datumCsysBuilder19.Destroy()
    
    sketchInPlaceBuilder19 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    sketchInPlaceBuilder19.Csystem = cartesianCoordinateSystem21
    
    sketchInPlaceBuilder19.PlaneOption = NXOpen.Sketch.PlaneOption.Inferred
    
    theSession.Preferences.Sketch.CreateInferredConstraints = True
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = True
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = True
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    nXObject25 = sketchInPlaceBuilder19.Commit()
    
    sketchInPlaceBuilder19.Destroy()
    
    sketch45 = nXObject25
    sketch45.Activate(NXOpen.Sketch.ViewReorient.FalseValue)
    
    rotMatrix78 = NXOpen.Matrix3x3()
    
    rotMatrix78.Xx = -0.99919751505144871
    rotMatrix78.Xy = 0.036693474557985932
    rotMatrix78.Xz = 0.016059727266636899
    rotMatrix78.Yx = 0.01744024229344867
    rotMatrix78.Yy = 0.037617885271216192
    rotMatrix78.Yz = 0.99913999652524788
    rotMatrix78.Zx = 0.036057785064561219
    rotMatrix78.Zy = 0.99861828725123658
    rotMatrix78.Zz = -0.038227640571369299
    translation78 = NXOpen.Point3d(40.901630004578379, -64.592102279687936, 21.913346349460724)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix78, translation78, 0.89692984317447721)
    
    markId140 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    theSession.ActiveSketch.Deactivate(NXOpen.Sketch.ViewReorient.FalseValue, NXOpen.Sketch.UpdateLevel.Model)
    
    markId141 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "")
    
    nErrs35 = theSession.UpdateManager.AddToDeleteList(sketch45)
    
    datumCsys19 = feature25
    nErrs36 = theSession.UpdateManager.AddToDeleteList(datumCsys19)
    
    nErrs37 = theSession.UpdateManager.AddToDeleteList(point36)
    
    nErrs38 = theSession.UpdateManager.DoUpdate(markId141)
    
    theSession.DeleteUndoMark(markId141, "")
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Curve->Rectangle...
    # ----------------------------------------------
    theSession.UndoToMark(markId137, "Create Rectangle")
    
    theSession.DeleteUndoMark(markId137, "Create Rectangle")
    
    rotMatrix79 = NXOpen.Matrix3x3()
    
    rotMatrix79.Xx = -0.99984839517789159
    rotMatrix79.Xy = -0.0094749248687278735
    rotMatrix79.Xz = 0.014608643295434197
    rotMatrix79.Yx = 0.014901581876542036
    rotMatrix79.Yy = -0.031621114968300709
    rotMatrix79.Yz = 0.9993888372128954
    rotMatrix79.Zx = -0.0090071925580622134
    rotMatrix79.Zy = 0.99945501694018368
    rotMatrix79.Zz = 0.031757512423496295
    translation79 = NXOpen.Point3d(37.810168010996065, -69.186940704529704, 23.164972650941905)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix79, translation79, 0.89692984317447721)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Curve->Rectangle...
    # ----------------------------------------------
    markId142 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId143 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Rectangle")
    
    theSession.UndoToMark(markId143, "Create Rectangle")
    
    theSession.DeleteUndoMark(markId143, "Create Rectangle")
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Curve->Rectangle...
    # ----------------------------------------------
    markId144 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId145 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Rectangle")
    
    scalar23 = workPart.Scalars.CreateScalar(0.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    point37 = workPart.Points.CreatePoint(line28, scalar23, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    direction28 = workPart.Directions.CreateDirection(datumAxis2, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    xform21 = workPart.Xforms.CreateXformByPlaneXDirPoint(datumPlane2, direction28, point37, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem22 = workPart.CoordinateSystems.CreateCoordinateSystem(xform21, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    datumCsysBuilder20 = workPart.Features.CreateDatumCsysBuilder(NXOpen.Features.Feature.Null)
    
    datumCsysBuilder20.Csys = cartesianCoordinateSystem22
    
    datumCsysBuilder20.DisplayScaleFactor = 1.25
    
    feature26 = datumCsysBuilder20.CommitFeature()
    
    datumCsysBuilder20.Destroy()
    
    sketchInPlaceBuilder20 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    sketchInPlaceBuilder20.Csystem = cartesianCoordinateSystem22
    
    sketchInPlaceBuilder20.PlaneOption = NXOpen.Sketch.PlaneOption.Inferred
    
    theSession.Preferences.Sketch.CreateInferredConstraints = True
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = True
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = True
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    nXObject26 = sketchInPlaceBuilder20.Commit()
    
    sketchInPlaceBuilder20.Destroy()
    
    sketch46 = nXObject26
    sketch46.Activate(NXOpen.Sketch.ViewReorient.FalseValue)
    
    markId146 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    theSession.ActiveSketch.Deactivate(NXOpen.Sketch.ViewReorient.FalseValue, NXOpen.Sketch.UpdateLevel.Model)
    
    markId147 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "")
    
    nErrs39 = theSession.UpdateManager.AddToDeleteList(sketch46)
    
    datumCsys20 = feature26
    nErrs40 = theSession.UpdateManager.AddToDeleteList(datumCsys20)
    
    nErrs41 = theSession.UpdateManager.AddToDeleteList(point37)
    
    nErrs42 = theSession.UpdateManager.DoUpdate(markId147)
    
    theSession.DeleteUndoMark(markId147, "")
    
    theSession.UndoToMark(markId145, "Create Rectangle")
    
    theSession.DeleteUndoMark(markId145, "Create Rectangle")
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Curve->Rectangle...
    # ----------------------------------------------
    markId148 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId149 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Rectangle")
    
    scalar24 = workPart.Scalars.CreateScalar(0.89652538797769932, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    point38 = workPart.Points.CreatePoint(line29, scalar24, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    direction29 = workPart.Directions.CreateDirection(datumAxis2, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    xform22 = workPart.Xforms.CreateXformByPlaneXDirPoint(datumPlane2, direction29, point38, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem23 = workPart.CoordinateSystems.CreateCoordinateSystem(xform22, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    datumCsysBuilder21 = workPart.Features.CreateDatumCsysBuilder(NXOpen.Features.Feature.Null)
    
    datumCsysBuilder21.Csys = cartesianCoordinateSystem23
    
    datumCsysBuilder21.DisplayScaleFactor = 1.25
    
    feature27 = datumCsysBuilder21.CommitFeature()
    
    datumCsysBuilder21.Destroy()
    
    sketchInPlaceBuilder21 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    sketchInPlaceBuilder21.Csystem = cartesianCoordinateSystem23
    
    sketchInPlaceBuilder21.PlaneOption = NXOpen.Sketch.PlaneOption.Inferred
    
    theSession.Preferences.Sketch.CreateInferredConstraints = True
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = True
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = True
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    nXObject27 = sketchInPlaceBuilder21.Commit()
    
    sketchInPlaceBuilder21.Destroy()
    
    sketch47 = nXObject27
    sketch47.Activate(NXOpen.Sketch.ViewReorient.FalseValue)
    
    expression51 = workPart.Expressions.CreateSystemExpression("18")
    
    workPart.Expressions.Delete(expression51)
    
    markId150 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    theSession.ActiveSketch.Deactivate(NXOpen.Sketch.ViewReorient.FalseValue, NXOpen.Sketch.UpdateLevel.Model)
    
    markId151 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "")
    
    nErrs43 = theSession.UpdateManager.AddToDeleteList(sketch47)
    
    datumCsys21 = feature27
    nErrs44 = theSession.UpdateManager.AddToDeleteList(datumCsys21)
    
    nErrs45 = theSession.UpdateManager.AddToDeleteList(point38)
    
    nErrs46 = theSession.UpdateManager.DoUpdate(markId151)
    
    theSession.DeleteUndoMark(markId151, "")
    
    theSession.UndoToMark(markId149, "Create Rectangle")
    
    theSession.DeleteUndoMark(markId149, "Create Rectangle")
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Curve->Rectangle...
    # ----------------------------------------------
    markId152 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId153 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Rectangle")
    
    scalar25 = workPart.Scalars.CreateScalar(0.9197955678351607, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    point39 = workPart.Points.CreatePoint(line29, scalar25, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    direction30 = workPart.Directions.CreateDirection(datumAxis2, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    xform23 = workPart.Xforms.CreateXformByPlaneXDirPoint(datumPlane2, direction30, point39, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem24 = workPart.CoordinateSystems.CreateCoordinateSystem(xform23, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    datumCsysBuilder22 = workPart.Features.CreateDatumCsysBuilder(NXOpen.Features.Feature.Null)
    
    datumCsysBuilder22.Csys = cartesianCoordinateSystem24
    
    datumCsysBuilder22.DisplayScaleFactor = 1.25
    
    feature28 = datumCsysBuilder22.CommitFeature()
    
    datumCsysBuilder22.Destroy()
    
    sketchInPlaceBuilder22 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    sketchInPlaceBuilder22.Csystem = cartesianCoordinateSystem24
    
    sketchInPlaceBuilder22.PlaneOption = NXOpen.Sketch.PlaneOption.Inferred
    
    theSession.Preferences.Sketch.CreateInferredConstraints = True
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = True
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = True
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    nXObject28 = sketchInPlaceBuilder22.Commit()
    
    sketchInPlaceBuilder22.Destroy()
    
    sketch48 = nXObject28
    sketch48.Activate(NXOpen.Sketch.ViewReorient.FalseValue)
    
    rotMatrix80 = NXOpen.Matrix3x3()
    
    rotMatrix80.Xx = -0.74852303689327393
    rotMatrix80.Xy = -0.66285134182022998
    rotMatrix80.Xz = -0.018475981359556068
    rotMatrix80.Yx = 0.038164063004032481
    rotMatrix80.Yy = -0.070879690984279847
    rotMatrix80.Yz = 0.9967545202811986
    rotMatrix80.Zx = -0.66200964308316634
    rotMatrix80.Zy = 0.74538860204131363
    rotMatrix80.Zz = 0.078352181921143904
    translation80 = NXOpen.Point3d(19.62491778775582, -69.408326815828573, -64.051992264873277)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix80, translation80, 0.89692984317447721)
    
    rotMatrix81 = NXOpen.Matrix3x3()
    
    rotMatrix81.Xx = -0.95429685006169607
    rotMatrix81.Xy = -0.29873840852635763
    rotMatrix81.Xz = -0.0085372849000062215
    rotMatrix81.Yx = -0.0039389377781835957
    rotMatrix81.Yy = -0.015991285216341581
    rotMatrix81.Yz = 0.99986437258575689
    rotMatrix81.Zx = -0.29883441356628315
    rotMatrix81.Zy = 0.95420104908151793
    rotMatrix81.Zz = 0.014083721107254031
    translation81 = NXOpen.Point3d(23.492678533073729, -70.048631147302245, -8.7229287930278616)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix81, translation81, 0.89692984317447721)
    
    markId154 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    theSession.ActiveSketch.Deactivate(NXOpen.Sketch.ViewReorient.FalseValue, NXOpen.Sketch.UpdateLevel.Model)
    
    markId155 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "")
    
    nErrs47 = theSession.UpdateManager.AddToDeleteList(sketch48)
    
    datumCsys22 = feature28
    nErrs48 = theSession.UpdateManager.AddToDeleteList(datumCsys22)
    
    nErrs49 = theSession.UpdateManager.AddToDeleteList(point39)
    
    nErrs50 = theSession.UpdateManager.DoUpdate(markId155)
    
    theSession.DeleteUndoMark(markId155, "")
    
    theSession.UndoToMark(markId153, "Create Rectangle")
    
    theSession.DeleteUndoMark(markId153, "Create Rectangle")
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Curve->Rectangle...
    # ----------------------------------------------
    markId156 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId157 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Rectangle")
    
    rotMatrix82 = NXOpen.Matrix3x3()
    
    rotMatrix82.Xx = -0.99904709647419621
    rotMatrix82.Xy = -0.043556991596446964
    rotMatrix82.Xz = -0.0027726358477405534
    rotMatrix82.Yx = -0.0015841730533731756
    rotMatrix82.Yy = -0.027296094810210069
    rotMatrix82.Yz = 0.99962613691512148
    rotMatrix82.Zx = -0.043616389376174833
    rotMatrix82.Zy = 0.99867798197976665
    rotMatrix82.Zz = 0.02720108245285166
    translation82 = NXOpen.Point3d(45.726687295500739, -71.073241840682996, -32.839547028146868)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix82, translation82, 0.89692984317447721)
    
    scalar26 = workPart.Scalars.CreateScalar(0.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    edge5 = extrude1.FindObject("EDGE * 120 * 140 {(-0,0,140)(-0,0,90)(-0,0,40) EXTRUDE(2)}")
    point40 = workPart.Points.CreatePoint(edge5, scalar26, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    edge6 = extrude1.FindObject("EDGE * 120 * 170 {(140,0,140)(70,0,140)(-0,0,140) EXTRUDE(2)}")
    direction31 = workPart.Directions.CreateDirection(edge6, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    face2 = extrude1.FindObject("FACE 120 {(124.868010523063,0,70) EXTRUDE(2)}")
    xform24 = workPart.Xforms.CreateXformByPlaneXDirPoint(face2, direction31, point40, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem25 = workPart.CoordinateSystems.CreateCoordinateSystem(xform24, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    datumCsysBuilder23 = workPart.Features.CreateDatumCsysBuilder(NXOpen.Features.Feature.Null)
    
    datumCsysBuilder23.Csys = cartesianCoordinateSystem25
    
    datumCsysBuilder23.DisplayScaleFactor = 1.25
    
    feature29 = datumCsysBuilder23.CommitFeature()
    
    datumCsysBuilder23.Destroy()
    
    sketchInPlaceBuilder23 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    sketchInPlaceBuilder23.Csystem = cartesianCoordinateSystem25
    
    sketchInPlaceBuilder23.PlaneOption = NXOpen.Sketch.PlaneOption.Inferred
    
    theSession.Preferences.Sketch.CreateInferredConstraints = True
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = True
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = True
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    nXObject29 = sketchInPlaceBuilder23.Commit()
    
    sketchInPlaceBuilder23.Destroy()
    
    sketch49 = nXObject29
    sketch49.Activate(NXOpen.Sketch.ViewReorient.FalseValue)
    
    rotMatrix83 = NXOpen.Matrix3x3()
    
    rotMatrix83.Xx = -0.99995068082111283
    rotMatrix83.Xy = -0.0089545975492199819
    rotMatrix83.Xz = -0.0042954753082527723
    rotMatrix83.Yx = -0.0048184496829273152
    rotMatrix83.Yy = 0.059223927488310804
    rotMatrix83.Yz = 0.99823309349846379
    rotMatrix83.Zx = -0.0086843806944078769
    rotMatrix83.Zy = 0.99820455899359184
    rotMatrix83.Zz = -0.059264153890558419
    translation83 = NXOpen.Point3d(48.323652956109314, -64.606242381076243, -31.92706946645157)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix83, translation83, 0.89692984317447721)
    
    rotMatrix84 = NXOpen.Matrix3x3()
    
    rotMatrix84.Xx = -0.92766930546317228
    rotMatrix84.Xy = -0.37077414568876194
    rotMatrix84.Xz = -0.044228866029371927
    rotMatrix84.Yx = 0.068195487095620108
    rotMatrix84.Yy = -0.2846858496158895
    rotMatrix84.Yz = 0.95619210547267675
    rotMatrix84.Zx = -0.36712264332408923
    rotMatrix84.Zy = 0.88401385731064686
    rotMatrix84.Zz = 0.28937944785607284
    translation84 = NXOpen.Point3d(17.586670963953608, -94.054109690308749, -21.077550011158039)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix84, translation84, 0.89692984317447721)
    
    rotMatrix85 = NXOpen.Matrix3x3()
    
    rotMatrix85.Xx = -0.99362081936705893
    rotMatrix85.Xy = -0.11270741256673616
    rotMatrix85.Xz = -0.0038349019341846393
    rotMatrix85.Yx = -0.0072754337512818202
    rotMatrix85.Yy = 0.030130788706098251
    rotMatrix85.Yz = 0.9995194863711665
    rotMatrix85.Zx = -0.11253770649903977
    rotMatrix85.Zy = 0.99317127159642582
    rotMatrix85.Zz = -0.030758574275736847
    translation85 = NXOpen.Point3d(40.377458600305772, -66.455114596226196, -22.976711498216417)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix85, translation85, 0.89692984317447721)
    
    theSession.SetUndoMarkVisibility(markId157, "Create Rectangle", NXOpen.Session.MarkVisibility.Visible)
    
    # ----------------------------------------------
    # Creating rectangle using By 3 Points method 
    # ----------------------------------------------
    startPoint7 = NXOpen.Point3d(16.489935160357241, 0.0, 123.94851516604139)
    endPoint7 = NXOpen.Point3d(-21.510064839642759, 0.0, 123.94851516604139)
    line34 = workPart.Curves.CreateLine(startPoint7, endPoint7)
    
    startPoint8 = NXOpen.Point3d(-21.510064839642759, 0.0, 123.94851516604139)
    endPoint8 = NXOpen.Point3d(-21.510064839642759, 0.0, 149.62609655360941)
    line35 = workPart.Curves.CreateLine(startPoint8, endPoint8)
    
    startPoint9 = NXOpen.Point3d(-21.510064839642759, 0.0, 149.62609655360941)
    endPoint9 = NXOpen.Point3d(16.489935160357241, 0.0, 149.62609655360941)
    line36 = workPart.Curves.CreateLine(startPoint9, endPoint9)
    
    startPoint10 = NXOpen.Point3d(16.489935160357241, 0.0, 149.62609655360941)
    endPoint10 = NXOpen.Point3d(16.489935160357241, 0.0, 123.94851516604139)
    line37 = workPart.Curves.CreateLine(startPoint10, endPoint10)
    
    theSession.ActiveSketch.AddGeometry(line34, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line35, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line36, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line37, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    geom1_18 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_18.Geometry = line34
    geom1_18.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_18.SplineDefiningPointIndex = 0
    geom2_18 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_18.Geometry = line35
    geom2_18.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_18.SplineDefiningPointIndex = 0
    sketchGeometricConstraint14 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_18, geom2_18)
    
    geom1_19 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_19.Geometry = line35
    geom1_19.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_19.SplineDefiningPointIndex = 0
    geom2_19 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_19.Geometry = line36
    geom2_19.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_19.SplineDefiningPointIndex = 0
    sketchGeometricConstraint15 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_19, geom2_19)
    
    geom1_20 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_20.Geometry = line36
    geom1_20.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_20.SplineDefiningPointIndex = 0
    geom2_20 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_20.Geometry = line37
    geom2_20.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_20.SplineDefiningPointIndex = 0
    sketchGeometricConstraint16 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_20, geom2_20)
    
    geom1_21 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_21.Geometry = line37
    geom1_21.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_21.SplineDefiningPointIndex = 0
    geom2_21 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_21.Geometry = line34
    geom2_21.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_21.SplineDefiningPointIndex = 0
    sketchGeometricConstraint17 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_21, geom2_21)
    
    geom2 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2.Geometry = line34
    geom2.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    geom2.SplineDefiningPointIndex = 0
    sketchGeometricConstraint18 = theSession.ActiveSketch.CreateHorizontalConstraint(geom2)
    
    conGeom1_7 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_7.Geometry = line34
    conGeom1_7.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_7.SplineDefiningPointIndex = 0
    conGeom2_7 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_7.Geometry = line35
    conGeom2_7.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_7.SplineDefiningPointIndex = 0
    sketchGeometricConstraint19 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_7, conGeom2_7)
    
    conGeom1_8 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_8.Geometry = line35
    conGeom1_8.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_8.SplineDefiningPointIndex = 0
    conGeom2_8 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_8.Geometry = line36
    conGeom2_8.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_8.SplineDefiningPointIndex = 0
    sketchGeometricConstraint20 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_8, conGeom2_8)
    
    conGeom1_9 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_9.Geometry = line36
    conGeom1_9.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_9.SplineDefiningPointIndex = 0
    conGeom2_9 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_9.Geometry = line37
    conGeom2_9.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_9.SplineDefiningPointIndex = 0
    sketchGeometricConstraint21 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_9, conGeom2_9)
    
    conGeom1_10 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_10.Geometry = line37
    conGeom1_10.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_10.SplineDefiningPointIndex = 0
    conGeom2_10 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_10.Geometry = line34
    conGeom2_10.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_10.SplineDefiningPointIndex = 0
    sketchGeometricConstraint22 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_10, conGeom2_10)
    
    dimObject1_11 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_11.Geometry = line34
    dimObject1_11.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_11.AssocValue = 0
    dimObject1_11.HelpPoint.X = 0.0
    dimObject1_11.HelpPoint.Y = 0.0
    dimObject1_11.HelpPoint.Z = 0.0
    dimObject1_11.View = NXOpen.NXObject.Null
    dimObject2_3 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_3.Geometry = line34
    dimObject2_3.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_3.AssocValue = 0
    dimObject2_3.HelpPoint.X = 0.0
    dimObject2_3.HelpPoint.Y = 0.0
    dimObject2_3.HelpPoint.Z = 0.0
    dimObject2_3.View = NXOpen.NXObject.Null
    dimOrigin11 = NXOpen.Point3d(-2.5100648396427587, 0.0, 113.91428554542071)
    sketchDimensionalConstraint9 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_11, dimObject2_3, dimOrigin11, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    sketchHelpedDimensionalConstraint1 = sketchDimensionalConstraint9
    dimension9 = sketchHelpedDimensionalConstraint1.AssociatedDimension
    
    expression52 = sketchHelpedDimensionalConstraint1.AssociatedExpression
    
    dimObject1_12 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_12.Geometry = line35
    dimObject1_12.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_12.AssocValue = 0
    dimObject1_12.HelpPoint.X = 0.0
    dimObject1_12.HelpPoint.Y = 0.0
    dimObject1_12.HelpPoint.Z = 0.0
    dimObject1_12.View = NXOpen.NXObject.Null
    dimObject2_4 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_4.Geometry = line35
    dimObject2_4.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_4.AssocValue = 0
    dimObject2_4.HelpPoint.X = 0.0
    dimObject2_4.HelpPoint.Y = 0.0
    dimObject2_4.HelpPoint.Z = 0.0
    dimObject2_4.View = NXOpen.NXObject.Null
    dimOrigin12 = NXOpen.Point3d(-31.544294460263437, 0.0, 136.78730585982541)
    sketchDimensionalConstraint10 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_12, dimObject2_4, dimOrigin12, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    sketchHelpedDimensionalConstraint2 = sketchDimensionalConstraint10
    dimension10 = sketchHelpedDimensionalConstraint2.AssociatedDimension
    
    expression53 = sketchHelpedDimensionalConstraint2.AssociatedExpression
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = False
    
    theSession.ActiveSketch.Update()
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = True
    
    geoms1 = [NXOpen.SmartObject.Null] * 4 
    geoms1[0] = line34
    geoms1[1] = line35
    geoms1[2] = line36
    geoms1[3] = line37
    theSession.ActiveSketch.UpdateConstraintDisplay(geoms1)
    
    geoms2 = [NXOpen.SmartObject.Null] * 4 
    geoms2[0] = line34
    geoms2[1] = line35
    geoms2[2] = line36
    geoms2[3] = line37
    theSession.ActiveSketch.UpdateDimensionDisplay(geoms2)
    
    rotMatrix86 = NXOpen.Matrix3x3()
    
    rotMatrix86.Xx = -0.98344164518905341
    rotMatrix86.Xy = -0.18121372061095423
    rotMatrix86.Xz = -0.002029278241620731
    rotMatrix86.Yx = -0.00027993801905764563
    rotMatrix86.Yy = -0.0096785188391063821
    rotMatrix86.Yz = 0.99995312285516047
    rotMatrix86.Zx = -0.18122486623681747
    rotMatrix86.Zy = 0.98339611232474256
    rotMatrix86.Zz = 0.0094675298801500506
    translation86 = NXOpen.Point3d(34.406049093623693, -69.998037427045205, -19.095076577587179)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix86, translation86, 0.89692984317447721)
    
    markId158 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    parallelDimension5 = dimension10
    sketchLinearDimensionBuilder3 = workPart.Sketches.CreateLinearDimensionBuilder(parallelDimension5)
    
    sketchLinearDimensionBuilder3.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Inferred
    
    sketchLinearDimensionBuilder3.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId158, "Linear Dimension Dialog")
    
    sketchLinearDimensionBuilder3.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits55 = sketchLinearDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits56 = sketchLinearDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    sketchLinearDimensionBuilder3.Style.OrdinateStyle.DoglegCreationOption = NXOpen.Annotations.OrdinateDoglegCreationOption.No
    
    dimensionlinearunits57 = sketchLinearDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits58 = sketchLinearDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits59 = sketchLinearDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits60 = sketchLinearDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    sketchLinearDimensionBuilder3.Origin.SetInferRelativeToGeometry(True)
    
    sketchLinearDimensionBuilder3.Origin.SetInferRelativeToGeometry(True)
    
    sketchLinearDimensionBuilder3.Measurement.Direction = NXOpen.Direction.Null
    
    sketchLinearDimensionBuilder3.Measurement.DirectionView = NXOpen.View.Null
    
    sketchLinearDimensionBuilder3.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits61 = sketchLinearDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits62 = sketchLinearDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits63 = sketchLinearDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits64 = sketchLinearDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits65 = sketchLinearDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits66 = sketchLinearDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits67 = sketchLinearDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits68 = sketchLinearDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits69 = sketchLinearDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits70 = sketchLinearDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits71 = sketchLinearDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits72 = sketchLinearDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    # ----------------------------------------------
    #   Dialog Begin Linear Dimension
    # ----------------------------------------------
    markId159 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Linear Dimension")
    
    theSession.DeleteUndoMark(markId159, None)
    
    markId160 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Linear Dimension")
    
    sketchLinearDimensionBuilder3.Driving.ExpressionValue.SetFormula("26")
    
    sketchLinearDimensionBuilder3.Driving.ExpressionMode = NXOpen.Annotations.DrivingValueBuilder.DrivingExpressionMode.KeepExpression
    
    sketchLinearDimensionBuilder3.Origin.SetInferRelativeToGeometry(True)
    
    nXObject30 = sketchLinearDimensionBuilder3.Commit()
    
    point1_8 = NXOpen.Point3d(-21.780154345122202, 0.0, 123.74696590836436)
    point2_8 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchLinearDimensionBuilder3.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line35, NXOpen.View.Null, point1_8, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_8)
    
    point1_9 = NXOpen.Point3d(-21.780154345122202, 0.0, 149.74696590836237)
    point2_9 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchLinearDimensionBuilder3.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line35, NXOpen.View.Null, point1_9, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_9)
    
    sketchLinearDimensionBuilder3.Driving.ExpressionValue.SetFormula("26")
    
    theSession.SetUndoMarkName(markId160, "Linear Dimension - =")
    
    theSession.SetUndoMarkVisibility(markId160, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId158, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId161 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Linear Dimension")
    
    markId162 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Linear Dimension")
    
    nXObject31 = sketchLinearDimensionBuilder3.Commit()
    
    theSession.DeleteUndoMark(markId162, None)
    
    theSession.SetUndoMarkName(markId158, "Linear Dimension")
    
    expression54 = sketchLinearDimensionBuilder3.Driving.ExpressionValue
    sketchLinearDimensionBuilder3.Destroy()
    
    theSession.DeleteUndoMark(markId161, None)
    
    theSession.SetUndoMarkVisibility(markId158, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId160, None)
    
    markId163 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    parallelDimension6 = dimension9
    sketchLinearDimensionBuilder4 = workPart.Sketches.CreateLinearDimensionBuilder(parallelDimension6)
    
    sketchLinearDimensionBuilder4.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Inferred
    
    sketchLinearDimensionBuilder4.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId163, "Linear Dimension Dialog")
    
    sketchLinearDimensionBuilder4.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits73 = sketchLinearDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits74 = sketchLinearDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    sketchLinearDimensionBuilder4.Style.OrdinateStyle.DoglegCreationOption = NXOpen.Annotations.OrdinateDoglegCreationOption.No
    
    dimensionlinearunits75 = sketchLinearDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits76 = sketchLinearDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits77 = sketchLinearDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits78 = sketchLinearDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    sketchLinearDimensionBuilder4.Origin.SetInferRelativeToGeometry(True)
    
    sketchLinearDimensionBuilder4.Origin.SetInferRelativeToGeometry(True)
    
    sketchLinearDimensionBuilder4.Measurement.Direction = NXOpen.Direction.Null
    
    sketchLinearDimensionBuilder4.Measurement.DirectionView = NXOpen.View.Null
    
    sketchLinearDimensionBuilder4.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits79 = sketchLinearDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits80 = sketchLinearDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits81 = sketchLinearDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits82 = sketchLinearDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits83 = sketchLinearDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits84 = sketchLinearDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits85 = sketchLinearDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits86 = sketchLinearDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits87 = sketchLinearDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits88 = sketchLinearDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits89 = sketchLinearDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits90 = sketchLinearDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    # ----------------------------------------------
    #   Dialog Begin Linear Dimension
    # ----------------------------------------------
    markId164 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Linear Dimension")
    
    theSession.DeleteUndoMark(markId164, None)
    
    markId165 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Linear Dimension")
    
    sketchLinearDimensionBuilder4.Driving.ExpressionValue.SetFormula("40")
    
    sketchLinearDimensionBuilder4.Driving.ExpressionMode = NXOpen.Annotations.DrivingValueBuilder.DrivingExpressionMode.KeepExpression
    
    sketchLinearDimensionBuilder4.Origin.SetInferRelativeToGeometry(True)
    
    nXObject32 = sketchLinearDimensionBuilder4.Commit()
    
    point1_10 = NXOpen.Point3d(16.696989786461426, 0.0, 123.74696590836436)
    point2_10 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchLinearDimensionBuilder4.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line34, NXOpen.View.Null, point1_10, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_10)
    
    point1_11 = NXOpen.Point3d(-23.303010213538574, 0.0, 123.74696590836237)
    point2_11 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchLinearDimensionBuilder4.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line34, NXOpen.View.Null, point1_11, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_11)
    
    sketchLinearDimensionBuilder4.Driving.ExpressionValue.SetFormula("40")
    
    theSession.SetUndoMarkName(markId165, "Linear Dimension - =")
    
    theSession.SetUndoMarkVisibility(markId165, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId163, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId166 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Linear Dimension")
    
    markId167 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Linear Dimension")
    
    nXObject33 = sketchLinearDimensionBuilder4.Commit()
    
    theSession.DeleteUndoMark(markId167, None)
    
    theSession.SetUndoMarkName(markId163, "Linear Dimension")
    
    expression55 = sketchLinearDimensionBuilder4.Driving.ExpressionValue
    sketchLinearDimensionBuilder4.Destroy()
    
    theSession.DeleteUndoMark(markId166, None)
    
    theSession.SetUndoMarkVisibility(markId163, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId165, None)
    
    rotMatrix87 = NXOpen.Matrix3x3()
    
    rotMatrix87.Xx = -0.99084756255668782
    rotMatrix87.Xy = 0.13475209920275655
    rotMatrix87.Xz = 0.0079359647126664504
    rotMatrix87.Yx = -0.0042794347546541295
    rotMatrix87.Yy = -0.090120058616588755
    rotMatrix87.Yz = 0.99592171453037648
    rotMatrix87.Zx = 0.13491773127966084
    rotMatrix87.Zy = 0.98677264189649838
    rotMatrix87.Zz = 0.089871903234303593
    translation87 = NXOpen.Point3d(56.654019958611698, -74.953402496959285, -56.940210634542865)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix87, translation87, 0.89692984317447721)
    
    markId168 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    parallelDimension7 = nXObject33
    sketchLinearDimensionBuilder5 = workPart.Sketches.CreateLinearDimensionBuilder(parallelDimension7)
    
    sketchLinearDimensionBuilder5.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Inferred
    
    sketchLinearDimensionBuilder5.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId168, "Linear Dimension Dialog")
    
    sketchLinearDimensionBuilder5.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits91 = sketchLinearDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits92 = sketchLinearDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    sketchLinearDimensionBuilder5.Style.OrdinateStyle.DoglegCreationOption = NXOpen.Annotations.OrdinateDoglegCreationOption.No
    
    dimensionlinearunits93 = sketchLinearDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits94 = sketchLinearDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits95 = sketchLinearDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits96 = sketchLinearDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    sketchLinearDimensionBuilder5.Origin.SetInferRelativeToGeometry(True)
    
    sketchLinearDimensionBuilder5.Origin.SetInferRelativeToGeometry(True)
    
    sketchLinearDimensionBuilder5.Measurement.Direction = NXOpen.Direction.Null
    
    sketchLinearDimensionBuilder5.Measurement.DirectionView = NXOpen.View.Null
    
    sketchLinearDimensionBuilder5.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits97 = sketchLinearDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits98 = sketchLinearDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits99 = sketchLinearDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits100 = sketchLinearDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits101 = sketchLinearDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits102 = sketchLinearDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits103 = sketchLinearDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits104 = sketchLinearDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits105 = sketchLinearDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits106 = sketchLinearDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits107 = sketchLinearDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits108 = sketchLinearDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    # ----------------------------------------------
    #   Dialog Begin Linear Dimension
    # ----------------------------------------------
    markId169 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Linear Dimension")
    
    theSession.DeleteUndoMark(markId169, None)
    
    markId170 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Linear Dimension")
    
    sketchLinearDimensionBuilder5.Driving.ExpressionValue.SetFormula("60")
    
    sketchLinearDimensionBuilder5.Driving.ExpressionMode = NXOpen.Annotations.DrivingValueBuilder.DrivingExpressionMode.KeepExpression
    
    sketchLinearDimensionBuilder5.Origin.SetInferRelativeToGeometry(True)
    
    nXObject34 = sketchLinearDimensionBuilder5.Commit()
    
    point1_12 = NXOpen.Point3d(16.696989786461426, 0.0, 123.74696590836436)
    point2_12 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchLinearDimensionBuilder5.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line34, NXOpen.View.Null, point1_12, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_12)
    
    point1_13 = NXOpen.Point3d(-43.30301021353857, 0.0, 123.74696590836237)
    point2_13 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchLinearDimensionBuilder5.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line34, NXOpen.View.Null, point1_13, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_13)
    
    sketchLinearDimensionBuilder5.Driving.ExpressionValue.SetFormula("60")
    
    theSession.SetUndoMarkName(markId170, "Linear Dimension - =")
    
    theSession.SetUndoMarkVisibility(markId170, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId168, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId171 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Linear Dimension")
    
    rotMatrix88 = NXOpen.Matrix3x3()
    
    rotMatrix88.Xx = -0.96852971912696961
    rotMatrix88.Xy = -0.24777279264873492
    rotMatrix88.Xz = -0.023639509108267717
    rotMatrix88.Yx = -0.015776017777692154
    rotMatrix88.Yy = -0.033674465713637872
    rotMatrix88.Yz = 0.99930833461048463
    rotMatrix88.Zx = -0.24839746462254964
    rotMatrix88.Zy = 0.96823275795748087
    rotMatrix88.Zz = 0.028705852837725518
    translation88 = NXOpen.Point3d(35.5625075000831, -70.987321332505758, -17.954387609312583)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix88, translation88, 0.89692984317447721)
    
    rotMatrix89 = NXOpen.Matrix3x3()
    
    rotMatrix89.Xx = -0.99804724663137734
    rotMatrix89.Xy = -0.05988137602129287
    rotMatrix89.Xz = -0.017773978095030157
    rotMatrix89.Yx = -0.015776017777692154
    rotMatrix89.Yy = -0.033674465713637872
    rotMatrix89.Yz = 0.99930833461048463
    rotMatrix89.Zx = -0.060438487361978557
    rotMatrix89.Zy = 0.99763733448818925
    rotMatrix89.Zz = 0.03266401813461435
    translation89 = NXOpen.Point3d(48.288550813973927, -70.987321332505758, -34.281116115710297)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix89, translation89, 0.89692984317447721)
    
    sketchLinearDimensionBuilder5.Driving.ExpressionValue.SetFormula("40")
    
    sketchLinearDimensionBuilder5.Driving.ExpressionValue.SetFormula("40")
    
    sketchLinearDimensionBuilder5.Origin.SetInferRelativeToGeometry(True)
    
    nXObject35 = sketchLinearDimensionBuilder5.Commit()
    
    point1_14 = NXOpen.Point3d(16.696989786461426, 0.0, 123.74696590836436)
    point2_14 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchLinearDimensionBuilder5.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line34, NXOpen.View.Null, point1_14, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_14)
    
    point1_15 = NXOpen.Point3d(-23.303010213538581, 0.0, 123.74696590836237)
    point2_15 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchLinearDimensionBuilder5.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line34, NXOpen.View.Null, point1_15, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_15)
    
    theSession.SetUndoMarkName(markId171, "Linear Dimension - =")
    
    theSession.SetUndoMarkVisibility(markId171, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId168, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId172 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Linear Dimension")
    
    # ----------------------------------------------
    #   Menu: Insert->Design Feature->Extrude...
    # ----------------------------------------------
    markId173 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Linear Dimension")
    
    nXObject36 = sketchLinearDimensionBuilder5.Commit()
    
    theSession.DeleteUndoMark(markId173, None)
    
    theSession.SetUndoMarkName(markId168, "Linear Dimension")
    
    expression56 = sketchLinearDimensionBuilder5.Driving.ExpressionValue
    sketchLinearDimensionBuilder5.Destroy()
    
    theSession.DeleteUndoMark(markId172, None)
    
    theSession.SetUndoMarkVisibility(markId168, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId171, None)
    
    theSession.DeleteUndoMark(markId170, None)
    
    markId174 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder8 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section8 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder8.Section = section8
    
    extrudeBuilder8.AllowSelfIntersectingSection(True)
    
    expression57 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit1)
    
    extrudeBuilder8.DistanceTolerance = 0.01
    
    extrudeBuilder8.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies39 = [NXOpen.Body.Null] * 1 
    targetBodies39[0] = NXOpen.Body.Null
    extrudeBuilder8.BooleanOperation.SetTargetBodies(targetBodies39)
    
    extrudeBuilder8.Limits.StartExtend.Value.SetFormula("20")
    
    extrudeBuilder8.Limits.EndExtend.Value.SetFormula("20")
    
    extrudeBuilder8.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies40 = [NXOpen.Body.Null] * 1 
    targetBodies40[0] = NXOpen.Body.Null
    extrudeBuilder8.BooleanOperation.SetTargetBodies(targetBodies40)
    
    extrudeBuilder8.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder8.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder8.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder8.Offset.EndOffset.SetFormula("5")
    
    extrudeBuilder8.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder8.Limits.EndExtend.Value.SetFormula("20")
    
    smartVolumeProfileBuilder8 = extrudeBuilder8.SmartVolumeProfile
    
    smartVolumeProfileBuilder8.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder8.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId174, "Extrude Dialog")
    
    section8.DistanceTolerance = 0.01
    
    section8.ChainingTolerance = 0.0094999999999999998
    
    section8.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    markId175 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    curves8 = [NXOpen.ICurve.Null] * 4 
    curves8[0] = line37
    curves8[1] = line35
    curves8[2] = line36
    curves8[3] = line34
    seedPoint8 = NXOpen.Point3d(-9.9696768802052471, 0.0, 132.41363257503036)
    regionBoundaryRule8 = workPart.ScRuleFactory.CreateRuleRegionBoundary(theSession.ActiveSketch, curves8, seedPoint8, 0.01)
    
    section8.AllowSelfIntersection(True)
    
    rules8 = [None] * 1 
    rules8[0] = regionBoundaryRule8
    helpPoint8 = NXOpen.Point3d(0.0, 0.0, 0.0)
    section8.AddToSection(rules8, NXOpen.NXObject.Null, NXOpen.NXObject.Null, NXOpen.NXObject.Null, helpPoint8, NXOpen.Section.Mode.Create, False)
    
    theSession.DeleteUndoMark(markId175, None)
    
    markId176 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId177 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    theSession.DeleteUndoMark(markId177, None)
    
    direction32 = workPart.Directions.CreateDirection(theSession.ActiveSketch, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrudeBuilder8.Direction = direction32
    
    targetBodies41 = [NXOpen.Body.Null] * 1 
    targetBodies41[0] = body1
    extrudeBuilder8.BooleanOperation.SetTargetBodies(targetBodies41)
    
    extrudeBuilder8.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies42 = [NXOpen.Body.Null] * 1 
    targetBodies42[0] = body1
    extrudeBuilder8.BooleanOperation.SetTargetBodies(targetBodies42)
    
    expression58 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit2)
    
    theSession.DeleteUndoMark(markId176, None)
    
    extrudeBuilder8.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies43 = [NXOpen.Body.Null] * 1 
    targetBodies43[0] = body1
    extrudeBuilder8.BooleanOperation.SetTargetBodies(targetBodies43)
    
    rotMatrix90 = NXOpen.Matrix3x3()
    
    rotMatrix90.Xx = -0.52590728881212634
    rotMatrix90.Xy = -0.845718493218103
    rotMatrix90.Xz = -0.090453047506321868
    rotMatrix90.Yx = 0.21187795652746355
    rotMatrix90.Yy = -0.23326046892080748
    rotMatrix90.Yz = 0.94905072845269633
    rotMatrix90.Zx = -0.8237288723311964
    rotMatrix90.Zy = 0.47994768867841031
    rotMatrix90.Zz = 0.30186248693772444
    translation90 = NXOpen.Point3d(-47.011675350070504, -104.27295363885403, -6.5081892917029549)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix90, translation90, 0.89692984317447721)
    
    extrudeBuilder8.Limits.EndExtend.Value.SetFormula("-200")
    
    extrudeBuilder8.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies44 = [NXOpen.Body.Null] * 1 
    targetBodies44[0] = body1
    extrudeBuilder8.BooleanOperation.SetTargetBodies(targetBodies44)
    
    extrudeBuilder8.Limits.EndExtend.Value.SetFormula("-140")
    
    extrudeBuilder8.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies45 = [NXOpen.Body.Null] * 1 
    targetBodies45[0] = body1
    extrudeBuilder8.BooleanOperation.SetTargetBodies(targetBodies45)
    
    rotMatrix91 = NXOpen.Matrix3x3()
    
    rotMatrix91.Xx = -0.6088102988752111
    rotMatrix91.Xy = 0.79127477349524733
    rotMatrix91.Xz = 0.056870491588557809
    rotMatrix91.Yx = -0.22854871279426012
    rotMatrix91.Yy = -0.24359042387677352
    rotMatrix91.Yz = 0.94256521857939612
    rotMatrix91.Zx = 0.75968118698804443
    rotMatrix91.Zy = 0.56084573478415856
    rotMatrix91.Zz = 0.32914518971246609
    translation91 = NXOpen.Point3d(58.770909080003058, -59.049302777963725, -166.49790240844644)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix91, translation91, 0.89692984317447721)
    
    rotMatrix92 = NXOpen.Matrix3x3()
    
    rotMatrix92.Xx = -0.96497155143272861
    rotMatrix92.Xy = 0.2460347296896232
    rotMatrix92.Xz = -0.091086863553797456
    rotMatrix92.Yx = -0.099932951029693684
    rotMatrix92.Yy = -0.02368460961213191
    rotMatrix92.Yz = 0.99471224209115983
    rotMatrix92.Zx = 0.24257640079779144
    rotMatrix92.Zy = 0.96897159455480386
    rotMatrix92.Zz = 0.047441951076174452
    translation92 = NXOpen.Point3d(69.524553287957616, -61.350414736693743, -68.389837158151451)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix92, translation92, 0.89692984317447721)
    
    rotMatrix93 = NXOpen.Matrix3x3()
    
    rotMatrix93.Xx = -0.99108519943360796
    rotMatrix93.Xy = -0.08615967152525765
    rotMatrix93.Xz = -0.10162006921030201
    rotMatrix93.Yx = -0.099932951029693684
    rotMatrix93.Yy = -0.02368460961213191
    rotMatrix93.Yz = 0.99471224209115983
    rotMatrix93.Zx = -0.088110911708730352
    rotMatrix93.Zy = 0.99599977423199504
    rotMatrix93.Zz = 0.014863275805678882
    translation93 = NXOpen.Point3d(51.24716520189456, -61.350414736693743, -30.385930495624848)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix93, translation93, 0.89692984317447721)
    
    markId178 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    theSession.DeleteUndoMark(markId178, None)
    
    markId179 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    extrudeBuilder8.ParentFeatureInternal = False
    
    markId180 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    feature30 = extrudeBuilder8.CommitFeature()
    
    theSession.DeleteUndoMark(markId179, None)
    
    theSession.SetUndoMarkName(markId174, "Extrude")
    
    expression59 = extrudeBuilder8.Limits.StartExtend.Value
    expression60 = extrudeBuilder8.Limits.EndExtend.Value
    extrudeBuilder8.Destroy()
    
    workPart.Expressions.Delete(expression57)
    
    workPart.Expressions.Delete(expression58)
    
    rotMatrix94 = NXOpen.Matrix3x3()
    
    rotMatrix94.Xx = -0.79392597248207075
    rotMatrix94.Xy = 0.60289312480899648
    rotMatrix94.Xz = -0.07874916048088712
    rotMatrix94.Yx = -0.099157100140864568
    rotMatrix94.Yy = -0.00060100748639348861
    rotMatrix94.Yz = 0.99507160962498586
    rotMatrix94.Zx = 0.59987450330052738
    rotMatrix94.Zy = 0.79782173375262777
    rotMatrix94.Zz = 0.06025828940402831
    translation94 = NXOpen.Point3d(77.696990927130685, -59.835066468407504, -118.3846675747341)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix94, translation94, 0.89692984317447721)
    
    rotMatrix95 = NXOpen.Matrix3x3()
    
    rotMatrix95.Xx = -0.97945646688990484
    rotMatrix95.Xy = -0.080750036657618346
    rotMatrix95.Xz = -0.18478219894606002
    rotMatrix95.Yx = -0.18289530206341506
    rotMatrix95.Yy = -0.030234688706765003
    rotMatrix95.Yz = 0.98266737611561228
    rotMatrix95.Zx = -0.084937258907267346
    rotMatrix95.Zy = 0.99627571243034985
    rotMatrix95.Zz = 0.014844759032117169
    translation95 = NXOpen.Point3d(54.978413682273143, -52.509665174531115, -30.696049852263492)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix95, translation95, 0.89692984317447721)
    
    rotMatrix96 = NXOpen.Matrix3x3()
    
    rotMatrix96.Xx = -0.95335042086175259
    rotMatrix96.Xy = -0.27658327199100652
    rotMatrix96.Xz = -0.12093249644936029
    rotMatrix96.Yx = -0.10806927559042817
    rotMatrix96.Yy = -0.061345855178506242
    rotMatrix96.Yz = 0.99224881845522206
    rotMatrix96.Zx = -0.28185813225111317
    rotMatrix96.Zy = 0.95902991596048404
    rotMatrix96.Zz = 0.028593943008055577
    translation96 = NXOpen.Point3d(35.048184744697295, -63.004344565095622, -13.55367577710313)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix96, translation96, 0.89692984317447721)
    
    rotMatrix97 = NXOpen.Matrix3x3()
    
    rotMatrix97.Xx = 0.64101023606554031
    rotMatrix97.Xy = 0.75936923925002309
    rotMatrix97.Xz = 0.11164334167356983
    rotMatrix97.Yx = -0.11031244735942325
    rotMatrix97.Yy = -0.05279893617750854
    rotMatrix97.Yz = 0.9924935447125578
    rotMatrix97.Zx = 0.75956371768060049
    rotMatrix97.Zy = -0.64851417164111713
    rotMatrix97.Zz = 0.04992322068797931
    translation97 = NXOpen.Point3d(-71.207432347062422, -62.185922835363037, -235.68842306360926)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix97, translation97, 0.89692984317447721)
    
    rotMatrix98 = NXOpen.Matrix3x3()
    
    rotMatrix98.Xx = 0.99146319617397205
    rotMatrix98.Xy = 0.061083259188074251
    rotMatrix98.Xz = 0.11519360259777836
    rotMatrix98.Yx = -0.1183464333215548
    rotMatrix98.Yy = 0.050778723152127628
    rotMatrix98.Yz = 0.99167315330965122
    rotMatrix98.Zx = 0.054725244198259325
    rotMatrix98.Zy = -0.99684018614921532
    rotMatrix98.Zz = 0.057574221014606422
    translation98 = NXOpen.Point3d(-156.77257463596931, -54.053944051902199, -187.10099380167486)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix98, translation98, 0.89692984317447721)
    
    rotMatrix99 = NXOpen.Matrix3x3()
    
    rotMatrix99.Xx = 0.99216388886157292
    rotMatrix99.Xy = -0.036946854274390206
    rotMatrix99.Xz = 0.11935555118346118
    rotMatrix99.Yx = -0.11947969194885576
    rotMatrix99.Yy = -0.0011625365205330581
    rotMatrix99.Yz = 0.99283596415553244
    rotMatrix99.Zx = -0.03654341049884921
    rotMatrix99.Zy = -0.99931655568596767
    rotMatrix99.Zz = -0.0055678255223390663
    translation99 = NXOpen.Point3d(-163.93602160764158, -57.635641115071252, -174.30632479741678)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix99, translation99, 0.89692984317447721)
    
    # ----------------------------------------------
    #   Menu: Tools->Journal->Stop Recording
    # ----------------------------------------------
    
if __name__ == '__main__':
    main()