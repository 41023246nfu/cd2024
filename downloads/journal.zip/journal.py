﻿# NX 1872
# Journal created by Admin on Fri May 31 15:09:56 2024 台北標準時間

#
import math
import NXOpen
import NXOpen.Annotations
import NXOpen.Features
import NXOpen.GeometricUtilities
import NXOpen.Preferences
def main() : 

    theSession  = NXOpen.Session.GetSession()
    workPart = theSession.Parts.Work
    displayPart = theSession.Parts.Display
    part1 = theSession.Parts.FindObject("model1")
    modelingView1 = part1.ModelingViews.FindObject("Trimetric")
    rotMatrix1 = NXOpen.Matrix3x3()
    
    rotMatrix1.Xx = -0.28438538572535671
    rotMatrix1.Xy = 0.34370276076498874
    rotMatrix1.Xz = -0.89498232643352782
    rotMatrix1.Yx = -0.74211742778484102
    rotMatrix1.Yy = 0.5120857237888754
    rotMatrix1.Yz = 0.43246957681395209
    rotMatrix1.Zx = 0.60694865990778524
    rotMatrix1.Zy = 0.78717000942245863
    rotMatrix1.Zz = 0.109438112657315
    translation1 = NXOpen.Point3d(0.0, 0.0, 0.0)
    modelingView1.SetRotationTranslationScale(rotMatrix1, translation1, 0.81119390228279675)
    
    rotMatrix2 = NXOpen.Matrix3x3()
    
    rotMatrix2.Xx = -0.36927510351461135
    rotMatrix2.Xy = -0.85083229261230886
    rotMatrix2.Xz = 0.37379179735831514
    rotMatrix2.Yx = -0.74211742778484102
    rotMatrix2.Yy = 0.5120857237888754
    rotMatrix2.Yz = 0.43246957681395209
    rotMatrix2.Zx = -0.55937252462226761
    rotMatrix2.Zy = -0.1176971594377329
    rotMatrix2.Zz = -0.82051798113021579
    translation2 = NXOpen.Point3d(0.0, 0.0, -0.0)
    modelingView1.SetRotationTranslationScale(rotMatrix2, translation2, 0.81119390228279675)
    
    rotMatrix3 = NXOpen.Matrix3x3()
    
    rotMatrix3.Xx = 0.62879909555403535
    rotMatrix3.Xy = 0.30846630890774773
    rotMatrix3.Xz = 0.71376483080862352
    rotMatrix3.Yx = -0.74211742778484102
    rotMatrix3.Yy = 0.5120857237888754
    rotMatrix3.Yz = 0.43246957681395209
    rotMatrix3.Zx = -0.23210648592498123
    rotMatrix3.Zy = -0.80163379903822585
    rotMatrix3.Zz = 0.55091726368947802
    translation3 = NXOpen.Point3d(0.0, 0.0, 0.0)
    modelingView1.SetRotationTranslationScale(rotMatrix3, translation3, 0.81119390228279675)
    
    rotMatrix4 = NXOpen.Matrix3x3()
    
    rotMatrix4.Xx = 0.38475015272544461
    rotMatrix4.Xy = 0.90438472453869312
    rotMatrix4.Xz = -0.18454156713007716
    rotMatrix4.Yx = -0.67972915986431004
    rotMatrix4.Yy = 0.4128757918147809
    rotMatrix4.Yz = 0.60621930830639215
    rotMatrix4.Zx = 0.62444822780428455
    rotMatrix4.Zy = -0.10780468707062742
    rotMatrix4.Zz = 0.77359069296217531
    translation4 = NXOpen.Point3d(0.0, 0.0, 0.0)
    modelingView1.SetRotationTranslationScale(rotMatrix4, translation4, 0.81119390228279675)
    
    scCollector1 = workPart.FindObject("ENTITY 113 2")
    scCollector1.Destroy()
    
    scCollector2 = workPart.FindObject("ENTITY 113 1")
    scCollector2.Destroy()
    
    theSession.UndoToMark(markId1 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Change Displayed Part")
    
    status1, partLoadStatus1 = theSession.Parts.SetActiveDisplay(part1, NXOpen.DisplayPartOption.AllowAdditional, NXOpen.PartDisplayPartWorkPartOption.UseLast)
    
    partLoadStatus1.Dispose()
    NXOpen.Session.UndoMarkId.ValueOf(124), None)
    
    workPart = theSession.Parts.Work # model1
    displayPart = theSession.Parts.Display # model1
    theSession.DeleteUndoMark(NXOpen.Session.UndoMarkId.ValueOf(124), None)
    
    rotMatrix5 = NXOpen.Matrix3x3()
    
    rotMatrix5.Xx = -0.54635118447113773
    rotMatrix5.Xy = 0.2664220922380226
    rotMatrix5.Xz = -0.79405267583108508
    rotMatrix5.Yx = -0.68576098046060185
    rotMatrix5.Yy = 0.40201499453866457
    rotMatrix5.Yz = 0.60672549134167353
    rotMatrix5.Zx = 0.48086615695503471
    rotMatrix5.Zy = 0.87601553235864416
    rotMatrix5.Zz = -0.036939493251845666
    translation5 = NXOpen.Point3d(0.0, 0.0, 0.0)
    modelingView1.SetRotationTranslationScale(rotMatrix5, translation5, 0.83317747687040644)
    
    rotMatrix6 = NXOpen.Matrix3x3()
    
    rotMatrix6.Xx = -0.17816792298470216
    rotMatrix6.Xy = 0.73430033776613834
    rotMatrix6.Xz = -0.65502611030084901
    rotMatrix6.Yx = -0.73956548878614892
    rotMatrix6.Yy = 0.33917159553361126
    rotMatrix6.Yz = 0.58138241853335471
    rotMatrix6.Zx = 0.64907555724724952
    rotMatrix6.Zy = 0.58801840340224598
    rotMatrix6.Zz = 0.48263368950421631
    translation6 = NXOpen.Point3d(0.0, 0.0, 0.0)
    modelingView1.SetRotationTranslationScale(rotMatrix6, translation6, 0.83317747687040644)
    
    rotMatrix7 = NXOpen.Matrix3x3()
    
    rotMatrix7.Xx = 0.23688402697338229
    rotMatrix7.Xy = 0.93977627807490505
    rotMatrix7.Xz = -0.24638690089483126
    rotMatrix7.Yx = -0.75507223528169198
    rotMatrix7.Yy = 0.33766993515469296
    rotMatrix7.Yz = 0.5620008313155227
    rotMatrix7.Zx = 0.61135249837682759
    rotMatrix7.Zy = 0.05291088791837821
    rotMatrix7.Zz = 0.7895875889780104
    translation7 = NXOpen.Point3d(0.0, 0.0, 0.0)
    modelingView1.SetRotationTranslationScale(rotMatrix7, translation7, 0.83317747687040644)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Curve->Circle...
    # ----------------------------------------------
    markId2 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId3 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    rotMatrix8 = NXOpen.Matrix3x3()
    
    rotMatrix8.Xx = 0.13997957732990018
    rotMatrix8.Xy = 0.91999791550998888
    rotMatrix8.Xz = -0.36607315305526744
    rotMatrix8.Yx = -0.77064573482613208
    rotMatrix8.Yy = 0.33336417099558863
    rotMatrix8.Yz = 0.54311461119244353
    rotMatrix8.Zx = 0.6216999833720761
    rotMatrix8.Zy = 0.20608776031998277
    rotMatrix8.Zz = 0.75565664538959854
    translation8 = NXOpen.Point3d(0.0, 0.0, 0.0)
    modelingView1.SetRotationTranslationScale(rotMatrix8, translation8, 0.83317747687040644)
    
    rotMatrix9 = NXOpen.Matrix3x3()
    
    rotMatrix9.Xx = -0.06070827249143336
    rotMatrix9.Xy = 0.80983746091693776
    rotMatrix9.Xz = -0.58350474937803332
    rotMatrix9.Yx = -0.77848215225710327
    rotMatrix9.Yy = 0.32746310284166308
    rotMatrix9.Yz = 0.53547498064285215
    rotMatrix9.Zx = 0.6247239744625307
    rotMatrix9.Zy = 0.48675579418526227
    rotMatrix9.Zz = 0.61056429027484216
    translation9 = NXOpen.Point3d(0.0, 0.0, 0.0)
    modelingView1.SetRotationTranslationScale(rotMatrix9, translation9, 0.83317747687040644)
    
    coordinates1 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point1 = workPart.Points.CreatePoint(coordinates1)
    
    datumAxis1 = workPart.Datums.FindObject("DATUM_CSYS(0) Y axis")
    direction1 = workPart.Directions.CreateDirection(datumAxis1, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    datumPlane1 = workPart.Datums.FindObject("DATUM_CSYS(0) YZ plane")
    xform1 = workPart.Xforms.CreateXformByPlaneXDirPoint(datumPlane1, direction1, point1, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem1 = workPart.CoordinateSystems.CreateCoordinateSystem(xform1, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    datumCsysBuilder1 = workPart.Features.CreateDatumCsysBuilder(NXOpen.Features.Feature.Null)
    
    datumCsysBuilder1.Csys = cartesianCoordinateSystem1
    
    datumCsysBuilder1.DisplayScaleFactor = 1.25
    
    feature1 = datumCsysBuilder1.CommitFeature()
    
    datumCsysBuilder1.Destroy()
    
    sketchInPlaceBuilder1 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    sketchInPlaceBuilder1.Csystem = cartesianCoordinateSystem1
    
    sketchInPlaceBuilder1.PlaneOption = NXOpen.Sketch.PlaneOption.Inferred
    
    theSession.Preferences.Sketch.CreateInferredConstraints = True
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = True
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = True
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    nXObject1 = sketchInPlaceBuilder1.Commit()
    
    sketchInPlaceBuilder1.Destroy()
    
    sketch1 = nXObject1
    sketch1.Activate(NXOpen.Sketch.ViewReorient.FalseValue)
    
    # ----------------------------------------------
    #   Menu: View->Full Screen
    # ----------------------------------------------
    # ----------------------------------------------
    #   Menu: View->Full Screen
    # ----------------------------------------------
    # ----------------------------------------------
    #   Menu: View->Full Screen
    # ----------------------------------------------
    # ----------------------------------------------
    #   Menu: View->Full Screen
    # ----------------------------------------------
    theSession.SetUndoMarkVisibility(markId3, "Curve", NXOpen.Session.MarkVisibility.Visible)
    
    nXMatrix1 = theSession.ActiveSketch.Orientation
    
    center1 = NXOpen.Point3d(0.0, -4.2189819906644708, 2.5800662653509518)
    arc1 = workPart.Curves.CreateArc(center1, nXMatrix1, 48.102731082541993, 0.0, ( 360.0 * math.pi/180.0 ))
    
    theSession.ActiveSketch.AddGeometry(arc1, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    dimObject1_1 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_1.Geometry = arc1
    dimObject1_1.AssocType = NXOpen.Sketch.AssocType.NotSet
    dimObject1_1.AssocValue = 0
    dimObject1_1.HelpPoint.X = 0.0
    dimObject1_1.HelpPoint.Y = 0.0
    dimObject1_1.HelpPoint.Z = 0.0
    dimObject1_1.View = NXOpen.NXObject.Null
    dimOrigin1 = NXOpen.Point3d(0.0, -4.2189819906644708, 6.1807396912201247)
    sketchDimensionalConstraint1 = theSession.ActiveSketch.CreateDiameterDimension(dimObject1_1, dimOrigin1, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    dimension1 = sketchDimensionalConstraint1.AssociatedDimension
    
    expression1 = sketchDimensionalConstraint1.AssociatedExpression
    
    theSession.ActiveSketch.Update()
    
    # ----------------------------------------------
    #   Menu: Edit->Undo
    # ----------------------------------------------
    marksRecycled1, undoUnavailable1 = theSession.UndoLastNVisibleMarks(1)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Curve->Circle...
    # ----------------------------------------------
    markId4 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId5 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    coordinates2 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point2 = workPart.Points.CreatePoint(coordinates2)
    
    direction2 = workPart.Directions.CreateDirection(datumAxis1, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    xform2 = workPart.Xforms.CreateXformByPlaneXDirPoint(datumPlane1, direction2, point2, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem2 = workPart.CoordinateSystems.CreateCoordinateSystem(xform2, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    datumCsysBuilder2 = workPart.Features.CreateDatumCsysBuilder(NXOpen.Features.Feature.Null)
    
    datumCsysBuilder2.Csys = cartesianCoordinateSystem2
    
    datumCsysBuilder2.DisplayScaleFactor = 1.25
    
    feature2 = datumCsysBuilder2.CommitFeature()
    
    datumCsysBuilder2.Destroy()
    
    sketchInPlaceBuilder2 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    sketchInPlaceBuilder2.Csystem = cartesianCoordinateSystem2
    
    sketchInPlaceBuilder2.PlaneOption = NXOpen.Sketch.PlaneOption.Inferred
    
    theSession.Preferences.Sketch.CreateInferredConstraints = True
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = True
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = True
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    nXObject2 = sketchInPlaceBuilder2.Commit()
    
    sketchInPlaceBuilder2.Destroy()
    
    sketch2 = nXObject2
    sketch2.Activate(NXOpen.Sketch.ViewReorient.FalseValue)
    
    theSession.SetUndoMarkVisibility(markId5, "Curve", NXOpen.Session.MarkVisibility.Visible)
    
    nXMatrix2 = theSession.ActiveSketch.Orientation
    
    center2 = NXOpen.Point3d(0.0, -0.087267255024540746, 1.2394521031605412)
    arc2 = workPart.Curves.CreateArc(center2, nXMatrix2, 13.7163952058918, 0.0, ( 360.0 * math.pi/180.0 ))
    
    theSession.ActiveSketch.AddGeometry(arc2, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    dimObject1_2 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_2.Geometry = arc2
    dimObject1_2.AssocType = NXOpen.Sketch.AssocType.NotSet
    dimObject1_2.AssocValue = 0
    dimObject1_2.HelpPoint.X = 0.0
    dimObject1_2.HelpPoint.Y = 0.0
    dimObject1_2.HelpPoint.Z = 0.0
    dimObject1_2.View = NXOpen.NXObject.Null
    dimOrigin2 = NXOpen.Point3d(0.0, -0.087267255024540746, 4.8401255290297138)
    sketchDimensionalConstraint2 = theSession.ActiveSketch.CreateDiameterDimension(dimObject1_2, dimOrigin2, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    dimension2 = sketchDimensionalConstraint2.AssociatedDimension
    
    expression2 = sketchDimensionalConstraint2.AssociatedExpression
    
    theSession.ActiveSketch.Update()
    
    # ----------------------------------------------
    #   Dialog Begin Circle
    # ----------------------------------------------
    rotMatrix10 = NXOpen.Matrix3x3()
    
    rotMatrix10.Xx = 0.16425622874575832
    rotMatrix10.Xy = 0.82207973320994243
    rotMatrix10.Xz = -0.54516493244127506
    rotMatrix10.Yx = 0.47259821350912762
    rotMatrix10.Yy = 0.41952617323874308
    rotMatrix10.Yz = 0.77501530214289593
    rotMatrix10.Zx = 0.86583533071029695
    rotMatrix10.Zy = -0.3849450638898162
    rotMatrix10.Zz = -0.31960362620073901
    translation10 = NXOpen.Point3d(0.0, 0.0, 0.0)
    modelingView1.SetRotationTranslationScale(rotMatrix10, translation10, 0.83317747687040644)
    
    rotMatrix11 = NXOpen.Matrix3x3()
    
    rotMatrix11.Xx = 0.12976387934130323
    rotMatrix11.Xy = 0.83345881856343151
    rotMatrix11.Xz = -0.53712915893400726
    rotMatrix11.Yx = 0.25032814360756467
    rotMatrix11.Yy = 0.49662415988322606
    rotMatrix11.Yz = 0.83108378899980762
    rotMatrix11.Zx = 0.95942543021138105
    rotMatrix11.Zy = -0.24230320175172626
    rotMatrix11.Zz = -0.14419432126327125
    translation11 = NXOpen.Point3d(0.0, 0.0, 0.0)
    modelingView1.SetRotationTranslationScale(rotMatrix11, translation11, 0.83317747687040644)
    
    rotMatrix12 = NXOpen.Matrix3x3()
    
    rotMatrix12.Xx = 0.0026981862462809592
    rotMatrix12.Xy = 0.85546378381906385
    rotMatrix12.Xz = -0.51785561150281112
    rotMatrix12.Yx = 0.13466278542623464
    rotMatrix12.Yy = 0.51282971808562838
    rotMatrix12.Yz = 0.8478629691580255
    rotMatrix12.Zx = 0.99088781101203793
    rotMatrix12.Zy = -0.072023571295687719
    rotMatrix12.Zz = -0.11381542586831858
    translation12 = NXOpen.Point3d(0.0, 0.0, 0.0)
    modelingView1.SetRotationTranslationScale(rotMatrix12, translation12, 0.83317747687040644)
    
    rotMatrix13 = NXOpen.Matrix3x3()
    
    rotMatrix13.Xx = -0.37520423253114582
    rotMatrix13.Xy = 0.77958764859003937
    rotMatrix13.Xz = -0.50146274244111932
    rotMatrix13.Yx = -0.27285515959850726
    rotMatrix13.Yy = 0.42412933751144261
    rotMatrix13.Yz = 0.86351859675549514
    rotMatrix13.Zx = 0.88587349309661012
    rotMatrix13.Zy = 0.46082252899349424
    rotMatrix13.Zz = 0.053579389702135952
    translation13 = NXOpen.Point3d(0.0, 0.0, 0.0)
    modelingView1.SetRotationTranslationScale(rotMatrix13, translation13, 0.83317747687040644)
    
    # ----------------------------------------------
    #   Menu: View->Full Screen
    # ----------------------------------------------
    # ----------------------------------------------
    #   Menu: View->Full Screen
    # ----------------------------------------------
    markId6 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    theSession.SetUndoMarkVisibility(markId6, "Curve", NXOpen.Session.MarkVisibility.Visible)
    
    nXMatrix3 = theSession.ActiveSketch.Orientation
    
    center3 = NXOpen.Point3d(0.0, -4.0, -18.0)
    arc3 = workPart.Curves.CreateArc(center3, nXMatrix3, 1.0582250334488195, 0.0, ( 360.0 * math.pi/180.0 ))
    
    theSession.ActiveSketch.AddGeometry(arc3, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    dimObject1_3 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_3.Geometry = arc3
    dimObject1_3.AssocType = NXOpen.Sketch.AssocType.NotSet
    dimObject1_3.AssocValue = 0
    dimObject1_3.HelpPoint.X = 0.0
    dimObject1_3.HelpPoint.Y = 0.0
    dimObject1_3.HelpPoint.Z = 0.0
    dimObject1_3.View = NXOpen.NXObject.Null
    dimOrigin3 = NXOpen.Point3d(0.0, -4.0, -14.399326574130827)
    sketchDimensionalConstraint3 = theSession.ActiveSketch.CreateDiameterDimension(dimObject1_3, dimOrigin3, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    dimension3 = sketchDimensionalConstraint3.AssociatedDimension
    
    expression3 = sketchDimensionalConstraint3.AssociatedExpression
    
    theSession.ActiveSketch.Update()
    
    markId7 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    theSession.SetUndoMarkVisibility(markId7, "Curve", NXOpen.Session.MarkVisibility.Visible)
    
    nXMatrix4 = theSession.ActiveSketch.Orientation
    
    center4 = NXOpen.Point3d(0.0, -34.0, 13.0)
    arc4 = workPart.Curves.CreateArc(center4, nXMatrix4, 0.51868803935971142, 0.0, ( 360.0 * math.pi/180.0 ))
    
    theSession.ActiveSketch.AddGeometry(arc4, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    dimObject1_4 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_4.Geometry = arc4
    dimObject1_4.AssocType = NXOpen.Sketch.AssocType.NotSet
    dimObject1_4.AssocValue = 0
    dimObject1_4.HelpPoint.X = 0.0
    dimObject1_4.HelpPoint.Y = 0.0
    dimObject1_4.HelpPoint.Z = 0.0
    dimObject1_4.View = NXOpen.NXObject.Null
    dimOrigin4 = NXOpen.Point3d(0.0, -34.0, 16.600673425869171)
    sketchDimensionalConstraint4 = theSession.ActiveSketch.CreateDiameterDimension(dimObject1_4, dimOrigin4, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    dimension4 = sketchDimensionalConstraint4.AssociatedDimension
    
    expression4 = sketchDimensionalConstraint4.AssociatedExpression
    
    theSession.ActiveSketch.Update()
    
    # ----------------------------------------------
    #   Dialog Begin Circle
    # ----------------------------------------------
    # ----------------------------------------------
    #   Menu: Edit->Undo
    # ----------------------------------------------
    marksRecycled2, undoUnavailable2 = theSession.UndoLastNVisibleMarks(1)
    
    # ----------------------------------------------
    #   Menu: Edit->Undo
    # ----------------------------------------------
    marksRecycled3, undoUnavailable3 = theSession.UndoLastNVisibleMarks(1)
    
    # ----------------------------------------------
    #   Menu: Edit->Undo
    # ----------------------------------------------
    marksRecycled4, undoUnavailable4 = theSession.UndoLastNVisibleMarks(1)
    
    # ----------------------------------------------
    #   Menu: Edit->Redo
    # ----------------------------------------------
    theSession.Redo()
    
    # ----------------------------------------------
    #   Menu: Insert->Design Feature->Extrude...
    # ----------------------------------------------
    markId8 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder1 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section1 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder1.Section = section1
    
    extrudeBuilder1.AllowSelfIntersectingSection(True)
    
    unit1 = extrudeBuilder1.Draft.FrontDraftAngle.Units
    
    expression5 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit1)
    
    extrudeBuilder1.DistanceTolerance = 0.01
    
    extrudeBuilder1.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies1 = [NXOpen.Body.Null] * 1 
    targetBodies1[0] = NXOpen.Body.Null
    extrudeBuilder1.BooleanOperation.SetTargetBodies(targetBodies1)
    
    extrudeBuilder1.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder1.Limits.EndExtend.Value.SetFormula("25")
    
    extrudeBuilder1.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder1.Offset.EndOffset.SetFormula("5")
    
    smartVolumeProfileBuilder1 = extrudeBuilder1.SmartVolumeProfile
    
    smartVolumeProfileBuilder1.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder1.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId8, "Extrude Dialog")
    
    extrudeBuilder1.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder1.Limits.EndExtend.Value.SetFormula("25")
    
    extrudeBuilder1.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder1.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder1.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder1.Offset.EndOffset.SetFormula("5")
    
    section1.DistanceTolerance = 0.01
    
    section1.ChainingTolerance = 0.0094999999999999998
    
    section1.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    markId9 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    sketchFeature2 = workPart.Features.FindObject("SKETCH(1)")
    sketch4 = sketchFeature2.FindObject("SKETCH_000")
    curves1 = [NXOpen.ICurve.Null] * 1 
    arc7 = sketch4.FindObject("Curve Arc1")
    curves1[0] = arc7
    seedPoint1 = NXOpen.Point3d(0.0, 4.4848644802727238, 1.239452103160541)
    regionBoundaryRule1 = workPart.ScRuleFactory.CreateRuleRegionBoundary(sketch4, curves1, seedPoint1, 0.01)
    
    section1.AllowSelfIntersection(True)
    
    rules1 = [None] * 1 
    rules1[0] = regionBoundaryRule1
    helpPoint1 = NXOpen.Point3d(0.0, 0.0, 0.0)
    section1.AddToSection(rules1, NXOpen.NXObject.Null, NXOpen.NXObject.Null, NXOpen.NXObject.Null, helpPoint1, NXOpen.Section.Mode.Create, False)
    
    theSession.DeleteUndoMark(markId9, None)
    
    markId10 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId11 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    theSession.DeleteUndoMark(markId11, None)
    
    direction4 = workPart.Directions.CreateDirection(sketch4, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrudeBuilder1.Direction = direction4
    
    unit2 = extrudeBuilder1.Offset.StartOffset.Units
    
    expression6 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit2)
    
    theSession.DeleteUndoMark(markId10, None)
    
    rotMatrix14 = NXOpen.Matrix3x3()
    
    rotMatrix14.Xx = -0.73658201576114102
    rotMatrix14.Xy = 0.44769851701369967
    rotMatrix14.Xz = -0.50696446810500406
    rotMatrix14.Yx = -0.65263937905148617
    rotMatrix14.Yy = -0.27375616833956901
    rotMatrix14.Yz = 0.70648382940257803
    rotMatrix14.Zx = 0.17750711244496048
    rotMatrix14.Zy = 0.8512482588292174
    rotMatrix14.Zz = 0.4938295524486972
    translation14 = NXOpen.Point3d(0.0, 0.0, 0.0)
    modelingView1.SetRotationTranslationScale(rotMatrix14, translation14, 0.83317747687040644)
    
    extrudeBuilder1.Limits.EndExtend.Value.SetFormula("60")
    
    markId12 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    theSession.DeleteUndoMark(markId12, None)
    
    markId13 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    extrudeBuilder1.ParentFeatureInternal = False
    
    markId14 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    feature3 = extrudeBuilder1.CommitFeature()
    
    theSession.DeleteUndoMark(markId13, None)
    
    theSession.SetUndoMarkName(markId8, "Extrude")
    
    expression7 = extrudeBuilder1.Limits.StartExtend.Value
    expression8 = extrudeBuilder1.Limits.EndExtend.Value
    extrudeBuilder1.Destroy()
    
    workPart.Expressions.Delete(expression5)
    
    workPart.Expressions.Delete(expression6)
    
    rotMatrix15 = NXOpen.Matrix3x3()
    
    rotMatrix15.Xx = -0.24185992060961803
    rotMatrix15.Xy = 0.96559838274319676
    rotMatrix15.Xz = -0.095517234290122585
    rotMatrix15.Yx = -0.4858017716067749
    rotMatrix15.Yy = -0.03528940850551647
    rotMatrix15.Yz = 0.87335633984705918
    rotMatrix15.Zx = 0.83994072261465635
    rotMatrix15.Zy = 0.25763233665643787
    rotMatrix15.Zz = 0.47762449853678446
    translation15 = NXOpen.Point3d(0.0, 0.0, 0.0)
    modelingView1.SetRotationTranslationScale(rotMatrix15, translation15, 0.83317747687040644)
    
    rotMatrix16 = NXOpen.Matrix3x3()
    
    rotMatrix16.Xx = 0.21672343508932021
    rotMatrix16.Xy = 0.97479803166973167
    rotMatrix16.Xz = -0.052912665174838239
    rotMatrix16.Yx = 0.22603765656249614
    rotMatrix16.Yy = 0.0026214306330909938
    rotMatrix16.Yz = 0.97411503731190374
    rotMatrix16.Zx = 0.94970412787289848
    rotMatrix16.Zy = -0.2230738118969928
    rotMatrix16.Zz = -0.21977293724870894
    translation16 = NXOpen.Point3d(0.0, 0.0, 0.0)
    modelingView1.SetRotationTranslationScale(rotMatrix16, translation16, 0.83317747687040644)
    
    rotMatrix17 = NXOpen.Matrix3x3()
    
    rotMatrix17.Xx = 0.29752394738885596
    rotMatrix17.Xy = 0.95174455250656242
    rotMatrix17.Xz = -0.075244983249643099
    rotMatrix17.Yx = 0.3291622720671154
    rotMatrix17.Yy = -0.028278273145418791
    rotMatrix17.Yz = 0.94384984924273196
    rotMatrix17.Zx = 0.89617615421175434
    rotMatrix17.Zy = -0.30558574253717807
    rotMatrix17.Zz = -0.32169186278212597
    translation17 = NXOpen.Point3d(0.0, 0.0, 0.0)
    modelingView1.SetRotationTranslationScale(rotMatrix17, translation17, 0.83317747687040644)
    
    rotMatrix18 = NXOpen.Matrix3x3()
    
    rotMatrix18.Xx = 0.46431582344347189
    rotMatrix18.Xy = -0.14506501148931009
    rotMatrix18.Xz = 0.87370873781919822
    rotMatrix18.Yx = 0.86019431814748493
    rotMatrix18.Yy = 0.30876642736471027
    rotMatrix18.Yz = -0.40586824014601097
    rotMatrix18.Zx = -0.21089464461383653
    rotMatrix18.Zy = 0.94001033812083234
    rotMatrix18.Zz = 0.26814923661864848
    translation18 = NXOpen.Point3d(0.0, 0.0, 0.0)
    modelingView1.SetRotationTranslationScale(rotMatrix18, translation18, 0.83317747687040644)
    
    markId15 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Change Displayed Part")
    
    part2 = theSession.Parts.FindObject("four4")
    status2, partLoadStatus2 = theSession.Parts.SetActiveDisplay(part2, NXOpen.DisplayPartOption.AllowAdditional, NXOpen.PartDisplayPartWorkPartOption.UseLast)
    
    workPart = theSession.Parts.Work # four4
    displayPart = theSession.Parts.Display # four4
    partLoadStatus2.Dispose()
    rotMatrix19 = NXOpen.Matrix3x3()
    
    rotMatrix19.Xx = 0.80836546918854757
    rotMatrix19.Xy = -0.17669352887293976
    rotMatrix19.Xz = -0.5615377681670306
    rotMatrix19.Yx = 0.54324830296508064
    rotMatrix19.Yy = -0.14355566503338132
    rotMatrix19.Yz = 0.82720798615728008
    rotMatrix19.Zx = -0.22677422593658586
    rotMatrix19.Zy = -0.97374081145408042
    rotMatrix19.Zz = -0.020056982814247608
    translation19 = NXOpen.Point3d(-2.4907867293112256, -1.9658200077856218, 3.0845280330792968)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix19, translation19, 18.944262521254281)
    
    rotMatrix20 = NXOpen.Matrix3x3()
    
    rotMatrix20.Xx = 0.81626015839674593
    rotMatrix20.Xy = -0.14025730939965503
    rotMatrix20.Xz = -0.56039918002624822
    rotMatrix20.Yx = 0.52411350581521399
    rotMatrix20.Yy = -0.2281699257080716
    rotMatrix20.Yz = 0.82051417905143975
    rotMatrix20.Zx = -0.24294935035147408
    rotMatrix20.Zy = -0.96346581265883136
    rotMatrix20.Zz = -0.11273526955418249
    translation20 = NXOpen.Point3d(-2.604084128854145, -1.6985129829619949, 3.1490601006228265)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix20, translation20, 18.944262521254281)
    
    rotMatrix21 = NXOpen.Matrix3x3()
    
    rotMatrix21.Xx = 0.82676190236540548
    rotMatrix21.Xy = -0.10533497962734106
    rotMatrix21.Xz = -0.55260229719396392
    rotMatrix21.Yx = 0.47805934967540653
    rotMatrix21.Yy = -0.38621935566518428
    rotMatrix21.Yz = 0.78885604992133829
    rotMatrix21.Zx = -0.29651983910872082
    rotMatrix21.Zy = -0.91637282335110615
    rotMatrix21.Zz = -0.26895507736137081
    translation21 = NXOpen.Point3d(-2.7257114832489382, -1.154682019040919, 3.2893747682140626)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix21, translation21, 18.944262521254281)
    
    # ----------------------------------------------
    #   Menu: Analysis->Measure...
    # ----------------------------------------------
    markId16 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    theSession.SetUndoMarkName(markId16, "Measure Dialog")
    
    # User Function call - UF_PART_ask_part_name
    
    scCollector3 = workPart.ScCollectors.CreateCollector()
    
    scCollector3.SetMultiComponent()
    
    extrude1 = workPart.Features.FindObject("EXTRUDE(2)")
    face1 = extrude1.FindObject("FACE 140 {(3,0,-1.4) EXTRUDE(2)}")
    line1 = workPart.Lines.CreateFaceAxis(face1, NXOpen.SmartObject.UpdateOption.AfterModeling)
    
    line1.SetVisibility(NXOpen.SmartObject.VisibilityOption.Visible)
    
    edges1 = [NXOpen.Edge.Null] * 1 
    edge1 = extrude1.FindObject("EDGE * 130 * 140 {(6,-0.7,1.2124355652982)(6,1.4,-0)(6,-0.7,-1.2124355652982) EXTRUDE(2)}")
    edges1[0] = edge1
    edgeDumbRule1 = workPart.ScRuleFactory.CreateRuleEdgeDumb(edges1)
    
    rules2 = [None] * 1 
    rules2[0] = edgeDumbRule1
    scCollector3.ReplaceRules(rules2, False)
    
    scCollector4 = workPart.ScCollectors.CreateCollector()
    
    scCollector4.SetMultiComponent()
    
    faces1 = [NXOpen.Face.Null] * 1 
    face2 = extrude1.FindObject("FACE 120 {(0,0,0) EXTRUDE(2)}")
    faces1[0] = face2
    faceDumbRule1 = workPart.ScRuleFactory.CreateRuleFaceDumb(faces1)
    
    rules3 = [None] * 1 
    rules3[0] = faceDumbRule1
    scCollector4.ReplaceRules(rules3, False)
    
    scCollector5 = workPart.ScCollectors.CreateCollector()
    
    scCollector5.SetMultiComponent()
    
    rotMatrix22 = NXOpen.Matrix3x3()
    
    rotMatrix22.Xx = 0.86113389608530699
    rotMatrix22.Xy = 0.19811086203229047
    rotMatrix22.Xz = -0.46818852971614361
    rotMatrix22.Yx = 0.49647622694685584
    rotMatrix22.Yy = -0.12960959687236817
    rotMatrix22.Yz = 0.85831970062162544
    rotMatrix22.Zx = 0.10936072919267195
    rotMatrix22.Zy = -0.97157266261634068
    rotMatrix22.Zz = -0.20996855042373069
    translation22 = NXOpen.Point3d(-3.5723189611032589, -1.8297959690523204, 1.8636426622494615)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix22, translation22, 18.444413905917756)
    
    edges2 = [NXOpen.Edge.Null] * 1 
    edges2[0] = edge1
    edgeDumbRule2 = workPart.ScRuleFactory.CreateRuleEdgeDumb(edges2)
    
    rules4 = [None] * 1 
    rules4[0] = edgeDumbRule2
    scCollector5.ReplaceRules(rules4, False)
    
    scCollector6 = workPart.ScCollectors.CreateCollector()
    
    scCollector6.SetMultiComponent()
    
    rotMatrix23 = NXOpen.Matrix3x3()
    
    rotMatrix23.Xx = 0.85345184446965361
    rotMatrix23.Xy = 0.021348309295297793
    rotMatrix23.Xz = -0.52073428815623524
    rotMatrix23.Yx = 0.16134583922367549
    rotMatrix23.Yy = -0.96089716884242704
    rotMatrix23.Yz = 0.22504255392217734
    rotMatrix23.Zx = -0.49556782516276521
    rotMatrix23.Zy = -0.27608129346415505
    rotMatrix23.Zz = -0.82352392197349478
    translation23 = NXOpen.Point3d(-3.1248362122323963, 1.5168747114852776, 2.7417639900530046)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix23, translation23, 18.444413905917756)
    
    scCollector3.Destroy()
    
    scCollector4.Destroy()
    
    scCollector5.Destroy()
    
    scCollector6.Destroy()
    
    markId17 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Measurement Update")
    
    nErrs1 = theSession.UpdateManager.DoUpdate(markId17)
    
    theSession.DeleteUndoMark(markId17, "Measurement Update")
    
    objects1 = [NXOpen.TaggedObject.Null] * 1 
    objects1[0] = line1
    nErrs2 = theSession.UpdateManager.AddObjectsToDeleteList(objects1)
    
    theSession.UndoToMark(markId16, None)
    
    theSession.DeleteUndoMark(markId16, None)
    
    rotMatrix24 = NXOpen.Matrix3x3()
    
    rotMatrix24.Xx = 0.92151543481786957
    rotMatrix24.Xy = 0.099532513519486929
    rotMatrix24.Xz = -0.37536992706519168
    rotMatrix24.Yx = 0.30480259075645405
    rotMatrix24.Yy = -0.7843246820191907
    rotMatrix24.Yz = 0.54030563003141885
    rotMatrix24.Zx = -0.24063392125921346
    rotMatrix24.Zy = -0.61231370385447759
    rotMatrix24.Zz = -0.75310506837454472
    translation24 = NXOpen.Point3d(-3.6025916355213488, 0.48046293102630677, 2.5245334025032262)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix24, translation24, 18.944262521254281)
    
    # ----------------------------------------------
    #   Menu: Analysis->Measure...
    # ----------------------------------------------
    markId18 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    theSession.SetUndoMarkName(markId18, "Measure Dialog")
    
    # User Function call - UF_PART_ask_part_name
    
    scCollector7 = workPart.ScCollectors.CreateCollector()
    
    scCollector7.SetMultiComponent()
    
    line2 = workPart.Lines.CreateFaceAxis(face1, NXOpen.SmartObject.UpdateOption.AfterModeling)
    
    line2.SetVisibility(NXOpen.SmartObject.VisibilityOption.Visible)
    
    edges3 = [NXOpen.Edge.Null] * 1 
    edges3[0] = edge1
    edgeDumbRule3 = workPart.ScRuleFactory.CreateRuleEdgeDumb(edges3)
    
    rules5 = [None] * 1 
    rules5[0] = edgeDumbRule3
    scCollector7.ReplaceRules(rules5, False)
    
    scCollector8 = workPart.ScCollectors.CreateCollector()
    
    scCollector8.SetMultiComponent()
    
    edges4 = [NXOpen.Edge.Null] * 1 
    edge2 = extrude1.FindObject("EDGE * 120 * 140 {(0,-0.7,1.2124355652982)(0,1.4,-0)(0,-0.7,-1.2124355652982) EXTRUDE(2)}")
    edges4[0] = edge2
    edgeDumbRule4 = workPart.ScRuleFactory.CreateRuleEdgeDumb(edges4)
    
    rules6 = [None] * 1 
    rules6[0] = edgeDumbRule4
    scCollector8.ReplaceRules(rules6, False)
    
    scCollector9 = workPart.ScCollectors.CreateCollector()
    
    scCollector9.SetMultiComponent()
    
    rotMatrix25 = NXOpen.Matrix3x3()
    
    rotMatrix25.Xx = 0.93402414265655542
    rotMatrix25.Xy = 0.29525290623279771
    rotMatrix25.Xz = -0.20105875334283413
    rotMatrix25.Yx = 0.2087169805322191
    rotMatrix25.Yy = 0.0056921471270214713
    rotMatrix25.Yz = 0.97795951935578496
    rotMatrix25.Zx = 0.28988984627302827
    rotMatrix25.Zy = -0.95540217752639156
    rotMatrix25.Zz = -0.056307692242082874
    translation25 = NXOpen.Point3d(-4.1468017331508937, -1.0850804912458822, 1.0997343925816994)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix25, translation25, 18.444413905917756)
    
    rotMatrix26 = NXOpen.Matrix3x3()
    
    rotMatrix26.Xx = 0.97655089792332261
    rotMatrix26.Xy = -0.21489633668997279
    rotMatrix26.Xz = -0.012957941286394367
    rotMatrix26.Yx = 0.21286661270960669
    rotMatrix26.Yy = 0.97282225301597325
    rotMatrix26.Yz = -0.091129957919792143
    rotMatrix26.Zx = 0.032189267756350635
    rotMatrix26.Zy = 0.086234729164964191
    rotMatrix26.Zz = 0.99575469997743804
    translation26 = NXOpen.Point3d(-3.1982523341382585, -2.9976789481198569, -0.60653355385306007)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix26, translation26, 18.444413905917756)
    
    rotMatrix27 = NXOpen.Matrix3x3()
    
    rotMatrix27.Xx = 0.97830303761162662
    rotMatrix27.Xy = -0.2068757060022593
    rotMatrix27.Xz = 0.011207536122208936
    rotMatrix27.Yx = 0.19264962684847567
    rotMatrix27.Yy = 0.88846151717899624
    rotMatrix27.Yz = -0.41656002420676203
    rotMatrix27.Zx = 0.076218684553113217
    rotMatrix27.Zy = 0.40968106468088317
    rotMatrix27.Zz = 0.90903912862259839
    translation27 = NXOpen.Point3d(-3.2301657792382428, -2.6346362803170216, -1.4857660414231744)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix27, translation27, 18.444413905917756)
    
    markId19 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Measurement Update")
    
    nErrs3 = theSession.UpdateManager.DoUpdate(markId19)
    
    theSession.DeleteUndoMark(markId19, "Measurement Update")
    
    workPart.Features.SetEditWithRollbackFeature(NXOpen.Features.Feature.Null)
    
    scCollector7.Destroy()
    
    scCollector8.Destroy()
    
    scCollector9.Destroy()
    
    objects2 = [NXOpen.TaggedObject.Null] * 1 
    objects2[0] = line2
    nErrs4 = theSession.UpdateManager.AddObjectsToDeleteList(objects2)
    
    theSession.UndoToMark(markId18, None)
    
    theSession.DeleteUndoMark(markId18, None)
    
    rotMatrix28 = NXOpen.Matrix3x3()
    
    rotMatrix28.Xx = 0.57748776975910432
    rotMatrix28.Xy = -0.10218096186050027
    rotMatrix28.Xz = 0.8099795841945131
    rotMatrix28.Yx = -0.13738521651798413
    rotMatrix28.Yy = 0.96582437211700489
    rotMatrix28.Yz = 0.21979213932053926
    rotMatrix28.Zx = -0.80475659553740975
    rotMatrix28.Zy = -0.23820649289650944
    rotMatrix28.Zz = 0.54371360906361865
    translation28 = NXOpen.Point3d(-2.1846755135904519, -1.7474144910349332, 3.4287775544076187)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix28, translation28, 18.944262521254281)
    
    rotMatrix29 = NXOpen.Matrix3x3()
    
    rotMatrix29.Xx = 0.32750028766132638
    rotMatrix29.Xy = -0.16834587995894865
    rotMatrix29.Xz = 0.92973287899406609
    rotMatrix29.Yx = -0.21691574316591761
    rotMatrix29.Yy = 0.94432123090946851
    rotMatrix29.Yz = 0.24739638885885895
    rotMatrix29.Zx = -0.91961465948979182
    rotMatrix29.Zy = -0.28269608691043502
    rotMatrix29.Zz = 0.27274860310733606
    translation29 = NXOpen.Point3d(-1.1232137506020743, -1.4056521922853504, 4.0429336879982802)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix29, translation29, 18.944262521254281)
    
    # ----------------------------------------------
    #   Menu: Analysis->Measure...
    # ----------------------------------------------
    markId20 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    theSession.SetUndoMarkName(markId20, "Measure Dialog")
    
    # User Function call - UF_PART_ask_part_name
    
    scCollector10 = workPart.ScCollectors.CreateCollector()
    
    scCollector10.SetMultiComponent()
    
    line3 = workPart.Lines.CreateFaceAxis(face1, NXOpen.SmartObject.UpdateOption.AfterModeling)
    
    line3.SetVisibility(NXOpen.SmartObject.VisibilityOption.Visible)
    
    edges5 = [NXOpen.Edge.Null] * 1 
    edges5[0] = edge2
    edgeDumbRule5 = workPart.ScRuleFactory.CreateRuleEdgeDumb(edges5)
    
    rules7 = [None] * 1 
    rules7[0] = edgeDumbRule5
    scCollector10.ReplaceRules(rules7, False)
    
    scCollector11 = workPart.ScCollectors.CreateCollector()
    
    scCollector11.SetMultiComponent()
    
    markId21 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Measurement Update")
    
    nErrs5 = theSession.UpdateManager.DoUpdate(markId21)
    
    theSession.DeleteUndoMark(markId21, "Measurement Update")
    
    workPart.Features.SetEditWithRollbackFeature(NXOpen.Features.Feature.Null)
    
    scCollector10.Destroy()
    
    scCollector11.Destroy()
    
    objects3 = [NXOpen.TaggedObject.Null] * 1 
    objects3[0] = line3
    nErrs6 = theSession.UpdateManager.AddObjectsToDeleteList(objects3)
    
    theSession.UndoToMark(markId20, None)
    
    theSession.DeleteUndoMark(markId20, None)
    
    rotMatrix30 = NXOpen.Matrix3x3()
    
    rotMatrix30.Xx = 0.83256896524840385
    rotMatrix30.Xy = -0.055487273864643936
    rotMatrix30.Xz = 0.55113526519745515
    rotMatrix30.Yx = 0.12037559907656085
    rotMatrix30.Yy = 0.98931589742752468
    rotMatrix30.Yz = -0.082242143966023057
    rotMatrix30.Zx = -0.54068348712732117
    rotMatrix30.Zy = 0.13481549442196583
    rotMatrix30.Zz = 0.83035302685761547
    translation30 = NXOpen.Point3d(-3.1807336080401698, -2.6881782009091331, 1.4964664031008126)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix30, translation30, 18.944262521254281)
    
    markId22 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Change Displayed Part")
    
    status3, partLoadStatus3 = theSession.Parts.SetActiveDisplay(part1, NXOpen.DisplayPartOption.AllowAdditional, NXOpen.PartDisplayPartWorkPartOption.UseLast)
    
    workPart = theSession.Parts.Work # model1
    displayPart = theSession.Parts.Display # model1
    partLoadStatus3.Dispose()
    theSession.DeleteUndoMark(markId22, None)
    
    theSession.DeleteUndoMark(markId15, None)
    
    # ----------------------------------------------
    #   Menu: Tools->Journal->Pause Recording
    # ----------------------------------------------
    # ----------------------------------------------
    #   Menu: Tools->Journal->Stop Recording
    # ----------------------------------------------
    
if __name__ == '__main__':
    main()