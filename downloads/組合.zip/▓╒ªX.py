﻿# NX 1872
# Journal created by Admin on Fri Jun 14 16:55:30 2024 台北標準時間

#
import math
import NXOpen
import NXOpen.Assemblies
import NXOpen.Assemblies.ProductInterface
import NXOpen.Features
import NXOpen.GeometricUtilities
import NXOpen.PDM
import NXOpen.Positioning
import NXOpen.Preferences
def main() : 

    theSession  = NXOpen.Session.GetSession()
    workPart = theSession.Parts.Work
    displayPart = theSession.Parts.Display
    # ----------------------------------------------
    #   Menu: Tools->Movie->Record...
    # ----------------------------------------------
    theUI = NXOpen.UI.GetUI()
    
    theUI.MovieManager.Start("F:\\鹽+命\Sie\\Siemens_NX1872\\組合.avi", False)
    
    # ----------------------------------------------
    #   Menu: Assemblies->Components->Add Component...
    # ----------------------------------------------
    markId1 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    addComponentBuilder1 = workPart.AssemblyManager.CreateAddComponentBuilder()
    
    componentPositioner1 = workPart.ComponentAssembly.Positioner
    
    componentPositioner1.ClearNetwork()
    
    componentPositioner1.BeginAssemblyConstraints()
    
    allowInterpartPositioning1 = theSession.Preferences.Assemblies.InterpartPositioning
    
    expression1 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", NXOpen.Unit.Null)
    
    unit1 = workPart.UnitCollection.FindObject("MilliMeter")
    expression2 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", unit1)
    
    expression3 = workPart.Expressions.CreateSystemExpressionWithUnits("0.0", unit1)
    
    unit2 = workPart.UnitCollection.FindObject("Degrees")
    expression4 = workPart.Expressions.CreateSystemExpressionWithUnits("0.0", unit2)
    
    expression5 = workPart.Expressions.CreateSystemExpressionWithUnits("1", NXOpen.Unit.Null)
    
    expression6 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", unit1)
    
    expression7 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression8 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit2)
    
    network1 = componentPositioner1.EstablishNetwork()
    
    componentNetwork1 = network1
    componentNetwork1.MoveObjectsState = True
    
    componentNetwork1.DisplayComponent = NXOpen.Assemblies.Component.Null
    
    theSession.SetUndoMarkName(markId1, "Add Component Dialog")
    
    componentNetwork1.MoveObjectsState = True
    
    markId2 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Assembly Constraints Update")
    
    addComponentBuilder1.SetComponentAnchor(NXOpen.Assemblies.ProductInterface.InterfaceObject.Null)
    
    addComponentBuilder1.SetInitialLocationType(NXOpen.Assemblies.AddComponentBuilder.LocationType.Snap)
    
    addComponentBuilder1.SetCount(1)
    
    addComponentBuilder1.SetScatterOption(True)
    
    addComponentBuilder1.ReferenceSet = "Unknown"
    
    addComponentBuilder1.Layer = -1
    
    addComponentBuilder1.ReferenceSet = "Use Model"
    
    addComponentBuilder1.Layer = -1
    
    partstouse1 = [NXOpen.BasePart.Null] * 1 
    part1 = theSession.Parts.FindObject("model6")
    partstouse1[0] = part1
    addComponentBuilder1.SetPartsToAdd(partstouse1)
    
    productinterfaceobjects1 = addComponentBuilder1.GetAllProductInterfaceObjects()
    
    arrangement1 = workPart.ComponentAssembly.Arrangements.FindObject("Arrangement 1")
    componentPositioner1.PrimaryArrangement = arrangement1
    
    coordinates1 = NXOpen.Point3d(-599.66179391267622, -2316.2588085062894, 7.1054273576010019e-15)
    point1 = workPart.Points.CreatePoint(coordinates1)
    
    coordinates2 = NXOpen.Point3d(-599.66179391267622, -2316.2588085062894, 7.1054273576010019e-15)
    point2 = workPart.Points.CreatePoint(coordinates2)
    
    origin1 = NXOpen.Point3d(-599.66179391267622, -2316.2588085062894, 7.1054273576010019e-15)
    vector1 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    direction1 = workPart.Directions.CreateDirection(origin1, vector1, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    origin2 = NXOpen.Point3d(-599.66179391267622, -2316.2588085062894, 7.1054273576010019e-15)
    vector2 = NXOpen.Vector3d(1.0, 0.0, 0.0)
    direction2 = workPart.Directions.CreateDirection(origin2, vector2, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    origin3 = NXOpen.Point3d(-599.66179391267622, -2316.2588085062894, 7.1054273576010019e-15)
    matrix1 = NXOpen.Matrix3x3()
    
    matrix1.Xx = 1.0
    matrix1.Xy = 0.0
    matrix1.Xz = 0.0
    matrix1.Yx = 0.0
    matrix1.Yy = 1.0
    matrix1.Yz = 0.0
    matrix1.Zx = 0.0
    matrix1.Zy = 0.0
    matrix1.Zz = 1.0
    plane1 = workPart.Planes.CreateFixedTypePlane(origin3, matrix1, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    xform1 = workPart.Xforms.CreateXformByPlaneXDirPoint(plane1, direction2, point2, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem1 = workPart.CoordinateSystems.CreateCoordinateSystem(xform1, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    point3 = NXOpen.Point3d(-599.66179391267622, -2316.2588085062894, 7.1054273576010019e-15)
    orientation1 = NXOpen.Matrix3x3()
    
    orientation1.Xx = 1.0
    orientation1.Xy = 0.0
    orientation1.Xz = 0.0
    orientation1.Yx = 0.0
    orientation1.Yy = 1.0
    orientation1.Yz = 0.0
    orientation1.Zx = 0.0
    orientation1.Zy = 0.0
    orientation1.Zz = 1.0
    addComponentBuilder1.SetInitialLocationAndOrientation(point3, orientation1)
    
    movableObjects1 = [NXOpen.NXObject.Null] * 1 
    component1 = workPart.ComponentAssembly.RootComponent.FindObject("COMPONENT model6 1")
    movableObjects1[0] = component1
    componentNetwork1.SetMovingGroup(movableObjects1)
    
    scaleAboutPoint1 = NXOpen.Point3d(-122.57171285929442, 53.811971499202421, 0.0)
    viewCenter1 = NXOpen.Point3d(122.57171285929442, -53.811971499202421, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint1, viewCenter1)
    
    scaleAboutPoint2 = NXOpen.Point3d(-153.21464107411802, 67.264964374003029, 0.0)
    viewCenter2 = NXOpen.Point3d(153.21464107411802, -67.264964374003029, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint2, viewCenter2)
    
    scaleAboutPoint3 = NXOpen.Point3d(-191.5183013426475, 84.081205467503779, 0.0)
    viewCenter3 = NXOpen.Point3d(191.5183013426475, -84.081205467503779, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint3, viewCenter3)
    
    scaleAboutPoint4 = NXOpen.Point3d(-153.21464107411794, 67.264964374003014, 0.0)
    viewCenter4 = NXOpen.Point3d(153.21464107411794, -67.264964374003014, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint4, viewCenter4)
    
    scaleAboutPoint5 = NXOpen.Point3d(-122.57171285929439, 53.811971499202407, 0.0)
    viewCenter5 = NXOpen.Point3d(122.57171285929439, -53.811971499202407, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint5, viewCenter5)
    
    scaleAboutPoint6 = NXOpen.Point3d(-98.057370287435518, 43.049577199361927, 0.0)
    viewCenter6 = NXOpen.Point3d(98.057370287435518, -43.049577199361927, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint6, viewCenter6)
    
    scaleAboutPoint7 = NXOpen.Point3d(-78.445896229948403, 34.439661759489539, 0.0)
    viewCenter7 = NXOpen.Point3d(78.445896229948403, -34.439661759489539, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint7, viewCenter7)
    
    componentPositioner1.ClearNetwork()
    
    addComponentBuilder1.RemoveAddedComponents()
    
    addComponentBuilder1.Destroy()
    
    workPart.Points.DeletePoint(point1)
    
    componentPositioner1.PrimaryArrangement = NXOpen.Assemblies.Arrangement.Null
    
    componentPositioner1.EndAssemblyConstraints()
    
    theSession.DeleteUndoMark(markId2, None)
    
    theSession.UndoToMark(markId1, None)
    
    theSession.DeleteUndoMark(markId1, None)
    
    # ----------------------------------------------
    #   Menu: Assemblies->Components->Add Component...
    # ----------------------------------------------
    markId3 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    addComponentBuilder2 = workPart.AssemblyManager.CreateAddComponentBuilder()
    
    componentPositioner2 = workPart.ComponentAssembly.Positioner
    
    componentPositioner2.ClearNetwork()
    
    componentPositioner2.BeginAssemblyConstraints()
    
    allowInterpartPositioning2 = theSession.Preferences.Assemblies.InterpartPositioning
    
    expression9 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", NXOpen.Unit.Null)
    
    unit3 = workPart.UnitCollection.FindObject("MilliMeter")
    expression10 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", unit3)
    
    expression11 = workPart.Expressions.CreateSystemExpressionWithUnits("0.0", unit3)
    
    unit4 = workPart.UnitCollection.FindObject("Degrees")
    expression12 = workPart.Expressions.CreateSystemExpressionWithUnits("0.0", unit4)
    
    expression13 = workPart.Expressions.CreateSystemExpressionWithUnits("1", NXOpen.Unit.Null)
    
    expression14 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", unit3)
    
    expression15 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit3)
    
    expression16 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit4)
    
    network2 = componentPositioner2.EstablishNetwork()
    
    componentNetwork2 = network2
    componentNetwork2.MoveObjectsState = True
    
    componentNetwork2.DisplayComponent = NXOpen.Assemblies.Component.Null
    
    theSession.SetUndoMarkName(markId3, "Add Component Dialog")
    
    componentNetwork2.MoveObjectsState = True
    
    markId4 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Assembly Constraints Update")
    
    addComponentBuilder2.SetComponentAnchor(NXOpen.Assemblies.ProductInterface.InterfaceObject.Null)
    
    addComponentBuilder2.SetInitialLocationType(NXOpen.Assemblies.AddComponentBuilder.LocationType.Snap)
    
    addComponentBuilder2.SetCount(1)
    
    addComponentBuilder2.SetScatterOption(True)
    
    addComponentBuilder2.ReferenceSet = "Unknown"
    
    addComponentBuilder2.Layer = -1
    
    addComponentBuilder2.ReferenceSet = "Use Model"
    
    addComponentBuilder2.Layer = -1
    
    partstouse2 = [NXOpen.BasePart.Null] * 1 
    partstouse2[0] = part1
    addComponentBuilder2.SetPartsToAdd(partstouse2)
    
    productinterfaceobjects2 = addComponentBuilder2.GetAllProductInterfaceObjects()
    
    arrangement2 = workPart.ComponentAssembly.Arrangements.FindObject("Arrangement 1")
    componentPositioner2.PrimaryArrangement = arrangement2
    
    coordinates3 = NXOpen.Point3d(-58.192199462398627, -348.89957104519726, 0.0)
    point4 = workPart.Points.CreatePoint(coordinates3)
    
    coordinates4 = NXOpen.Point3d(-58.192199462398627, -348.89957104519726, 0.0)
    point5 = workPart.Points.CreatePoint(coordinates4)
    
    origin4 = NXOpen.Point3d(-58.192199462398627, -348.89957104519726, 0.0)
    vector3 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    direction3 = workPart.Directions.CreateDirection(origin4, vector3, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    origin5 = NXOpen.Point3d(-58.192199462398627, -348.89957104519726, 0.0)
    vector4 = NXOpen.Vector3d(1.0, 0.0, 0.0)
    direction4 = workPart.Directions.CreateDirection(origin5, vector4, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    origin6 = NXOpen.Point3d(-58.192199462398627, -348.89957104519726, 0.0)
    matrix2 = NXOpen.Matrix3x3()
    
    matrix2.Xx = 1.0
    matrix2.Xy = 0.0
    matrix2.Xz = 0.0
    matrix2.Yx = 0.0
    matrix2.Yy = 1.0
    matrix2.Yz = 0.0
    matrix2.Zx = 0.0
    matrix2.Zy = 0.0
    matrix2.Zz = 1.0
    plane2 = workPart.Planes.CreateFixedTypePlane(origin6, matrix2, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    xform2 = workPart.Xforms.CreateXformByPlaneXDirPoint(plane2, direction4, point5, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem2 = workPart.CoordinateSystems.CreateCoordinateSystem(xform2, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    point6 = NXOpen.Point3d(-58.192199462398627, -348.89957104519726, 0.0)
    orientation2 = NXOpen.Matrix3x3()
    
    orientation2.Xx = 1.0
    orientation2.Xy = 0.0
    orientation2.Xz = 0.0
    orientation2.Yx = 0.0
    orientation2.Yy = 1.0
    orientation2.Yz = 0.0
    orientation2.Zx = 0.0
    orientation2.Zy = 0.0
    orientation2.Zz = 1.0
    addComponentBuilder2.SetInitialLocationAndOrientation(point6, orientation2)
    
    movableObjects2 = [NXOpen.NXObject.Null] * 1 
    component2 = workPart.ComponentAssembly.RootComponent.FindObject("COMPONENT model6 1")
    movableObjects2[0] = component2
    componentNetwork2.SetMovingGroup(movableObjects2)
    
    rotMatrix1 = NXOpen.Matrix3x3()
    
    rotMatrix1.Xx = -0.81808018749841593
    rotMatrix1.Xy = 0.44680478021085102
    rotMatrix1.Xz = -0.36209155638221041
    rotMatrix1.Yx = -0.36239926382261578
    rotMatrix1.Yy = 0.088373049569348383
    rotMatrix1.Yz = 0.92782378590475834
    rotMatrix1.Zx = 0.44655523779638251
    rotMatrix1.Zy = 0.89025597020775316
    rotMatrix1.Zz = 0.089625482459338462
    translation1 = NXOpen.Point3d(145.70536700330791, 26.887807139366565, 78.706024561374591)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix1, translation1, 0.86428331404266312)
    
    componentNetwork2.EmptyMovingGroup()
    
    addComponentBuilder2.ReferenceSet = "Use Model"
    
    addComponentBuilder2.Layer = -1
    
    partstouse3 = [NXOpen.BasePart.Null] * 2 
    part2 = theSession.Parts.FindObject("model4")
    partstouse3[0] = part2
    partstouse3[1] = part1
    addComponentBuilder2.SetPartsToAdd(partstouse3)
    
    productinterfaceobjects3 = addComponentBuilder2.GetAllProductInterfaceObjects()
    
    movableObjects3 = [NXOpen.NXObject.Null] * 2 
    movableObjects3[0] = component2
    component3 = workPart.ComponentAssembly.RootComponent.FindObject("COMPONENT model4 1")
    movableObjects3[1] = component3
    componentNetwork2.SetMovingGroup(movableObjects3)
    
    markId5 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Transform Origin")
    
    loaded1 = componentNetwork2.IsReferencedGeometryLoaded()
    
    componentNetwork2.BeginDrag()
    
    translation2 = NXOpen.Vector3d(-101.67701634624082, 0.0, -92.931726411526469)
    componentNetwork2.DragByTranslation(translation2)
    
    componentNetwork2.EndDrag()
    
    componentNetwork2.ResetDisplay()
    
    componentNetwork2.ApplyToModel()
    
    rotMatrix2 = NXOpen.Matrix3x3()
    
    rotMatrix2.Xx = -0.80067315840351638
    rotMatrix2.Xy = 0.48494387699396369
    rotMatrix2.Xz = -0.35178392455910146
    rotMatrix2.Yx = -0.26436105112290947
    rotMatrix2.Yy = 0.24094256912405407
    rotMatrix2.Yz = 0.93384148174788695
    rotMatrix2.Zx = 0.53762043121642067
    rotMatrix2.Zy = 0.84069977670388674
    rotMatrix2.Zz = -0.06471597475667093
    translation3 = NXOpen.Point3d(160.37236499404978, 82.347152373712646, 46.786067730762966)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix2, translation3, 0.86428331404266312)
    
    scaleAboutPoint8 = NXOpen.Point3d(-2.14291228725711, -71.328366132987313, 0.0)
    viewCenter8 = NXOpen.Point3d(2.14291228725711, 71.328366132987313, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint8, viewCenter8)
    
    scaleAboutPoint9 = NXOpen.Point3d(-0.38266290843878353, -89.160457666234109, 0.0)
    viewCenter9 = NXOpen.Point3d(0.38266290843878353, 89.160457666234109, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint9, viewCenter9)
    
    rotMatrix3 = NXOpen.Matrix3x3()
    
    rotMatrix3.Xx = -0.62999172858274421
    rotMatrix3.Xy = 0.70062867809188678
    rotMatrix3.Xz = -0.33500727955156995
    rotMatrix3.Yx = -0.44457055311796001
    rotMatrix3.Yy = 0.028338440844772536
    rotMatrix3.Yz = 0.89529545741664329
    rotMatrix3.Zx = 0.63676325680563528
    rotMatrix3.Zy = 0.71296310437897414
    rotMatrix3.Zz = 0.29362589561647634
    translation4 = NXOpen.Point3d(236.65640782780085, -33.881922930361966, 6.0869740061306175)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix3, translation4, 0.5531413209873044)
    
    scaleAboutPoint10 = NXOpen.Point3d(88.490797576466107, -134.41034658911897, 0.0)
    viewCenter10 = NXOpen.Point3d(-88.490797576466107, 134.41034658911897, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint10, viewCenter10)
    
    scaleAboutPoint11 = NXOpen.Point3d(110.61349697058252, -168.01293323639871, 0.0)
    viewCenter11 = NXOpen.Point3d(-110.61349697058272, 168.01293323639871, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint11, viewCenter11)
    
    scaleAboutPoint12 = NXOpen.Point3d(138.26687121322826, -210.01616654549835, 0.0)
    viewCenter12 = NXOpen.Point3d(-138.26687121322826, 210.01616654549835, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint12, viewCenter12)
    
    rotMatrix4 = NXOpen.Matrix3x3()
    
    rotMatrix4.Xx = -0.63245668137378774
    rotMatrix4.Xy = 0.69130124264482795
    rotMatrix4.Xz = -0.34942973271227834
    rotMatrix4.Yx = -0.3534191361318807
    rotMatrix4.Yy = 0.14388414080036727
    rotMatrix4.Yz = 0.92433341833016802
    rotMatrix4.Zx = 0.68927023757119599
    rotMatrix4.Zy = 0.70809600051395427
    rotMatrix4.Zz = 0.15331860178951134
    translation5 = NXOpen.Point3d(316.77754644209887, -119.87591356014146, -5.1507411881664211)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix4, translation5, 0.2832083563454999)
    
    markId6 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Add Component")
    
    markId7 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "AddComponent on_apply")
    
    componentNetwork2.Solve()
    
    componentPositioner2.ClearNetwork()
    
    nErrs1 = theSession.UpdateManager.AddToDeleteList(componentNetwork2)
    
    nErrs2 = theSession.UpdateManager.DoUpdate(markId4)
    
    componentPositioner2.EndAssemblyConstraints()
    
    logicalobjects1 = addComponentBuilder2.GetLogicalObjectsHavingUnassignedRequiredAttributes()
    
    nXObject1 = addComponentBuilder2.Commit()
    
    errorList1 = addComponentBuilder2.GetOperationFailures()
    
    errorList1.Dispose()
    theSession.DeleteUndoMark(markId6, None)
    
    theSession.SetUndoMarkName(markId3, "Add Component")
    
    addComponentBuilder2.Destroy()
    
    workPart.Points.DeletePoint(point4)
    
    componentPositioner2.PrimaryArrangement = NXOpen.Assemblies.Arrangement.Null
    
    theSession.DeleteUndoMark(markId4, None)
    
    theSession.DeleteUndoMark(markId5, None)
    
    markId8 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    addComponentBuilder3 = workPart.AssemblyManager.CreateAddComponentBuilder()
    
    componentPositioner3 = workPart.ComponentAssembly.Positioner
    
    componentPositioner3.ClearNetwork()
    
    componentPositioner3.PrimaryArrangement = arrangement2
    
    componentPositioner3.BeginAssemblyConstraints()
    
    allowInterpartPositioning3 = theSession.Preferences.Assemblies.InterpartPositioning
    
    expression17 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", NXOpen.Unit.Null)
    
    expression18 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", unit3)
    
    expression19 = workPart.Expressions.CreateSystemExpressionWithUnits("0.0", unit3)
    
    expression20 = workPart.Expressions.CreateSystemExpressionWithUnits("0.0", unit4)
    
    expression21 = workPart.Expressions.CreateSystemExpressionWithUnits("1", NXOpen.Unit.Null)
    
    expression22 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", unit3)
    
    expression23 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit3)
    
    expression24 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit4)
    
    network3 = componentPositioner3.EstablishNetwork()
    
    componentNetwork3 = network3
    componentNetwork3.MoveObjectsState = True
    
    componentNetwork3.DisplayComponent = NXOpen.Assemblies.Component.Null
    
    theSession.SetUndoMarkName(markId8, "Add Component Dialog")
    
    componentNetwork3.MoveObjectsState = True
    
    markId9 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Assembly Constraints Update")
    
    addComponentBuilder3.SetComponentAnchor(NXOpen.Assemblies.ProductInterface.InterfaceObject.Null)
    
    addComponentBuilder3.SetInitialLocationType(NXOpen.Assemblies.AddComponentBuilder.LocationType.Snap)
    
    addComponentBuilder3.SetCount(1)
    
    addComponentBuilder3.SetScatterOption(True)
    
    addComponentBuilder3.ReferenceSet = "Unknown"
    
    addComponentBuilder3.Layer = -1
    
    # ----------------------------------------------
    #   Dialog Begin Add Component
    # ----------------------------------------------
    scaleAboutPoint13 = NXOpen.Point3d(145.74075614367311, -255.04632325142796, 0.0)
    viewCenter13 = NXOpen.Point3d(-145.74075614367311, 255.04632325142796, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint13, viewCenter13)
    
    origin7 = NXOpen.Point3d(33.286195510378334, -14.771909742773696, -47.825328464505496)
    workPart.ModelingViews.WorkView.SetOrigin(origin7)
    
    origin8 = NXOpen.Point3d(33.286195510378334, -14.771909742773696, -47.825328464505496)
    workPart.ModelingViews.WorkView.SetOrigin(origin8)
    
    rotMatrix5 = NXOpen.Matrix3x3()
    
    rotMatrix5.Xx = -0.53601681910742505
    rotMatrix5.Xy = 0.77911124277879185
    rotMatrix5.Xz = -0.32507174747991674
    rotMatrix5.Yx = -0.43051788767171117
    rotMatrix5.Yy = 0.078954527396797952
    rotMatrix5.Yz = 0.89912208903921076
    rotMatrix5.Zx = 0.72618201439353236
    rotMatrix5.Zy = 0.62189376422282616
    rotMatrix5.Zz = 0.293100371873045
    translation6 = NXOpen.Point3d(45.089828545003485, 35.528971052563747, -35.434632710082838)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix5, translation6, 0.22656668507639993)
    
    addComponentBuilder3.ReferenceSet = "Use Model"
    
    addComponentBuilder3.Layer = -1
    
    partstouse4 = [NXOpen.BasePart.Null] * 1 
    partstouse4[0] = part2
    addComponentBuilder3.SetPartsToAdd(partstouse4)
    
    productinterfaceobjects4 = addComponentBuilder3.GetAllProductInterfaceObjects()
    
    coordinates5 = NXOpen.Point3d(185.48838681395085, 117.70397621465045, 0.0)
    point7 = workPart.Points.CreatePoint(coordinates5)
    
    coordinates6 = NXOpen.Point3d(185.48838681395085, 117.70397621465045, 0.0)
    point8 = workPart.Points.CreatePoint(coordinates6)
    
    origin9 = NXOpen.Point3d(185.48838681395085, 117.70397621465045, 0.0)
    vector5 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    direction5 = workPart.Directions.CreateDirection(origin9, vector5, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    origin10 = NXOpen.Point3d(185.48838681395085, 117.70397621465045, 0.0)
    vector6 = NXOpen.Vector3d(1.0, 0.0, 0.0)
    direction6 = workPart.Directions.CreateDirection(origin10, vector6, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    origin11 = NXOpen.Point3d(185.48838681395085, 117.70397621465045, 0.0)
    matrix3 = NXOpen.Matrix3x3()
    
    matrix3.Xx = 1.0
    matrix3.Xy = 0.0
    matrix3.Xz = 0.0
    matrix3.Yx = 0.0
    matrix3.Yy = 1.0
    matrix3.Yz = 0.0
    matrix3.Zx = 0.0
    matrix3.Zy = 0.0
    matrix3.Zz = 1.0
    plane3 = workPart.Planes.CreateFixedTypePlane(origin11, matrix3, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    xform3 = workPart.Xforms.CreateXformByPlaneXDirPoint(plane3, direction6, point8, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem3 = workPart.CoordinateSystems.CreateCoordinateSystem(xform3, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    point9 = NXOpen.Point3d(185.48838681395085, 117.70397621465045, 0.0)
    orientation3 = NXOpen.Matrix3x3()
    
    orientation3.Xx = 1.0
    orientation3.Xy = 0.0
    orientation3.Xz = 0.0
    orientation3.Yx = 0.0
    orientation3.Yy = 1.0
    orientation3.Yz = 0.0
    orientation3.Zx = 0.0
    orientation3.Zy = 0.0
    orientation3.Zz = 1.0
    addComponentBuilder3.SetInitialLocationAndOrientation(point9, orientation3)
    
    movableObjects4 = [NXOpen.NXObject.Null] * 1 
    component4 = workPart.ComponentAssembly.RootComponent.FindObject("COMPONENT model4 1")
    movableObjects4[0] = component4
    componentNetwork3.SetMovingGroup(movableObjects4)
    
    markId10 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Transform Origin")
    
    loaded2 = componentNetwork3.IsReferencedGeometryLoaded()
    
    componentNetwork3.BeginDrag()
    
    translation7 = NXOpen.Vector3d(1.4210854715202004e-14, 236.19205899068388, -214.45718557290633)
    componentNetwork3.DragByTranslation(translation7)
    
    componentNetwork3.EndDrag()
    
    componentNetwork3.ResetDisplay()
    
    componentNetwork3.ApplyToModel()
    
    markId11 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Add Component")
    
    theSession.DeleteUndoMark(markId11, None)
    
    markId12 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Add Component")
    
    markId13 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "AddComponent on_apply")
    
    componentNetwork3.Solve()
    
    componentPositioner3.ClearNetwork()
    
    nErrs3 = theSession.UpdateManager.AddToDeleteList(componentNetwork3)
    
    nErrs4 = theSession.UpdateManager.DoUpdate(markId9)
    
    componentPositioner3.EndAssemblyConstraints()
    
    logicalobjects2 = addComponentBuilder3.GetLogicalObjectsHavingUnassignedRequiredAttributes()
    
    addComponentBuilder3.ComponentName = "MODEL4"
    
    nXObject2 = addComponentBuilder3.Commit()
    
    errorList2 = addComponentBuilder3.GetOperationFailures()
    
    errorList2.Dispose()
    theSession.DeleteUndoMark(markId12, None)
    
    theSession.SetUndoMarkName(markId8, "Add Component")
    
    addComponentBuilder3.Destroy()
    
    workPart.Points.DeletePoint(point7)
    
    componentPositioner3.PrimaryArrangement = NXOpen.Assemblies.Arrangement.Null
    
    theSession.DeleteUndoMark(markId9, None)
    
    theSession.DeleteUndoMark(markId10, None)
    
    rotMatrix6 = NXOpen.Matrix3x3()
    
    rotMatrix6.Xx = -0.89159408661761252
    rotMatrix6.Xy = 0.21535386813896645
    rotMatrix6.Xz = -0.39834996697137448
    rotMatrix6.Yx = -0.42956942777371115
    rotMatrix6.Yy = -0.12388564039182297
    rotMatrix6.Yz = 0.89449564270983084
    rotMatrix6.Zx = 0.14328325593270314
    rotMatrix6.Zy = 0.96864599291087594
    rotMatrix6.Zz = 0.20296514229549512
    translation8 = NXOpen.Point3d(31.149610528469815, 25.351328658474387, 5.2444507058463898)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix6, translation8, 0.22656668507639993)
    
    scaleAboutPoint14 = NXOpen.Point3d(-52.550753417189817, 3.5033835611459878, 0.0)
    viewCenter14 = NXOpen.Point3d(52.550753417190016, -3.5033835611459878, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint14, viewCenter14)
    
    scaleAboutPoint15 = NXOpen.Point3d(-65.688441771487021, 4.3792294514324848, 0.0)
    viewCenter15 = NXOpen.Point3d(65.688441771487518, -4.3792294514324848, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint15, viewCenter15)
    
    scaleAboutPoint16 = NXOpen.Point3d(-82.110552214358776, 5.4740368142906055, 0.0)
    viewCenter16 = NXOpen.Point3d(82.110552214359089, -5.4740368142906055, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint16, viewCenter16)
    
    scaleAboutPoint17 = NXOpen.Point3d(-18.246789380968426, 18.246789380969204, 0.0)
    viewCenter17 = NXOpen.Point3d(18.246789380968814, -18.246789380969204, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint17, viewCenter17)
    
    scaleAboutPoint18 = NXOpen.Point3d(-14.597431504774741, 14.597431504775363, 0.0)
    viewCenter18 = NXOpen.Point3d(14.597431504775052, -14.597431504775363, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint18, viewCenter18)
    
    scaleAboutPoint19 = NXOpen.Point3d(-11.677945203819791, 11.67794520382029, 0.0)
    viewCenter19 = NXOpen.Point3d(11.67794520382029, -11.67794520382029, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint19, viewCenter19)
    
    scaleAboutPoint20 = NXOpen.Point3d(-9.3423561630558325, 9.3423561630562304, 0.0)
    viewCenter20 = NXOpen.Point3d(9.3423561630562304, -9.3423561630562304, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint20, viewCenter20)
    
    scaleAboutPoint21 = NXOpen.Point3d(-6.5396493141389627, 7.4738849304449841, 0.0)
    viewCenter21 = NXOpen.Point3d(6.5396493141393615, -7.4738849304449841, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint21, viewCenter21)
    
    scaleAboutPoint22 = NXOpen.Point3d(-5.2317194513111716, 5.9791079443559889, 0.0)
    viewCenter22 = NXOpen.Point3d(5.2317194513115535, -5.9791079443559889, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint22, viewCenter22)
    
    scaleAboutPoint23 = NXOpen.Point3d(-4.1853755610488852, 4.7832863554847895, 0.0)
    viewCenter23 = NXOpen.Point3d(4.185375561049395, -4.7832863554847895, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint23, viewCenter23)
    
    scaleAboutPoint24 = NXOpen.Point3d(-3.3483004488390677, 3.8266290843878323, 0.0)
    viewCenter24 = NXOpen.Point3d(3.3483004488394754, -3.8266290843878323, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint24, viewCenter24)
    
    scaleAboutPoint25 = NXOpen.Point3d(-2.6786403590711889, 3.061303267510135, 0.0)
    viewCenter25 = NXOpen.Point3d(2.678640359071613, -3.0613032675103962, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint25, viewCenter25)
    
    scaleAboutPoint26 = NXOpen.Point3d(-24.184295813330159, -2.7551729407592651, 0.0)
    viewCenter26 = NXOpen.Point3d(24.184295813330678, 2.7551729407590564, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint26, viewCenter26)
    
    scaleAboutPoint27 = NXOpen.Point3d(-19.592340912064905, -2.2041383526074121, 0.0)
    viewCenter27 = NXOpen.Point3d(19.592340912065406, 2.2041383526072447, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint27, viewCenter27)
    
    rotMatrix7 = NXOpen.Matrix3x3()
    
    rotMatrix7.Xx = -0.54790633994082893
    rotMatrix7.Xy = 0.81218053759072673
    rotMatrix7.Xz = -0.20040313623166717
    rotMatrix7.Yx = -0.36609862794424236
    rotMatrix7.Yy = -0.01739760163222134
    rotMatrix7.Yz = 0.93041341245426401
    rotMatrix7.Zx = 0.75217713157872157
    rotMatrix7.Zy = 0.58314672065980899
    rotMatrix7.Zz = 0.30687043668904063
    translation9 = NXOpen.Point3d(315.35809207490553, 69.446962414461865, -123.76415040685313)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix7, translation9, 1.3504426781916621)
    
    rotMatrix8 = NXOpen.Matrix3x3()
    
    rotMatrix8.Xx = -0.88734814141520146
    rotMatrix8.Xy = 0.3077176339882477
    rotMatrix8.Xz = -0.34339937923599806
    rotMatrix8.Yx = -0.36609862794424236
    rotMatrix8.Yy = -0.01739760163222134
    rotMatrix8.Yz = 0.93041341245426401
    rotMatrix8.Zx = 0.28033028831065837
    rotMatrix8.Zy = 0.95131865386427006
    rotMatrix8.Zz = 0.12809273307077915
    translation10 = NXOpen.Point3d(52.811094483902608, 69.446962414461865, -2.7267520061058974)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix8, translation10, 1.3504426781916621)
    
    scaleAboutPoint28 = NXOpen.Point3d(-3.1347745459301444, -5.0940086371370485, 0.0)
    viewCenter28 = NXOpen.Point3d(3.1347745459307124, 5.0940086371369144, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint28, viewCenter28)
    
    scaleAboutPoint29 = NXOpen.Point3d(-3.9184681824127638, -6.3675107964213105, 0.0)
    viewCenter29 = NXOpen.Point3d(3.9184681824133065, 6.3675107964211426, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint29, viewCenter29)
    
    scaleAboutPoint30 = NXOpen.Point3d(-4.8980852280160585, -7.9593884955266372, 0.0)
    viewCenter30 = NXOpen.Point3d(4.8980852280166332, 7.9593884955264285, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint30, viewCenter30)
    
    rotMatrix9 = NXOpen.Matrix3x3()
    
    rotMatrix9.Xx = -0.76470704595632866
    rotMatrix9.Xy = 0.55802180290877401
    rotMatrix9.Xz = -0.32223407849449004
    rotMatrix9.Yx = -0.54123194051368961
    rotMatrix9.Yy = -0.28483599871707238
    rotMatrix9.Yz = 0.79116145027588025
    rotMatrix9.Zx = 0.34970147330621482
    rotMatrix9.Zy = 0.77941011111820635
    rotMatrix9.Zz = 0.51983531839821395
    translation11 = NXOpen.Point3d(56.851814702091076, 47.340763299653901, 26.377413466122579)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix9, translation11, 0.69142665123413105)
    
    scaleAboutPoint31 = NXOpen.Point3d(-122.06946779196811, 62.756716983958611, 0.0)
    viewCenter31 = NXOpen.Point3d(122.06946779196869, -62.756716983958476, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint31, viewCenter31)
    
    scaleAboutPoint32 = NXOpen.Point3d(-152.58683473996018, 78.445896229948261, 0.0)
    viewCenter32 = NXOpen.Point3d(152.58683473996075, -78.445896229948104, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint32, viewCenter32)
    
    scaleAboutPoint33 = NXOpen.Point3d(-190.73354342495028, 98.057370287435333, 0.0)
    viewCenter33 = NXOpen.Point3d(190.73354342495088, -98.057370287435134, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint33, viewCenter33)
    
    scaleAboutPoint34 = NXOpen.Point3d(-238.41692928118798, 122.57171285929418, 0.0)
    viewCenter34 = NXOpen.Point3d(238.41692928118849, -122.57171285929392, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint34, viewCenter34)
    
    rotMatrix10 = NXOpen.Matrix3x3()
    
    rotMatrix10.Xx = -0.019654474490964975
    rotMatrix10.Xy = 0.99975444294989424
    rotMatrix10.Xz = 0.010235010231385639
    rotMatrix10.Yx = -0.2193626568598584
    rotMatrix10.Yy = -0.014299616592028642
    rotMatrix10.Yz = 0.97553859264546972
    rotMatrix10.Zx = 0.97544539898852067
    rotMatrix10.Zy = 0.01692851934675765
    rotMatrix10.Zz = 0.21958984226247619
    translation12 = NXOpen.Point3d(-106.16413631224162, 151.46706746340564, -77.665070810856577)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix10, translation12, 0.28320835634550007)
    
    scaleAboutPoint35 = NXOpen.Point3d(-394.24743008096164, 203.66336435461992, 0.0)
    viewCenter35 = NXOpen.Point3d(394.24743008096175, -203.6633643546196, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint35, viewCenter35)
    
    scaleAboutPoint36 = NXOpen.Point3d(-315.39794406476915, 162.93069148369594, 0.0)
    viewCenter36 = NXOpen.Point3d(315.39794406476966, -162.93069148369568, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint36, viewCenter36)
    
    scaleAboutPoint37 = NXOpen.Point3d(-252.31835525181532, 130.34455318695672, 0.0)
    viewCenter37 = NXOpen.Point3d(252.31835525181563, -130.34455318695652, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint37, viewCenter37)
    
    scaleAboutPoint38 = NXOpen.Point3d(-275.99562271146436, 88.969126212014572, 0.0)
    viewCenter38 = NXOpen.Point3d(275.9956227114647, -88.969126212014572, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint38, viewCenter38)
    
    scaleAboutPoint39 = NXOpen.Point3d(-344.99452838933047, 111.21140776501819, 0.0)
    viewCenter39 = NXOpen.Point3d(344.99452838933098, -111.21140776501819, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint39, viewCenter39)
    
    scaleAboutPoint40 = NXOpen.Point3d(-431.24316048666327, 139.01425970627278, 0.0)
    viewCenter40 = NXOpen.Point3d(431.24316048666361, -139.01425970627278, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint40, viewCenter40)
    
    rotMatrix11 = NXOpen.Matrix3x3()
    
    rotMatrix11.Xx = 0.9537840787670343
    rotMatrix11.Xy = -0.18204262828530723
    rotMatrix11.Xz = 0.23907407341137052
    rotMatrix11.Yx = -0.24482551119632678
    rotMatrix11.Yy = -0.0094667646786062189
    rotMatrix11.Yz = 0.96952093811014428
    rotMatrix11.Zx = -0.17423088175746662
    rotMatrix11.Zy = -0.98324506703746184
    rotMatrix11.Zz = -0.0535979289573617
    translation13 = NXOpen.Point3d(-265.14137215882226, 137.94586693426209, -87.483366099151965)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix11, translation13, 0.28320835634550007)
    
    scaleAboutPoint41 = NXOpen.Point3d(-348.46988488198747, 152.28040545781238, 0.0)
    viewCenter41 = NXOpen.Point3d(348.46988488198781, -152.28040545781269, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint41, viewCenter41)
    
    scaleAboutPoint42 = NXOpen.Point3d(-278.77590790558992, 121.8243243662499, 0.0)
    viewCenter42 = NXOpen.Point3d(278.7759079055902, -121.82432436625014, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint42, viewCenter42)
    
    scaleAboutPoint43 = NXOpen.Point3d(-223.02072632447187, 97.459459492999926, 0.0)
    viewCenter43 = NXOpen.Point3d(223.02072632447218, -97.459459493000125, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint43, viewCenter43)
    
    rotMatrix12 = NXOpen.Matrix3x3()
    
    rotMatrix12.Xx = 0.96785679846853589
    rotMatrix12.Xy = -0.061754880507627744
    rotMatrix12.Xz = 0.2438022813505504
    rotMatrix12.Yx = -0.24414432613735104
    rotMatrix12.Yy = 0.0020610199959476792
    rotMatrix12.Yz = 0.96973671695543839
    rotMatrix12.Zx = -0.060388456456363634
    rotMatrix12.Zy = -0.99808921792095839
    rotMatrix12.Zz = -0.013082331472369514
    translation14 = NXOpen.Point3d(-89.68968788138092, 64.163968300499533, -90.501926354050056)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix12, translation14, 0.55314132098730484)
    
    # ----------------------------------------------
    #   Menu: Insert->Synchronous Modeling->Move Face...
    # ----------------------------------------------
    markId14 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    admMoveFaceBuilder1 = workPart.Features.CreateAdmMoveFaceBuilder(NXOpen.Features.AdmMoveFace.Null)
    
    admMoveFaceBuilder1.FaceToMove.RelationScope = 511
    
    admMoveFaceBuilder1.Motion.DistanceAngle.OrientXpress.AxisOption = NXOpen.GeometricUtilities.OrientXpressBuilder.Axis.Passive
    
    admMoveFaceBuilder1.Motion.DistanceAngle.OrientXpress.PlaneOption = NXOpen.GeometricUtilities.OrientXpressBuilder.Plane.Passive
    
    admMoveFaceBuilder1.Motion.AlongCurveAngle.AlongCurve.IsPercentUsed = True
    
    admMoveFaceBuilder1.Motion.AlongCurveAngle.AlongCurve.Expression.SetFormula("0")
    
    admMoveFaceBuilder1.Motion.AlongCurveAngle.AlongCurve.Expression.SetFormula("0")
    
    admMoveFaceBuilder1.Motion.OrientXpress.AxisOption = NXOpen.GeometricUtilities.OrientXpressBuilder.Axis.Passive
    
    admMoveFaceBuilder1.Motion.OrientXpress.PlaneOption = NXOpen.GeometricUtilities.OrientXpressBuilder.Plane.Passive
    
    admMoveFaceBuilder1.Motion.DeltaEnum = NXOpen.GeometricUtilities.ModlMotion.Delta.ReferenceAcsWorkPart
    
    theSession.SetUndoMarkName(markId14, "Move Face Dialog")
    
    rotMatrix13 = NXOpen.Matrix3x3()
    
    rotMatrix13.Xx = 0.95601504831638595
    rotMatrix13.Xy = -0.16493526209628476
    rotMatrix13.Xz = 0.24255223501311288
    rotMatrix13.Yx = -0.22864052318316869
    rotMatrix13.Yy = 0.098951165531799667
    rotMatrix13.Yz = 0.96846898659607183
    rotMatrix13.Zx = -0.18373551249323705
    rotMatrix13.Zy = -0.98132819492621015
    rotMatrix13.Zz = 0.056887918679797998
    translation15 = NXOpen.Point3d(-94.03791816895621, 67.73632182886891, -75.19979777274591)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix13, translation15, 0.55314132098730484)
    
    admMoveFaceBuilder1.Destroy()
    
    theSession.UndoToMark(markId14, None)
    
    theSession.DeleteUndoMark(markId14, None)
    
    # ----------------------------------------------
    #   Menu: Insert->Synchronous Modeling->Move Face...
    # ----------------------------------------------
    markId15 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    admMoveFaceBuilder2 = workPart.Features.CreateAdmMoveFaceBuilder(NXOpen.Features.AdmMoveFace.Null)
    
    admMoveFaceBuilder2.FaceToMove.RelationScope = 511
    
    admMoveFaceBuilder2.Motion.DistanceAngle.OrientXpress.AxisOption = NXOpen.GeometricUtilities.OrientXpressBuilder.Axis.Passive
    
    admMoveFaceBuilder2.Motion.DistanceAngle.OrientXpress.PlaneOption = NXOpen.GeometricUtilities.OrientXpressBuilder.Plane.Passive
    
    admMoveFaceBuilder2.Motion.AlongCurveAngle.AlongCurve.IsPercentUsed = True
    
    admMoveFaceBuilder2.Motion.AlongCurveAngle.AlongCurve.Expression.SetFormula("0")
    
    admMoveFaceBuilder2.Motion.AlongCurveAngle.AlongCurve.Expression.SetFormula("0")
    
    admMoveFaceBuilder2.Motion.OrientXpress.AxisOption = NXOpen.GeometricUtilities.OrientXpressBuilder.Axis.Passive
    
    admMoveFaceBuilder2.Motion.OrientXpress.PlaneOption = NXOpen.GeometricUtilities.OrientXpressBuilder.Plane.Passive
    
    admMoveFaceBuilder2.Motion.DeltaEnum = NXOpen.GeometricUtilities.ModlMotion.Delta.ReferenceAcsWorkPart
    
    theSession.SetUndoMarkName(markId15, "Move Face Dialog")
    
    admMoveFaceBuilder2.Destroy()
    
    theSession.UndoToMark(markId15, None)
    
    theSession.DeleteUndoMark(markId15, None)
    
    # ----------------------------------------------
    #   Menu: Assemblies->Component Position->Assembly Constraints...
    # ----------------------------------------------
    markId16 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Constraints with Positioning Task")
    
    markId17 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    componentPositioner4 = workPart.ComponentAssembly.Positioner
    
    componentPositioner4.ClearNetwork()
    
    componentPositioner4.PrimaryArrangement = arrangement2
    
    componentPositioner4.BeginAssemblyConstraints()
    
    allowInterpartPositioning4 = theSession.Preferences.Assemblies.InterpartPositioning
    
    expression25 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", NXOpen.Unit.Null)
    
    expression26 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", unit3)
    
    expression27 = workPart.Expressions.CreateSystemExpressionWithUnits("0.0", unit3)
    
    expression28 = workPart.Expressions.CreateSystemExpressionWithUnits("0.0", unit4)
    
    expression29 = workPart.Expressions.CreateSystemExpressionWithUnits("1", NXOpen.Unit.Null)
    
    expression30 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", unit3)
    
    expression31 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit3)
    
    expression32 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit4)
    
    network4 = componentPositioner4.EstablishNetwork()
    
    componentNetwork4 = network4
    componentNetwork4.MoveObjectsState = True
    
    componentNetwork4.DisplayComponent = NXOpen.Assemblies.Component.Null
    
    componentNetwork4.NetworkArrangementsMode = NXOpen.Positioning.ComponentNetwork.ArrangementsMode.Existing
    
    theSession.SetUndoMarkName(markId17, "Assembly Constraints Dialog")
    
    componentNetwork4.MoveObjectsState = True
    
    componentNetwork4.NetworkArrangementsMode = NXOpen.Positioning.ComponentNetwork.ArrangementsMode.Existing
    
    markId18 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Assembly Constraints Update")
    
    component5 = nXObject2
    face1 = component5.FindObject("PROTO#.Features|EXTRUDE(4)|FACE 140 {(-80,-0.1672952755923,8.1078093530407) EXTRUDE(2)}")
    line1 = workPart.Lines.CreateFaceAxis(face1, NXOpen.SmartObject.UpdateOption.AfterModeling)
    
    line1.SetVisibility(NXOpen.SmartObject.VisibilityOption.Visible)
    
    component6 = nXObject1
    face2 = component6.FindObject("PROTO#.Features|EXTRUDE(8)|FACE 140 {(20.1928085054608,-70,10) EXTRUDE(2)}")
    line2 = workPart.Lines.CreateFaceAxis(face2, NXOpen.SmartObject.UpdateOption.AfterModeling)
    
    line2.SetVisibility(NXOpen.SmartObject.VisibilityOption.Visible)
    
    markId19 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constraint")
    
    constraint1 = componentPositioner4.CreateConstraint(True)
    
    componentConstraint1 = constraint1
    componentConstraint1.ConstraintType = NXOpen.Positioning.Constraint.Type.Distance
    
    constraintReference1 = componentConstraint1.CreateConstraintReference(component5, face1, True, False, False)
    
    helpPoint1 = NXOpen.Point3d(126.40249190829635, 353.72873992974417, -216.34937621986498)
    constraintReference1.HelpPoint = helpPoint1
    
    constraintReference2 = componentConstraint1.CreateConstraintReference(component6, face2, False, False, False)
    
    helpPoint2 = NXOpen.Point3d(-129.67856663729216, -437.53131576320413, -73.139529219420055)
    constraintReference2.HelpPoint = helpPoint2
    
    constraintReference2.SetFixHint(True)
    
    componentConstraint1.SetExpression("0")
    
    componentConstraint1.SetExpression("133.417649808339")
    
    objects1 = [NXOpen.TaggedObject.Null] * 1 
    objects1[0] = line2
    nErrs5 = theSession.UpdateManager.AddObjectsToDeleteList(objects1)
    
    objects2 = [NXOpen.TaggedObject.Null] * 1 
    objects2[0] = line1
    nErrs6 = theSession.UpdateManager.AddObjectsToDeleteList(objects2)
    
    componentNetwork4.Solve()
    
    line3 = workPart.Lines.CreateFaceAxis(face2, NXOpen.SmartObject.UpdateOption.AfterModeling)
    
    line3.SetVisibility(NXOpen.SmartObject.VisibilityOption.Visible)
    
    objects3 = [NXOpen.TaggedObject.Null] * 1 
    objects3[0] = line3
    nErrs7 = theSession.UpdateManager.AddObjectsToDeleteList(objects3)
    
    markId20 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Assembly Constraints")
    
    nErrs8 = theSession.UpdateManager.DoUpdate(markId18)
    
    componentNetwork4.Solve()
    
    componentPositioner4.ClearNetwork()
    
    nErrs9 = theSession.UpdateManager.AddToDeleteList(componentNetwork4)
    
    componentPositioner4.DeleteNonPersistentConstraints()
    
    nErrs10 = theSession.UpdateManager.DoUpdate(markId18)
    
    theSession.DeleteUndoMark(markId20, None)
    
    theSession.SetUndoMarkName(markId17, "Assembly Constraints")
    
    componentPositioner4.PrimaryArrangement = NXOpen.Assemblies.Arrangement.Null
    
    componentPositioner4.EndAssemblyConstraints()
    
    theSession.DeleteUndoMark(markId18, None)
    
    theSession.DeleteUndoMark(markId19, None)
    
    markId21 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    componentPositioner5 = workPart.ComponentAssembly.Positioner
    
    componentPositioner5.ClearNetwork()
    
    componentPositioner5.PrimaryArrangement = arrangement2
    
    componentPositioner5.BeginAssemblyConstraints()
    
    allowInterpartPositioning5 = theSession.Preferences.Assemblies.InterpartPositioning
    
    expression33 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", NXOpen.Unit.Null)
    
    expression34 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", unit3)
    
    expression35 = workPart.Expressions.CreateSystemExpressionWithUnits("0.0", unit3)
    
    expression36 = workPart.Expressions.CreateSystemExpressionWithUnits("0.0", unit4)
    
    expression37 = workPart.Expressions.CreateSystemExpressionWithUnits("1", NXOpen.Unit.Null)
    
    expression38 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", unit3)
    
    expression39 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit3)
    
    expression40 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit4)
    
    network5 = componentPositioner5.EstablishNetwork()
    
    componentNetwork5 = network5
    componentNetwork5.MoveObjectsState = True
    
    componentNetwork5.DisplayComponent = NXOpen.Assemblies.Component.Null
    
    componentNetwork5.NetworkArrangementsMode = NXOpen.Positioning.ComponentNetwork.ArrangementsMode.Existing
    
    theSession.SetUndoMarkName(markId21, "Assembly Constraints Dialog")
    
    componentNetwork5.MoveObjectsState = True
    
    componentNetwork5.NetworkArrangementsMode = NXOpen.Positioning.ComponentNetwork.ArrangementsMode.Existing
    
    markId22 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Assembly Constraints Update")
    
    # ----------------------------------------------
    #   Dialog Begin Assembly Constraints
    # ----------------------------------------------
    line4 = workPart.Lines.CreateFaceAxis(face1, NXOpen.SmartObject.UpdateOption.AfterModeling)
    
    line4.SetVisibility(NXOpen.SmartObject.VisibilityOption.Visible)
    
    # ----------------------------------------------
    #   Menu: Edit->Undo
    # ----------------------------------------------
    objects4 = [NXOpen.TaggedObject.Null] * 1 
    objects4[0] = line4
    nErrs11 = theSession.UpdateManager.AddObjectsToDeleteList(objects4)
    
    componentPositioner5.PrimaryArrangement = NXOpen.Assemblies.Arrangement.Null
    
    componentPositioner5.EndAssemblyConstraints()
    
    theSession.DeleteUndoMark(markId22, None)
    
    marksRecycled1, undoUnavailable1 = theSession.UndoLastNVisibleMarks(1)
    
    theSession.DeleteUndoMark(markId16, None)
    
    # ----------------------------------------------
    #   Menu: Edit->Undo
    # ----------------------------------------------
    marksRecycled2, undoUnavailable2 = theSession.UndoLastNVisibleMarks(1)
    
    # ----------------------------------------------
    #   Menu: Assemblies->Component Position->Assembly Constraints...
    # ----------------------------------------------
    markId23 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Constraints with Positioning Task")
    
    markId24 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    componentPositioner6 = workPart.ComponentAssembly.Positioner
    
    componentPositioner6.ClearNetwork()
    
    componentPositioner6.PrimaryArrangement = arrangement2
    
    componentPositioner6.BeginAssemblyConstraints()
    
    allowInterpartPositioning6 = theSession.Preferences.Assemblies.InterpartPositioning
    
    expression41 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", NXOpen.Unit.Null)
    
    expression42 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", unit3)
    
    expression43 = workPart.Expressions.CreateSystemExpressionWithUnits("0.0", unit3)
    
    expression44 = workPart.Expressions.CreateSystemExpressionWithUnits("0.0", unit4)
    
    expression45 = workPart.Expressions.CreateSystemExpressionWithUnits("1", NXOpen.Unit.Null)
    
    expression46 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", unit3)
    
    expression47 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit3)
    
    expression48 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit4)
    
    network6 = componentPositioner6.EstablishNetwork()
    
    componentNetwork6 = network6
    componentNetwork6.MoveObjectsState = True
    
    componentNetwork6.DisplayComponent = NXOpen.Assemblies.Component.Null
    
    componentNetwork6.NetworkArrangementsMode = NXOpen.Positioning.ComponentNetwork.ArrangementsMode.Existing
    
    theSession.SetUndoMarkName(markId24, "Assembly Constraints Dialog")
    
    componentNetwork6.MoveObjectsState = True
    
    componentNetwork6.NetworkArrangementsMode = NXOpen.Positioning.ComponentNetwork.ArrangementsMode.Existing
    
    markId25 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Assembly Constraints Update")
    
    line5 = workPart.Lines.CreateFaceAxis(face1, NXOpen.SmartObject.UpdateOption.AfterModeling)
    
    line5.SetVisibility(NXOpen.SmartObject.VisibilityOption.Visible)
    
    line6 = workPart.Lines.CreateFaceAxis(face2, NXOpen.SmartObject.UpdateOption.AfterModeling)
    
    line6.SetVisibility(NXOpen.SmartObject.VisibilityOption.Visible)
    
    markId26 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constraint")
    
    constraint2 = componentPositioner6.CreateConstraint(True)
    
    componentConstraint2 = constraint2
    componentConstraint2.ConstraintType = NXOpen.Positioning.Constraint.Type.Distance
    
    constraintReference3 = componentConstraint2.CreateConstraintReference(component5, face1, True, False, False)
    
    helpPoint3 = NXOpen.Point3d(98.18126622800024, 353.72873992974417, -216.34937621986506)
    constraintReference3.HelpPoint = helpPoint3
    
    constraintReference4 = componentConstraint2.CreateConstraintReference(component6, face2, True, False, False)
    
    helpPoint4 = NXOpen.Point3d(-139.67640730317996, -453.73142781319393, -72.931726411526569)
    constraintReference4.HelpPoint = helpPoint4
    
    constraintReference4.SetFixHint(True)
    
    componentConstraint2.SetExpression("0")
    
    componentConstraint2.SetExpression("143.417649808339")
    
    objects5 = [NXOpen.TaggedObject.Null] * 1 
    objects5[0] = line6
    nErrs12 = theSession.UpdateManager.AddObjectsToDeleteList(objects5)
    
    objects6 = [NXOpen.TaggedObject.Null] * 1 
    objects6[0] = line5
    nErrs13 = theSession.UpdateManager.AddObjectsToDeleteList(objects6)
    
    componentNetwork6.Solve()
    
    line7 = workPart.Lines.CreateFaceAxis(face2, NXOpen.SmartObject.UpdateOption.AfterModeling)
    
    line7.SetVisibility(NXOpen.SmartObject.VisibilityOption.Visible)
    
    line8 = workPart.Lines.CreateFaceAxis(face1, NXOpen.SmartObject.UpdateOption.AfterModeling)
    
    line8.SetVisibility(NXOpen.SmartObject.VisibilityOption.Visible)
    
    markId27 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Assembly Constraints")
    
    objects7 = [NXOpen.TaggedObject.Null] * 1 
    objects7[0] = line7
    nErrs14 = theSession.UpdateManager.AddObjectsToDeleteList(objects7)
    
    objects8 = [NXOpen.TaggedObject.Null] * 1 
    objects8[0] = line8
    nErrs15 = theSession.UpdateManager.AddObjectsToDeleteList(objects8)
    
    theSession.DeleteUndoMark(markId27, None)
    
    markId28 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Assembly Constraints")
    
    nErrs16 = theSession.UpdateManager.DoUpdate(markId25)
    
    componentNetwork6.Solve()
    
    componentPositioner6.ClearNetwork()
    
    nErrs17 = theSession.UpdateManager.AddToDeleteList(componentNetwork6)
    
    componentPositioner6.DeleteNonPersistentConstraints()
    
    nErrs18 = theSession.UpdateManager.DoUpdate(markId25)
    
    theSession.DeleteUndoMark(markId28, None)
    
    theSession.SetUndoMarkName(markId24, "Assembly Constraints")
    
    componentPositioner6.PrimaryArrangement = NXOpen.Assemblies.Arrangement.Null
    
    componentPositioner6.EndAssemblyConstraints()
    
    theSession.DeleteUndoMark(markId25, None)
    
    theSession.DeleteUndoMark(markId26, None)
    
    theSession.DeleteUndoMark(markId23, None)
    
    rotMatrix14 = NXOpen.Matrix3x3()
    
    rotMatrix14.Xx = 0.86174902219539518
    rotMatrix14.Xy = -0.437090262159329
    rotMatrix14.Xz = 0.25756693396237623
    rotMatrix14.Yx = -0.24592411215896648
    rotMatrix14.Yy = 0.084167824861684906
    rotMatrix14.Yz = 0.96562783116316253
    rotMatrix14.Zx = -0.44374537045935875
    rotMatrix14.Zy = -0.89547075886572047
    rotMatrix14.Zz = -0.034959493879993621
    translation16 = NXOpen.Point3d(-99.932592864426056, 67.73411177711111, -65.765154941270339)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix14, translation16, 0.55314132098730495)
    
    markId29 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Change Displayed Part")
    
    status1, partLoadStatus1 = theSession.Parts.SetActiveDisplay(part2, NXOpen.DisplayPartOption.AllowAdditional, NXOpen.PartDisplayPartWorkPartOption.UseLast)
    
    workPart = theSession.Parts.Work # model4
    displayPart = theSession.Parts.Display # model4
    partLoadStatus1.Dispose()
    rotMatrix15 = NXOpen.Matrix3x3()
    
    rotMatrix15.Xx = 0.7561456055278154
    rotMatrix15.Xy = 0.3344952370432861
    rotMatrix15.Xz = -0.5624560068452803
    rotMatrix15.Yx = 0.049139249896496186
    rotMatrix15.Yy = -0.88609010522493603
    rotMatrix15.Yz = -0.46090092161122487
    rotMatrix15.Zx = -0.65255586531774368
    rotMatrix15.Zy = 0.32086954018388891
    rotMatrix15.Zz = -0.68644998420977044
    translation17 = NXOpen.Point3d(31.68978276090801, 12.421255914148276, 58.100513860155679)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix15, translation17, 2.7372126561721029)
    
    markId30 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Change Displayed Part")
    
    part3 = theSession.Parts.FindObject("assembly2")
    status2, partLoadStatus2 = theSession.Parts.SetActiveDisplay(part3, NXOpen.DisplayPartOption.AllowAdditional, NXOpen.PartDisplayPartWorkPartOption.UseLast)
    
    workPart = theSession.Parts.Work # assembly2
    displayPart = theSession.Parts.Display # assembly2
    partLoadStatus2.Dispose()
    theSession.DeleteUndoMark(markId30, None)
    
    theSession.DeleteUndoMark(markId29, None)
    
    # ----------------------------------------------
    #   Menu: Assemblies->Component Position->Assembly Constraints...
    # ----------------------------------------------
    markId31 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Constraints with Positioning Task")
    
    markId32 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    componentPositioner7 = workPart.ComponentAssembly.Positioner
    
    componentPositioner7.ClearNetwork()
    
    componentPositioner7.PrimaryArrangement = arrangement2
    
    componentPositioner7.BeginAssemblyConstraints()
    
    allowInterpartPositioning7 = theSession.Preferences.Assemblies.InterpartPositioning
    
    expression49 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", NXOpen.Unit.Null)
    
    expression50 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", unit3)
    
    expression51 = workPart.Expressions.CreateSystemExpressionWithUnits("0.0", unit3)
    
    expression52 = workPart.Expressions.CreateSystemExpressionWithUnits("0.0", unit4)
    
    expression53 = workPart.Expressions.CreateSystemExpressionWithUnits("1", NXOpen.Unit.Null)
    
    expression54 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", unit3)
    
    expression55 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit3)
    
    expression56 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit4)
    
    network7 = componentPositioner7.EstablishNetwork()
    
    componentNetwork7 = network7
    componentNetwork7.MoveObjectsState = True
    
    componentNetwork7.DisplayComponent = NXOpen.Assemblies.Component.Null
    
    componentNetwork7.NetworkArrangementsMode = NXOpen.Positioning.ComponentNetwork.ArrangementsMode.Existing
    
    theSession.SetUndoMarkName(markId32, "Assembly Constraints Dialog")
    
    componentNetwork7.MoveObjectsState = True
    
    componentNetwork7.NetworkArrangementsMode = NXOpen.Positioning.ComponentNetwork.ArrangementsMode.Existing
    
    markId33 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Assembly Constraints Update")
    
    line9 = workPart.Lines.CreateFaceAxis(face1, NXOpen.SmartObject.UpdateOption.AfterModeling)
    
    objects9 = [NXOpen.TaggedObject.Null] * 1 
    objects9[0] = line9
    nErrs19 = theSession.UpdateManager.AddObjectsToDeleteList(objects9)
    
    markId34 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constraint")
    
    constraint3 = componentPositioner7.CreateConstraint(True)
    
    componentConstraint3 = constraint3
    componentConstraint3.ConstraintType = NXOpen.Positioning.Constraint.Type.Concentric
    
    edge1 = component5.FindObject("PROTO#.Features|EXTRUDE(4)|EDGE * 140 EXTRUDE(2) 120 {(0,-5.1672952755923,-10.5524446848037)(0,9.8327047244077,-1.8921906469593)(0,-5.1672952755923,6.768063390885) EXTRUDE(2)}")
    constraintReference5 = componentConstraint3.CreateConstraintReference(component5, edge1, False, False, False)
    
    helpPoint5 = NXOpen.Point3d(185.48838681395085, 344.45584202862142, -212.60593335060872)
    constraintReference5.HelpPoint = helpPoint5
    
    edge2 = component6.FindObject("PROTO#.Features|EXTRUDE(8)|EDGE * 140 EXTRUDE(2) 130 {(28.8530625433051,-140,25)(20.1928085054608,-140,10)(11.5325544676164,-140,25) EXTRUDE(2)}")
    constraintReference6 = componentConstraint3.CreateConstraintReference(component6, edge2, False, False, False)
    
    helpPoint6 = NXOpen.Point3d(-141.48659338106322, -488.89957104519726, -63.096929699675577)
    constraintReference6.HelpPoint = helpPoint6
    
    constraintReference6.SetFixHint(True)
    
    componentNetwork7.Solve()
    
    line10 = workPart.Lines.CreateFaceAxis(face1, NXOpen.SmartObject.UpdateOption.AfterModeling)
    
    scaleAboutPoint44 = NXOpen.Point3d(-162.15340745092959, -137.75864703795801, 0.0)
    viewCenter44 = NXOpen.Point3d(162.1534074509299, 137.75864703795801, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint44, viewCenter44)
    
    scaleAboutPoint45 = NXOpen.Point3d(-129.72272596074365, -110.20691763036641, 0.0)
    viewCenter45 = NXOpen.Point3d(129.72272596074396, 110.20691763036641, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint45, viewCenter45)
    
    scaleAboutPoint46 = NXOpen.Point3d(-103.77818076859485, -88.16553410429313, 0.0)
    viewCenter46 = NXOpen.Point3d(103.77818076859519, 88.16553410429313, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint46, viewCenter46)
    
    componentPositioner7.PrimaryArrangement = NXOpen.Assemblies.Arrangement.Null
    
    componentPositioner7.EndAssemblyConstraints()
    
    theSession.DeleteUndoMark(markId33, None)
    
    objects10 = [NXOpen.TaggedObject.Null] * 1 
    objects10[0] = line10
    nErrs20 = theSession.UpdateManager.AddObjectsToDeleteList(objects10)
    
    theSession.UndoToMark(markId32, None)
    
    theSession.DeleteUndoMark(markId32, None)
    
    theSession.DeleteUndoMark(markId31, None)
    
    # ----------------------------------------------
    #   Menu: Assemblies->Component Position->Assembly Constraints...
    # ----------------------------------------------
    markId35 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Constraints with Positioning Task")
    
    markId36 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    componentPositioner8 = workPart.ComponentAssembly.Positioner
    
    componentPositioner8.ClearNetwork()
    
    componentPositioner8.PrimaryArrangement = arrangement2
    
    componentPositioner8.BeginAssemblyConstraints()
    
    allowInterpartPositioning8 = theSession.Preferences.Assemblies.InterpartPositioning
    
    expression57 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", NXOpen.Unit.Null)
    
    expression58 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", unit3)
    
    expression59 = workPart.Expressions.CreateSystemExpressionWithUnits("0.0", unit3)
    
    expression60 = workPart.Expressions.CreateSystemExpressionWithUnits("0.0", unit4)
    
    expression61 = workPart.Expressions.CreateSystemExpressionWithUnits("1", NXOpen.Unit.Null)
    
    expression62 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", unit3)
    
    expression63 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit3)
    
    expression64 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit4)
    
    network8 = componentPositioner8.EstablishNetwork()
    
    componentNetwork8 = network8
    componentNetwork8.MoveObjectsState = True
    
    componentNetwork8.DisplayComponent = NXOpen.Assemblies.Component.Null
    
    componentNetwork8.NetworkArrangementsMode = NXOpen.Positioning.ComponentNetwork.ArrangementsMode.Existing
    
    theSession.SetUndoMarkName(markId36, "Assembly Constraints Dialog")
    
    componentNetwork8.MoveObjectsState = True
    
    componentNetwork8.NetworkArrangementsMode = NXOpen.Positioning.ComponentNetwork.ArrangementsMode.Existing
    
    markId37 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Assembly Constraints Update")
    
    line11 = workPart.Lines.CreateFaceAxis(face2, NXOpen.SmartObject.UpdateOption.AfterModeling)
    
    line11.SetVisibility(NXOpen.SmartObject.VisibilityOption.Visible)
    
    scaleAboutPoint47 = NXOpen.Point3d(-23.342437414764955, -45.919549012652674, 0.0)
    viewCenter47 = NXOpen.Point3d(23.342437414765282, 45.919549012652674, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint47, viewCenter47)
    
    scaleAboutPoint48 = NXOpen.Point3d(-18.673949931811912, -37.041769536873083, 0.0)
    viewCenter48 = NXOpen.Point3d(18.673949931812253, 37.041769536873083, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint48, viewCenter48)
    
    scaleAboutPoint49 = NXOpen.Point3d(-14.93915994544955, -29.63341562949855, 0.0)
    viewCenter49 = NXOpen.Point3d(14.939159945449841, 29.633415629498383, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint49, viewCenter49)
    
    scaleAboutPoint50 = NXOpen.Point3d(-18.67394993181194, -37.041769536873083, 0.0)
    viewCenter50 = NXOpen.Point3d(18.673949931812199, 37.041769536873083, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint50, viewCenter50)
    
    scaleAboutPoint51 = NXOpen.Point3d(-23.342437414764948, -46.302211921091342, 0.0)
    viewCenter51 = NXOpen.Point3d(23.342437414765275, 46.302211921091342, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint51, viewCenter51)
    
    scaleAboutPoint52 = NXOpen.Point3d(-29.178046768456223, -57.877764901364174, 0.0)
    viewCenter52 = NXOpen.Point3d(29.17804676845655, 57.877764901364174, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint52, viewCenter52)
    
    componentPositioner8.PrimaryArrangement = NXOpen.Assemblies.Arrangement.Null
    
    componentPositioner8.EndAssemblyConstraints()
    
    theSession.DeleteUndoMark(markId37, None)
    
    objects11 = [NXOpen.TaggedObject.Null] * 1 
    objects11[0] = line11
    nErrs21 = theSession.UpdateManager.AddObjectsToDeleteList(objects11)
    
    theSession.UndoToMark(markId36, None)
    
    theSession.DeleteUndoMark(markId36, None)
    
    theSession.DeleteUndoMark(markId35, None)
    
    markId38 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Delete Constraint")
    
    objects12 = [NXOpen.TaggedObject.Null] * 1 
    objects12[0] = componentConstraint2
    nErrs22 = theSession.UpdateManager.AddObjectsToDeleteList(objects12)
    
    nErrs23 = theSession.UpdateManager.DoUpdate(markId38)
    
    # ----------------------------------------------
    #   Menu: Assemblies->Component Position->Assembly Constraints...
    # ----------------------------------------------
    markId39 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Constraints with Positioning Task")
    
    markId40 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    componentPositioner9 = workPart.ComponentAssembly.Positioner
    
    componentPositioner9.ClearNetwork()
    
    componentPositioner9.PrimaryArrangement = arrangement2
    
    componentPositioner9.BeginAssemblyConstraints()
    
    allowInterpartPositioning9 = theSession.Preferences.Assemblies.InterpartPositioning
    
    expression65 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", NXOpen.Unit.Null)
    
    expression66 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", unit3)
    
    expression67 = workPart.Expressions.CreateSystemExpressionWithUnits("0.0", unit3)
    
    expression68 = workPart.Expressions.CreateSystemExpressionWithUnits("0.0", unit4)
    
    expression69 = workPart.Expressions.CreateSystemExpressionWithUnits("1", NXOpen.Unit.Null)
    
    expression70 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", unit3)
    
    expression71 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit3)
    
    expression72 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit4)
    
    network9 = componentPositioner9.EstablishNetwork()
    
    componentNetwork9 = network9
    componentNetwork9.MoveObjectsState = True
    
    componentNetwork9.DisplayComponent = NXOpen.Assemblies.Component.Null
    
    componentNetwork9.NetworkArrangementsMode = NXOpen.Positioning.ComponentNetwork.ArrangementsMode.Existing
    
    theSession.SetUndoMarkName(markId40, "Assembly Constraints Dialog")
    
    componentNetwork9.MoveObjectsState = True
    
    componentNetwork9.NetworkArrangementsMode = NXOpen.Positioning.ComponentNetwork.ArrangementsMode.Existing
    
    markId41 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Assembly Constraints Update")
    
    line12 = workPart.Lines.CreateFaceAxis(face1, NXOpen.SmartObject.UpdateOption.AfterModeling)
    
    objects13 = [NXOpen.TaggedObject.Null] * 1 
    objects13[0] = line12
    nErrs24 = theSession.UpdateManager.AddObjectsToDeleteList(objects13)
    
    line13 = workPart.Lines.CreateFaceAxis(face2, NXOpen.SmartObject.UpdateOption.AfterModeling)
    
    markId42 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constraint")
    
    constraint4 = componentPositioner9.CreateConstraint(True)
    
    componentConstraint4 = constraint4
    componentConstraint4.ConstraintType = NXOpen.Positioning.Constraint.Type.Concentric
    
    constraintReference7 = componentConstraint4.CreateConstraintReference(component5, edge1, False, False, False)
    
    helpPoint7 = NXOpen.Point3d(185.48838681395085, 344.35434053965406, -212.86790583005666)
    constraintReference7.HelpPoint = helpPoint7
    
    constraintReference8 = componentConstraint4.CreateConstraintReference(component6, edge2, False, False, False)
    
    helpPoint8 = NXOpen.Point3d(-143.05428098699221, -488.89957104519726, -63.519501946704139)
    constraintReference8.HelpPoint = helpPoint8
    
    constraintReference8.SetFixHint(True)
    
    objects14 = [NXOpen.TaggedObject.Null] * 1 
    objects14[0] = line13
    nErrs25 = theSession.UpdateManager.AddObjectsToDeleteList(objects14)
    
    componentNetwork9.Solve()
    
    rotMatrix16 = NXOpen.Matrix3x3()
    
    rotMatrix16.Xx = 0.11568997940038442
    rotMatrix16.Xy = -0.97471129918133514
    rotMatrix16.Xz = 0.1911902505740633
    rotMatrix16.Yx = 0.014620584403755604
    rotMatrix16.Yy = 0.19413289351978635
    rotMatrix16.Yz = 0.98086627945165361
    rotMatrix16.Zx = -0.99317776212420072
    rotMatrix16.Zy = -0.11068108646859968
    rotMatrix16.Zz = 0.036710079271216375
    translation18 = NXOpen.Point3d(-268.13195560673046, 102.48301409820053, 284.32520934057686)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix16, translation18, 0.44251305678984409)
    
    face3 = component5.FindObject("PROTO#.Features|EXTRUDE(6)|FACE 140 {(-180,-1.3940372767944,36.6305468146156) EXTRUDE(2)}")
    line14 = workPart.Lines.CreateFaceAxis(face3, NXOpen.SmartObject.UpdateOption.AfterModeling)
    
    scaleAboutPoint53 = NXOpen.Point3d(18.535234627503144, -34.678826077263587, 0.0)
    viewCenter53 = NXOpen.Point3d(-18.535234627502838, 34.678826077263587, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint53, viewCenter53)
    
    scaleAboutPoint54 = NXOpen.Point3d(14.828187702002559, -27.743060861810878, 0.0)
    viewCenter54 = NXOpen.Point3d(-14.828187702002234, 27.743060861810878, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint54, viewCenter54)
    
    scaleAboutPoint55 = NXOpen.Point3d(11.862550161602012, -22.194448689448695, 0.0)
    viewCenter55 = NXOpen.Point3d(-11.862550161601815, 22.194448689448695, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint55, viewCenter55)
    
    scaleAboutPoint56 = NXOpen.Point3d(9.4900401292816632, -17.75555895155896, 0.0)
    viewCenter56 = NXOpen.Point3d(-9.4900401292814287, 17.75555895155896, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint56, viewCenter56)
    
    scaleAboutPoint57 = NXOpen.Point3d(11.862550161602012, -22.194448689448695, 0.0)
    viewCenter57 = NXOpen.Point3d(-11.862550161601815, 22.194448689448695, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint57, viewCenter57)
    
    scaleAboutPoint58 = NXOpen.Point3d(14.828187702002474, -27.743060861810868, 0.0)
    viewCenter58 = NXOpen.Point3d(-14.828187702002229, 27.743060861810868, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint58, viewCenter58)
    
    scaleAboutPoint59 = NXOpen.Point3d(11.862550161601977, -22.194448689448691, 0.0)
    viewCenter59 = NXOpen.Point3d(-11.862550161601847, 22.194448689448691, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint59, viewCenter59)
    
    scaleAboutPoint60 = NXOpen.Point3d(9.4900401292814749, -18.061689278310105, 0.0)
    viewCenter60 = NXOpen.Point3d(-9.4900401292815797, 18.061689278310105, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint60, viewCenter60)
    
    scaleAboutPoint61 = NXOpen.Point3d(7.5920321034252423, -14.694255684048843, 0.0)
    viewCenter61 = NXOpen.Point3d(-7.5920321034252423, 14.694255684048843, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint61, viewCenter61)
    
    line15 = workPart.Lines.CreateFaceAxis(face1, NXOpen.SmartObject.UpdateOption.AfterModeling)
    
    objects15 = [NXOpen.TaggedObject.Null] * 1 
    objects15[0] = line14
    nErrs26 = theSession.UpdateManager.AddObjectsToDeleteList(objects15)
    
    objects16 = [NXOpen.TaggedObject.Null] * 1 
    objects16[0] = line15
    nErrs27 = theSession.UpdateManager.AddObjectsToDeleteList(objects16)
    
    rotMatrix17 = NXOpen.Matrix3x3()
    
    rotMatrix17.Xx = 0.029350582218705429
    rotMatrix17.Xy = -0.98011218793789856
    rotMatrix17.Xz = 0.19626166813468518
    rotMatrix17.Yx = -0.0083928740993448065
    rotMatrix17.Yy = 0.19609769199233906
    rotMatrix17.Yz = 0.98054844595238178
    rotMatrix17.Zx = -0.99953394288927466
    rotMatrix17.Zy = -0.030426867253530655
    rotMatrix17.Zz = -0.0024703767648762772
    translation19 = NXOpen.Point3d(-278.49117055849592, 127.8354161531913, 315.69373054010646)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix17, translation19, 1.3504426781916632)
    
    rotMatrix18 = NXOpen.Matrix3x3()
    
    rotMatrix18.Xx = 0.30176559010963144
    rotMatrix18.Xy = -0.93437032807375719
    rotMatrix18.Xz = 0.18944555587589398
    rotMatrix18.Yx = -0.0083928740993448065
    rotMatrix18.Yy = 0.19609769199233906
    rotMatrix18.Yz = 0.98054844595238178
    rotMatrix18.Zx = -0.95334520940220935
    rotMatrix18.Zy = -0.29748577312304858
    rotMatrix18.Zz = 0.051333483217518655
    translation20 = NXOpen.Point3d(-272.97887064291604, 127.8354161531913, 206.7088980832041)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix18, translation20, 1.3504426781916632)
    
    line16 = workPart.Lines.CreateFaceAxis(face1, NXOpen.SmartObject.UpdateOption.AfterModeling)
    
    line16.SetVisibility(NXOpen.SmartObject.VisibilityOption.Visible)
    
    objects17 = [NXOpen.TaggedObject.Null] * 1 
    objects17[0] = line16
    nErrs28 = theSession.UpdateManager.AddObjectsToDeleteList(objects17)
    
    rotMatrix19 = NXOpen.Matrix3x3()
    
    rotMatrix19.Xx = -0.13765946847514038
    rotMatrix19.Xy = -0.97092420390361389
    rotMatrix19.Xz = 0.19584703473189541
    rotMatrix19.Yx = 0.02618328812197309
    rotMatrix19.Yy = 0.19409322007279728
    rotMatrix19.Yz = 0.98063359994693977
    rotMatrix19.Zx = -0.99013347896244164
    rotMatrix19.Zy = 0.14012141947577839
    rotMatrix19.Zz = -0.0012967813344436909
    translation21 = NXOpen.Point3d(-266.8517915202321, 125.38385774143222, 385.03849610202053)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix19, translation21, 1.3504426781916632)
    
    line17 = workPart.Lines.CreateFaceAxis(face3, NXOpen.SmartObject.UpdateOption.AfterModeling)
    
    markId43 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constraint")
    
    constraint5 = componentPositioner9.CreateConstraint(True)
    
    componentConstraint5 = constraint5
    componentConstraint5.ConstraintType = NXOpen.Positioning.Constraint.Type.Distance
    
    face4 = component5.FindObject("PROTO#.Features|EXTRUDE(6)|FACE 120 {(-160,-1.3940372767944,-3.3694531853844) EXTRUDE(2)}")
    constraintReference9 = componentConstraint5.CreateConstraintReference(component5, face4, False, False, False)
    
    helpPoint9 = NXOpen.Point3d(-151.27187572469302, -328.89957104517231, -49.905440831662929)
    constraintReference9.HelpPoint = helpPoint9
    
    face5 = component6.FindObject("PROTO#.Features|EXTRUDE(2)|FACE 120 {(150.9,0,70) EXTRUDE(2)}")
    constraintReference10 = componentConstraint5.CreateConstraintReference(component6, face5, False, False, False)
    
    helpPoint10 = NXOpen.Point3d(-94.321781911530508, -348.89957104519726, -52.289350419612354)
    constraintReference10.HelpPoint = helpPoint10
    
    constraintReference10.SetFixHint(True)
    
    componentConstraint5.SetExpression("0")
    
    componentConstraint5.SetExpression("20")
    
    objects18 = [NXOpen.TaggedObject.Null] * 1 
    objects18[0] = line17
    nErrs29 = theSession.UpdateManager.AddObjectsToDeleteList(objects18)
    
    componentNetwork9.Solve()
    
    line18 = workPart.Lines.CreateFaceAxis(face1, NXOpen.SmartObject.UpdateOption.AfterModeling)
    
    line18.SetVisibility(NXOpen.SmartObject.VisibilityOption.Visible)
    
    line19 = workPart.Lines.CreateFaceAxis(face3, NXOpen.SmartObject.UpdateOption.AfterModeling)
    
    line19.SetVisibility(NXOpen.SmartObject.VisibilityOption.Visible)
    
    constraintReference9.SetFixHint(False)
    
    constraintReference10.SetFixHint(True)
    
    componentNetwork9.AddConstraint(componentConstraint5)
    
    expression73 = workPart.Expressions.FindObject("p8")
    expression73.RightHandSide = "5"
    
    objects19 = [NXOpen.TaggedObject.Null] * 1 
    objects19[0] = line19
    nErrs30 = theSession.UpdateManager.AddObjectsToDeleteList(objects19)
    
    objects20 = [NXOpen.TaggedObject.Null] * 1 
    objects20[0] = line18
    nErrs31 = theSession.UpdateManager.AddObjectsToDeleteList(objects20)
    
    componentNetwork9.Solve()
    
    constraintReference9.SetFixHint(False)
    
    constraintReference10.SetFixHint(True)
    
    componentNetwork9.AddConstraint(componentConstraint5)
    
    expression73.RightHandSide = "10"
    
    componentNetwork9.Solve()
    
    markId44 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Assembly Constraints")
    
    nErrs32 = theSession.UpdateManager.DoUpdate(markId41)
    
    componentNetwork9.Solve()
    
    componentPositioner9.ClearNetwork()
    
    nErrs33 = theSession.UpdateManager.AddToDeleteList(componentNetwork9)
    
    componentPositioner9.DeleteNonPersistentConstraints()
    
    nErrs34 = theSession.UpdateManager.DoUpdate(markId41)
    
    theSession.DeleteUndoMark(markId44, None)
    
    theSession.SetUndoMarkName(markId40, "Assembly Constraints")
    
    componentPositioner9.PrimaryArrangement = NXOpen.Assemblies.Arrangement.Null
    
    componentPositioner9.EndAssemblyConstraints()
    
    theSession.DeleteUndoMark(markId41, None)
    
    theSession.DeleteUndoMark(markId43, None)
    
    theSession.DeleteUndoMark(markId42, None)
    
    markId45 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    componentPositioner10 = workPart.ComponentAssembly.Positioner
    
    componentPositioner10.ClearNetwork()
    
    componentPositioner10.PrimaryArrangement = arrangement2
    
    componentPositioner10.BeginAssemblyConstraints()
    
    allowInterpartPositioning10 = theSession.Preferences.Assemblies.InterpartPositioning
    
    expression74 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", NXOpen.Unit.Null)
    
    expression75 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", unit3)
    
    expression76 = workPart.Expressions.CreateSystemExpressionWithUnits("0.0", unit3)
    
    expression77 = workPart.Expressions.CreateSystemExpressionWithUnits("0.0", unit4)
    
    expression78 = workPart.Expressions.CreateSystemExpressionWithUnits("1", NXOpen.Unit.Null)
    
    expression79 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", unit3)
    
    expression80 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit3)
    
    expression81 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit4)
    
    network10 = componentPositioner10.EstablishNetwork()
    
    componentNetwork10 = network10
    componentNetwork10.MoveObjectsState = True
    
    componentNetwork10.DisplayComponent = NXOpen.Assemblies.Component.Null
    
    componentNetwork10.NetworkArrangementsMode = NXOpen.Positioning.ComponentNetwork.ArrangementsMode.Existing
    
    theSession.SetUndoMarkName(markId45, "Assembly Constraints Dialog")
    
    componentNetwork10.MoveObjectsState = True
    
    componentNetwork10.NetworkArrangementsMode = NXOpen.Positioning.ComponentNetwork.ArrangementsMode.Existing
    
    markId46 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Assembly Constraints Update")
    
    # ----------------------------------------------
    #   Dialog Begin Assembly Constraints
    # ----------------------------------------------
    scaleAboutPoint62 = NXOpen.Point3d(21.943421821512889, -27.625200686011819, 0.0)
    viewCenter62 = NXOpen.Point3d(-21.943421821512924, 27.625200686011819, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint62, viewCenter62)
    
    scaleAboutPoint63 = NXOpen.Point3d(17.868214911803395, -22.100160548809463, 0.0)
    viewCenter63 = NXOpen.Point3d(-17.868214911803371, 22.100160548809463, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint63, viewCenter63)
    
    scaleAboutPoint64 = NXOpen.Point3d(14.419962911279937, -17.680128439047614, 0.0)
    viewCenter64 = NXOpen.Point3d(-14.419962911279915, 17.680128439047529, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint64, viewCenter64)
    
    line20 = workPart.Lines.CreateFaceAxis(face3, NXOpen.SmartObject.UpdateOption.AfterModeling)
    
    line20.SetVisibility(NXOpen.SmartObject.VisibilityOption.Visible)
    
    scaleAboutPoint65 = NXOpen.Point3d(11.53597032902395, -14.144102751238092, 0.0)
    viewCenter65 = NXOpen.Point3d(-11.535970329023934, 14.144102751238023, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint65, viewCenter65)
    
    scaleAboutPoint66 = NXOpen.Point3d(9.2287762632191548, -11.315282200990502, 0.0)
    viewCenter66 = NXOpen.Point3d(-9.2287762632191548, 11.315282200990392, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint66, viewCenter66)
    
    scaleAboutPoint67 = NXOpen.Point3d(11.535970329023945, -14.144102751238094, 0.0)
    viewCenter67 = NXOpen.Point3d(-11.535970329023945, 14.144102751238027, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint67, viewCenter67)
    
    scaleAboutPoint68 = NXOpen.Point3d(14.419962911279928, -17.680128439047614, 0.0)
    viewCenter68 = NXOpen.Point3d(-14.419962911279928, 17.680128439047529, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint68, viewCenter68)
    
    scaleAboutPoint69 = NXOpen.Point3d(18.024953639099913, -22.10016054880947, 0.0)
    viewCenter69 = NXOpen.Point3d(-18.024953639099913, 22.10016054880947, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint69, viewCenter69)
    
    scaleAboutPoint70 = NXOpen.Point3d(22.727115457995492, -27.233353867770482, 0.0)
    viewCenter70 = NXOpen.Point3d(-22.727115457995527, 27.233353867770482, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint70, viewCenter70)
    
    scaleAboutPoint71 = NXOpen.Point3d(28.653798583895252, -33.796788073312349, 0.0)
    viewCenter71 = NXOpen.Point3d(-28.653798583895252, 33.796788073312349, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint71, viewCenter71)
    
    scaleAboutPoint72 = NXOpen.Point3d(35.817248229869094, -42.245985091640435, 0.0)
    viewCenter72 = NXOpen.Point3d(-35.817248229869065, 42.245985091640435, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint72, viewCenter72)
    
    scaleAboutPoint73 = NXOpen.Point3d(44.771560287336392, -52.80748136455054, 0.0)
    viewCenter73 = NXOpen.Point3d(-44.771560287336328, 52.80748136455054, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint73, viewCenter73)
    
    scaleAboutPoint74 = NXOpen.Point3d(56.921107630267279, -65.53102307013981, 0.0)
    viewCenter74 = NXOpen.Point3d(-56.921107630267279, 65.53102307013981, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint74, viewCenter74)
    
    line21 = workPart.Lines.CreateFaceAxis(face1, NXOpen.SmartObject.UpdateOption.AfterModeling)
    
    line21.SetVisibility(NXOpen.SmartObject.VisibilityOption.Visible)
    
    rotMatrix20 = NXOpen.Matrix3x3()
    
    rotMatrix20.Xx = -0.36607452139594848
    rotMatrix20.Xy = -0.89368753881493124
    rotMatrix20.Xz = 0.25944561617348744
    rotMatrix20.Yx = 0.010174031906474713
    rotMatrix20.Yy = 0.27493800547909103
    rotMatrix20.Yz = 0.96140812468896175
    rotMatrix20.Zx = -0.93052992099099086
    rotMatrix20.Zy = 0.35458662708863131
    rotMatrix20.Zz = -0.091555393234992496
    translation22 = NXOpen.Point3d(-174.40920796193262, 102.77550216967376, 465.45755131210672)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix20, translation22, 0.44251305678984443)
    
    componentPositioner10.PrimaryArrangement = NXOpen.Assemblies.Arrangement.Null
    
    componentPositioner10.EndAssemblyConstraints()
    
    theSession.DeleteUndoMark(markId46, None)
    
    objects21 = [NXOpen.TaggedObject.Null] * 1 
    objects21[0] = line20
    nErrs35 = theSession.UpdateManager.AddObjectsToDeleteList(objects21)
    
    objects22 = [NXOpen.TaggedObject.Null] * 1 
    objects22[0] = line21
    nErrs36 = theSession.UpdateManager.AddObjectsToDeleteList(objects22)
    
    theSession.UndoToMark(markId45, None)
    
    theSession.DeleteUndoMark(markId45, None)
    
    theSession.DeleteUndoMark(markId39, None)
    
    markId47 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Delete Constraint")
    
    objects23 = [NXOpen.TaggedObject.Null] * 1 
    objects23[0] = componentConstraint5
    nErrs37 = theSession.UpdateManager.AddObjectsToDeleteList(objects23)
    
    nErrs38 = theSession.UpdateManager.DoUpdate(markId47)
    
    rotMatrix21 = NXOpen.Matrix3x3()
    
    rotMatrix21.Xx = -0.1763063086274356
    rotMatrix21.Xy = -0.95138045126022064
    rotMatrix21.Xz = 0.25256944094262301
    rotMatrix21.Yx = -0.081710414887535623
    rotMatrix21.Yy = 0.26984857491389785
    rotMatrix21.Yz = 0.95942959862401911
    rotMatrix21.Zx = -0.9809380681965002
    rotMatrix21.Zy = 0.14851593711396793
    rotMatrix21.Zz = -0.12531369751980614
    translation23 = NXOpen.Point3d(-207.28416515937027, 104.9530331549426, 382.07386870612436)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix21, translation23, 0.44251305678984376)
    
    # ----------------------------------------------
    #   Menu: Edit->Delete...
    # ----------------------------------------------
    markId48 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Delete")
    
    notifyOnDelete1 = theSession.Preferences.Modeling.NotifyOnDelete
    
    theSession.UpdateManager.ClearErrorList()
    
    markId49 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Delete")
    
    objects24 = [NXOpen.TaggedObject.Null] * 1 
    objects24[0] = component5
    nErrs39 = theSession.UpdateManager.AddObjectsToDeleteList(objects24)
    
    notifyOnDelete2 = theSession.Preferences.Modeling.NotifyOnDelete
    
    id1 = theSession.NewestVisibleUndoMark
    
    nErrs40 = theSession.UpdateManager.DoUpdate(id1)
    
    theSession.DeleteUndoMark(markId48, None)
    
    # ----------------------------------------------
    #   Menu: Edit->Delete...
    # ----------------------------------------------
    markId50 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Delete")
    
    notifyOnDelete3 = theSession.Preferences.Modeling.NotifyOnDelete
    
    theSession.UpdateManager.ClearErrorList()
    
    markId51 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Delete")
    
    objects25 = [NXOpen.TaggedObject.Null] * 1 
    objects25[0] = component3
    nErrs41 = theSession.UpdateManager.AddObjectsToDeleteList(objects25)
    
    notifyOnDelete4 = theSession.Preferences.Modeling.NotifyOnDelete
    
    id2 = theSession.NewestVisibleUndoMark
    
    nErrs42 = theSession.UpdateManager.DoUpdate(id2)
    
    theSession.DeleteUndoMark(markId50, None)
    
    workPart.ModelingViews.WorkView.Fit()
    
    markId52 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Change Displayed Part")
    
    status3, partLoadStatus3 = theSession.Parts.SetActiveDisplay(part2, NXOpen.DisplayPartOption.AllowAdditional, NXOpen.PartDisplayPartWorkPartOption.UseLast)
    
    workPart = theSession.Parts.Work # model4
    displayPart = theSession.Parts.Display # model4
    partLoadStatus3.Dispose()
    scaleAboutPoint75 = NXOpen.Point3d(-20.492257530735305, 20.782242307113581, 0.0)
    viewCenter75 = NXOpen.Point3d(20.492257530735241, -20.782242307113613, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint75, viewCenter75)
    
    scaleAboutPoint76 = NXOpen.Point3d(-16.39380602458824, 16.625793845690861, 0.0)
    viewCenter76 = NXOpen.Point3d(16.393806024588187, -16.62579384569089, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint76, viewCenter76)
    
    scaleAboutPoint77 = NXOpen.Point3d(-13.115044819670597, 13.300635076552688, 0.0)
    viewCenter77 = NXOpen.Point3d(13.115044819670539, -13.300635076552719, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint77, viewCenter77)
    
    scaleAboutPoint78 = NXOpen.Point3d(-10.492035855736493, 10.640508061242148, 0.0)
    viewCenter78 = NXOpen.Point3d(10.492035855736425, -10.640508061242173, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint78, viewCenter78)
    
    scaleAboutPoint79 = NXOpen.Point3d(-8.3936286845891939, 8.5124064489937155, 0.0)
    viewCenter79 = NXOpen.Point3d(8.3936286845891335, -8.5124064489937457, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint79, viewCenter79)
    
    scaleAboutPoint80 = NXOpen.Point3d(-10.492035855736484, 10.640508061242151, 0.0)
    viewCenter80 = NXOpen.Point3d(10.492035855736429, -10.640508061242173, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint80, viewCenter80)
    
    scaleAboutPoint81 = NXOpen.Point3d(-13.11504481967059, 13.300635076552688, 0.0)
    viewCenter81 = NXOpen.Point3d(13.115044819670549, -13.300635076552709, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint81, viewCenter81)
    
    scaleAboutPoint82 = NXOpen.Point3d(-16.161818203485577, 15.543184013878438, 0.0)
    viewCenter82 = NXOpen.Point3d(16.161818203485524, -15.543184013878458, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint82, viewCenter82)
    
    scaleAboutPoint83 = NXOpen.Point3d(-20.202272754356972, 18.849010464591391, 0.0)
    viewCenter83 = NXOpen.Point3d(20.202272754356908, -18.849010464591405, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint83, viewCenter83)
    
    scaleAboutPoint84 = NXOpen.Point3d(-25.252840942946197, 23.198782110266325, 0.0)
    viewCenter84 = NXOpen.Point3d(25.252840942946143, -23.198782110266336, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint84, viewCenter84)
    
    scaleAboutPoint85 = NXOpen.Point3d(-31.566051178682748, 28.847443900135865, 0.0)
    viewCenter85 = NXOpen.Point3d(31.56605117868267, -28.847443900135879, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint85, viewCenter85)
    
    scaleAboutPoint86 = NXOpen.Point3d(-38.513603112746878, 33.038630121228898, 0.0)
    viewCenter86 = NXOpen.Point3d(38.513603112746814, -33.038630121228934, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint86, viewCenter86)
    
    scaleAboutPoint87 = NXOpen.Point3d(-48.142003890933552, 41.062297436384483, 0.0)
    viewCenter87 = NXOpen.Point3d(48.142003890933509, -41.062297436384519, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint87, viewCenter87)
    
    scaleAboutPoint88 = NXOpen.Point3d(-59.882517094727461, 51.032884026541062, 0.0)
    viewCenter88 = NXOpen.Point3d(59.882517094727362, -51.032884026541083, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint88, viewCenter88)
    
    markId53 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Redefine Feature")
    
    extrude1 = workPart.Features.FindObject("EXTRUDE(4)")
    # User Function call - UF_PART_ask_part_name
    
    editWithRollbackManager1 = workPart.Features.StartEditWithRollbackManager(extrude1, markId53)
    
    markId54 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    extrudeBuilder1 = workPart.Features.CreateExtrudeBuilder(extrude1)
    
    section1 = extrudeBuilder1.Section
    
    section1.PrepareMappingData()
    
    refs1 = section1.EvaluateAndAskOutputEntities()
    
    extrudeBuilder1.AllowSelfIntersectingSection(True)
    
    targetBodies1 = [NXOpen.Body.Null] * 1 
    body1 = workPart.Bodies.FindObject("EXTRUDE(2)")
    targetBodies1[0] = body1
    extrudeBuilder1.BooleanOperation.SetTargetBodies(targetBodies1)
    
    targetBodies2 = [NXOpen.Body.Null] * 1 
    targetBodies2[0] = body1
    extrudeBuilder1.BooleanOperation.SetTargetBodies(targetBodies2)
    
    unit5 = extrudeBuilder1.Draft.FrontDraftAngle.Units
    
    expression82 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit5)
    
    unit6 = extrudeBuilder1.Offset.StartOffset.Units
    
    expression83 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit6)
    
    theSession.SetUndoMarkName(markId54, "Extrude Dialog")
    
    section1.DistanceTolerance = 0.01
    
    section1.ChainingTolerance = 0.0094999999999999998
    
    extrudeBuilder1.Limits.EndExtend.Value.SetFormula("140")
    
    markId55 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    theSession.DeleteUndoMark(markId55, None)
    
    markId56 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    feature1 = extrudeBuilder1.CommitFeature()
    
    theSession.DeleteUndoMark(markId56, None)
    
    theSession.SetUndoMarkName(markId54, "Extrude")
    
    section1.CleanMappingData()
    
    expression84 = extrudeBuilder1.Limits.StartExtend.Value
    expression85 = extrudeBuilder1.Limits.EndExtend.Value
    extrudeBuilder1.Destroy()
    
    workPart.Expressions.Delete(expression82)
    
    workPart.Expressions.Delete(expression83)
    
    theSession.DeleteUndoMark(markId54, None)
    
    editWithRollbackManager1.UpdateFeature(False)
    
    editWithRollbackManager1.Stop()
    
    editWithRollbackManager1.Destroy()
    
    rotMatrix22 = NXOpen.Matrix3x3()
    
    rotMatrix22.Xx = 0.90554424882260542
    rotMatrix22.Xy = 0.23855805538804958
    rotMatrix22.Xz = -0.35082711929636151
    rotMatrix22.Yx = 0.097099197261889508
    rotMatrix22.Yy = -0.92152093560192228
    rotMatrix22.Yz = -0.37599323283599012
    rotMatrix22.Zx = -0.41299074967292659
    rotMatrix22.Zy = 0.30641347792946871
    rotMatrix22.Zz = -0.85764177908248285
    translation24 = NXOpen.Point3d(-13.394470685872832, 64.633412078616743, 74.571584441190964)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix22, translation24, 0.71754387453958024)
    
    # ----------------------------------------------
    #   Menu: File->Save
    # ----------------------------------------------
    partSaveStatus1 = workPart.Save(NXOpen.BasePart.SaveComponents.TrueValue, NXOpen.BasePart.CloseAfterSave.FalseValue)
    
    partSaveStatus1.Dispose()
    markId57 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Change Displayed Part")
    
    status4, partLoadStatus4 = theSession.Parts.SetActiveDisplay(part3, NXOpen.DisplayPartOption.AllowAdditional, NXOpen.PartDisplayPartWorkPartOption.UseLast)
    
    workPart = theSession.Parts.Work # assembly2
    displayPart = theSession.Parts.Display # assembly2
    partLoadStatus4.Dispose()
    theSession.DeleteUndoMark(markId57, None)
    
    rotMatrix23 = NXOpen.Matrix3x3()
    
    rotMatrix23.Xx = -0.96285179151929579
    rotMatrix23.Xy = 0.25118035938394867
    rotMatrix23.Xz = -0.099120404699736583
    rotMatrix23.Yx = -0.16851832959878635
    rotMatrix23.Yy = -0.27212476998849428
    rotMatrix23.Yz = 0.9473909869467545
    rotMatrix23.Zx = 0.21099289124831777
    rotMatrix23.Zy = 0.92890071408006913
    rotMatrix23.Zz = 0.30434431689160252
    translation25 = NXOpen.Point3d(93.443750676301349, -93.930782264066025, 398.17758565939789)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix23, translation25, 1.0713184987484101)
    
    scaleAboutPoint89 = NXOpen.Point3d(-57.050027672819269, 11.607581387976186, 0.0)
    viewCenter89 = NXOpen.Point3d(57.050027672819269, -11.607581387976103, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint89, viewCenter89)
    
    scaleAboutPoint90 = NXOpen.Point3d(-45.640022138255411, 9.2860651103809495, 0.0)
    viewCenter90 = NXOpen.Point3d(45.640022138255411, -9.286065110380882, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint90, viewCenter90)
    
    scaleAboutPoint91 = NXOpen.Point3d(-36.512017710604333, 7.42885208830476, 0.0)
    viewCenter91 = NXOpen.Point3d(36.512017710604319, -7.4288520883047067, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint91, viewCenter91)
    
    scaleAboutPoint92 = NXOpen.Point3d(-45.640022138255446, 9.2860651103809495, 0.0)
    viewCenter92 = NXOpen.Point3d(45.640022138255382, -9.286065110380882, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint92, viewCenter92)
    
    scaleAboutPoint93 = NXOpen.Point3d(-57.050027672819269, 11.607581387976186, 0.0)
    viewCenter93 = NXOpen.Point3d(57.050027672819226, -11.607581387976103, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint93, viewCenter93)
    
    # ----------------------------------------------
    #   Menu: Assemblies->Components->Add Component...
    # ----------------------------------------------
    markId58 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    addComponentBuilder4 = workPart.AssemblyManager.CreateAddComponentBuilder()
    
    componentPositioner11 = workPart.ComponentAssembly.Positioner
    
    componentPositioner11.ClearNetwork()
    
    componentPositioner11.PrimaryArrangement = arrangement2
    
    componentPositioner11.BeginAssemblyConstraints()
    
    allowInterpartPositioning11 = theSession.Preferences.Assemblies.InterpartPositioning
    
    expression86 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", NXOpen.Unit.Null)
    
    expression87 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", unit3)
    
    expression88 = workPart.Expressions.CreateSystemExpressionWithUnits("0.0", unit3)
    
    expression89 = workPart.Expressions.CreateSystemExpressionWithUnits("0.0", unit4)
    
    expression90 = workPart.Expressions.CreateSystemExpressionWithUnits("1", NXOpen.Unit.Null)
    
    expression91 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", unit3)
    
    expression92 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit3)
    
    expression93 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit4)
    
    network11 = componentPositioner11.EstablishNetwork()
    
    componentNetwork11 = network11
    componentNetwork11.MoveObjectsState = True
    
    componentNetwork11.DisplayComponent = NXOpen.Assemblies.Component.Null
    
    theSession.SetUndoMarkName(markId58, "Add Component Dialog")
    
    componentNetwork11.MoveObjectsState = True
    
    markId59 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Assembly Constraints Update")
    
    addComponentBuilder4.SetComponentAnchor(NXOpen.Assemblies.ProductInterface.InterfaceObject.Null)
    
    addComponentBuilder4.SetInitialLocationType(NXOpen.Assemblies.AddComponentBuilder.LocationType.Snap)
    
    addComponentBuilder4.SetCount(1)
    
    addComponentBuilder4.SetScatterOption(True)
    
    addComponentBuilder4.ReferenceSet = "Unknown"
    
    addComponentBuilder4.Layer = -1
    
    addComponentBuilder4.ReferenceSet = "Use Model"
    
    addComponentBuilder4.Layer = -1
    
    partstouse5 = [NXOpen.BasePart.Null] * 1 
    partstouse5[0] = part2
    addComponentBuilder4.SetPartsToAdd(partstouse5)
    
    productinterfaceobjects5 = addComponentBuilder4.GetAllProductInterfaceObjects()
    
    coordinates7 = NXOpen.Point3d(87.548511652293541, -563.43311045668202, 0.0)
    point10 = workPart.Points.CreatePoint(coordinates7)
    
    coordinates8 = NXOpen.Point3d(87.548511652293541, -563.43311045668202, 0.0)
    point11 = workPart.Points.CreatePoint(coordinates8)
    
    origin12 = NXOpen.Point3d(87.548511652293541, -563.43311045668202, 0.0)
    vector7 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    direction7 = workPart.Directions.CreateDirection(origin12, vector7, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    origin13 = NXOpen.Point3d(87.548511652293541, -563.43311045668202, 0.0)
    vector8 = NXOpen.Vector3d(1.0, 0.0, 0.0)
    direction8 = workPart.Directions.CreateDirection(origin13, vector8, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    origin14 = NXOpen.Point3d(87.548511652293541, -563.43311045668202, 0.0)
    matrix4 = NXOpen.Matrix3x3()
    
    matrix4.Xx = 1.0
    matrix4.Xy = 0.0
    matrix4.Xz = 0.0
    matrix4.Yx = 0.0
    matrix4.Yy = 1.0
    matrix4.Yz = 0.0
    matrix4.Zx = 0.0
    matrix4.Zy = 0.0
    matrix4.Zz = 1.0
    plane4 = workPart.Planes.CreateFixedTypePlane(origin14, matrix4, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    xform4 = workPart.Xforms.CreateXformByPlaneXDirPoint(plane4, direction8, point11, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem4 = workPart.CoordinateSystems.CreateCoordinateSystem(xform4, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    point12 = NXOpen.Point3d(87.548511652293541, -563.43311045668202, 0.0)
    orientation4 = NXOpen.Matrix3x3()
    
    orientation4.Xx = 1.0
    orientation4.Xy = 0.0
    orientation4.Xz = 0.0
    orientation4.Yx = 0.0
    orientation4.Yy = 1.0
    orientation4.Yz = 0.0
    orientation4.Zx = 0.0
    orientation4.Zy = 0.0
    orientation4.Zz = 1.0
    addComponentBuilder4.SetInitialLocationAndOrientation(point12, orientation4)
    
    movableObjects5 = [NXOpen.NXObject.Null] * 1 
    component7 = workPart.ComponentAssembly.RootComponent.FindObject("COMPONENT model4 1")
    movableObjects5[0] = component7
    componentNetwork11.SetMovingGroup(movableObjects5)
    
    coordinates9 = NXOpen.Point3d(57.75956662612537, -649.35526180180068, 0.0)
    point13 = workPart.Points.CreatePoint(coordinates9)
    
    coordinates10 = NXOpen.Point3d(57.75956662612537, -649.35526180180068, 0.0)
    point14 = workPart.Points.CreatePoint(coordinates10)
    
    componentNetwork11.EmptyMovingGroup()
    
    origin15 = NXOpen.Point3d(57.75956662612537, -649.35526180180068, 0.0)
    vector9 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    direction9 = workPart.Directions.CreateDirection(origin15, vector9, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    origin16 = NXOpen.Point3d(57.75956662612537, -649.35526180180068, 0.0)
    vector10 = NXOpen.Vector3d(1.0, 0.0, 0.0)
    direction10 = workPart.Directions.CreateDirection(origin16, vector10, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    origin17 = NXOpen.Point3d(57.75956662612537, -649.35526180180068, 0.0)
    matrix5 = NXOpen.Matrix3x3()
    
    matrix5.Xx = 1.0
    matrix5.Xy = 0.0
    matrix5.Xz = 0.0
    matrix5.Yx = 0.0
    matrix5.Yy = 1.0
    matrix5.Yz = 0.0
    matrix5.Zx = 0.0
    matrix5.Zy = 0.0
    matrix5.Zz = 1.0
    plane5 = workPart.Planes.CreateFixedTypePlane(origin17, matrix5, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    xform5 = workPart.Xforms.CreateXformByPlaneXDirPoint(plane5, direction10, point14, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem5 = workPart.CoordinateSystems.CreateCoordinateSystem(xform5, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    point15 = NXOpen.Point3d(57.75956662612537, -649.35526180180068, 0.0)
    orientation5 = NXOpen.Matrix3x3()
    
    orientation5.Xx = 1.0
    orientation5.Xy = 0.0
    orientation5.Xz = 0.0
    orientation5.Yx = 0.0
    orientation5.Yy = 1.0
    orientation5.Yz = 0.0
    orientation5.Zx = 0.0
    orientation5.Zy = 0.0
    orientation5.Zz = 1.0
    addComponentBuilder4.SetInitialLocationAndOrientation(point15, orientation5)
    
    movableObjects6 = [NXOpen.NXObject.Null] * 1 
    movableObjects6[0] = component7
    componentNetwork11.SetMovingGroup(movableObjects6)
    
    markId60 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Add Component")
    
    theSession.DeleteUndoMark(markId60, None)
    
    markId61 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Add Component")
    
    markId62 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "AddComponent on_apply")
    
    componentNetwork11.Solve()
    
    componentPositioner11.ClearNetwork()
    
    nErrs43 = theSession.UpdateManager.AddToDeleteList(componentNetwork11)
    
    nErrs44 = theSession.UpdateManager.DoUpdate(markId59)
    
    componentPositioner11.EndAssemblyConstraints()
    
    logicalobjects3 = addComponentBuilder4.GetLogicalObjectsHavingUnassignedRequiredAttributes()
    
    addComponentBuilder4.ComponentName = "MODEL4"
    
    nXObject3 = addComponentBuilder4.Commit()
    
    errorList3 = addComponentBuilder4.GetOperationFailures()
    
    errorList3.Dispose()
    theSession.DeleteUndoMark(markId61, None)
    
    theSession.SetUndoMarkName(markId58, "Add Component")
    
    addComponentBuilder4.Destroy()
    
    objects26 = [NXOpen.TaggedObject.Null] * 1 
    objects26[0] = point13
    nErrs45 = theSession.UpdateManager.AddObjectsToDeleteList(objects26)
    
    workPart.Points.DeletePoint(point10)
    
    componentPositioner11.PrimaryArrangement = NXOpen.Assemblies.Arrangement.Null
    
    theSession.DeleteUndoMark(markId59, None)
    
    # ----------------------------------------------
    #   Menu: Assemblies->Components->Add Component...
    # ----------------------------------------------
    markId63 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    addComponentBuilder5 = workPart.AssemblyManager.CreateAddComponentBuilder()
    
    componentPositioner12 = workPart.ComponentAssembly.Positioner
    
    componentPositioner12.ClearNetwork()
    
    componentPositioner12.PrimaryArrangement = arrangement2
    
    componentPositioner12.BeginAssemblyConstraints()
    
    allowInterpartPositioning12 = theSession.Preferences.Assemblies.InterpartPositioning
    
    expression94 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", NXOpen.Unit.Null)
    
    expression95 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", unit3)
    
    expression96 = workPart.Expressions.CreateSystemExpressionWithUnits("0.0", unit3)
    
    expression97 = workPart.Expressions.CreateSystemExpressionWithUnits("0.0", unit4)
    
    expression98 = workPart.Expressions.CreateSystemExpressionWithUnits("1", NXOpen.Unit.Null)
    
    expression99 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", unit3)
    
    expression100 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit3)
    
    expression101 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit4)
    
    network12 = componentPositioner12.EstablishNetwork()
    
    componentNetwork12 = network12
    componentNetwork12.MoveObjectsState = True
    
    componentNetwork12.DisplayComponent = NXOpen.Assemblies.Component.Null
    
    theSession.SetUndoMarkName(markId63, "Add Component Dialog")
    
    componentNetwork12.MoveObjectsState = True
    
    markId64 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Assembly Constraints Update")
    
    addComponentBuilder5.SetComponentAnchor(NXOpen.Assemblies.ProductInterface.InterfaceObject.Null)
    
    addComponentBuilder5.SetInitialLocationType(NXOpen.Assemblies.AddComponentBuilder.LocationType.Snap)
    
    addComponentBuilder5.SetCount(1)
    
    addComponentBuilder5.SetScatterOption(True)
    
    addComponentBuilder5.ReferenceSet = "Unknown"
    
    addComponentBuilder5.Layer = -1
    
    addComponentBuilder5.ReferenceSet = "Use Model"
    
    addComponentBuilder5.Layer = -1
    
    partstouse6 = [NXOpen.BasePart.Null] * 1 
    partstouse6[0] = part2
    addComponentBuilder5.SetPartsToAdd(partstouse6)
    
    productinterfaceobjects6 = addComponentBuilder5.GetAllProductInterfaceObjects()
    
    scaleAboutPoint94 = NXOpen.Point3d(90.761407661303366, -8.6439435867907264, 0.0)
    viewCenter94 = NXOpen.Point3d(-90.761407661303366, 8.6439435867907264, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint94, viewCenter94)
    
    scaleAboutPoint95 = NXOpen.Point3d(113.45175957662921, -10.80492948348841, 0.0)
    viewCenter95 = NXOpen.Point3d(-113.45175957662921, 10.80492948348841, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint95, viewCenter95)
    
    scaleAboutPoint96 = NXOpen.Point3d(141.81469947078651, -13.50616185436051, 0.0)
    viewCenter96 = NXOpen.Point3d(-141.81469947078651, 13.50616185436051, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint96, viewCenter96)
    
    scaleAboutPoint97 = NXOpen.Point3d(177.26837433848311, -16.882702317950635, 0.0)
    viewCenter97 = NXOpen.Point3d(-177.26837433848311, 16.882702317950635, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint97, viewCenter97)
    
    coordinates11 = NXOpen.Point3d(-127.02074107501207, 25.846790703946795, 0.0)
    point16 = workPart.Points.CreatePoint(coordinates11)
    
    coordinates12 = NXOpen.Point3d(-127.02074107501207, 25.846790703946795, 0.0)
    point17 = workPart.Points.CreatePoint(coordinates12)
    
    origin18 = NXOpen.Point3d(-127.02074107501207, 25.846790703946795, 0.0)
    vector11 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    direction11 = workPart.Directions.CreateDirection(origin18, vector11, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    origin19 = NXOpen.Point3d(-127.02074107501207, 25.846790703946795, 0.0)
    vector12 = NXOpen.Vector3d(1.0, 0.0, 0.0)
    direction12 = workPart.Directions.CreateDirection(origin19, vector12, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    origin20 = NXOpen.Point3d(-127.02074107501207, 25.846790703946795, 0.0)
    matrix6 = NXOpen.Matrix3x3()
    
    matrix6.Xx = 1.0
    matrix6.Xy = 0.0
    matrix6.Xz = 0.0
    matrix6.Yx = 0.0
    matrix6.Yy = 1.0
    matrix6.Yz = 0.0
    matrix6.Zx = 0.0
    matrix6.Zy = 0.0
    matrix6.Zz = 1.0
    plane6 = workPart.Planes.CreateFixedTypePlane(origin20, matrix6, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    xform6 = workPart.Xforms.CreateXformByPlaneXDirPoint(plane6, direction12, point17, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem6 = workPart.CoordinateSystems.CreateCoordinateSystem(xform6, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    point18 = NXOpen.Point3d(-127.02074107501207, 25.846790703946795, 0.0)
    orientation6 = NXOpen.Matrix3x3()
    
    orientation6.Xx = 1.0
    orientation6.Xy = 0.0
    orientation6.Xz = 0.0
    orientation6.Yx = 0.0
    orientation6.Yy = 1.0
    orientation6.Yz = 0.0
    orientation6.Zx = 0.0
    orientation6.Zy = 0.0
    orientation6.Zz = 1.0
    addComponentBuilder5.SetInitialLocationAndOrientation(point18, orientation6)
    
    movableObjects7 = [NXOpen.NXObject.Null] * 1 
    component8 = workPart.ComponentAssembly.RootComponent.FindObject("COMPONENT model4 1")
    movableObjects7[0] = component8
    componentNetwork12.SetMovingGroup(movableObjects7)
    
    rotMatrix24 = NXOpen.Matrix3x3()
    
    rotMatrix24.Xx = -0.98075209167244504
    rotMatrix24.Xy = 0.14245742371284337
    rotMatrix24.Xz = -0.13353358045536712
    rotMatrix24.Yx = -0.16851832959878635
    rotMatrix24.Yy = -0.27212476998849428
    rotMatrix24.Yz = 0.9473909869467545
    rotMatrix24.Zx = 0.098625084382046091
    rotMatrix24.Zy = 0.95165854800333272
    rotMatrix24.Zz = 0.29089362444513239
    translation26 = NXOpen.Point3d(93.981074266453419, -95.891105184642157, 395.60332259056912)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix24, translation26, 0.54851507135918609)
    
    markId65 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Add Component")
    
    theSession.DeleteUndoMark(markId65, None)
    
    markId66 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Add Component")
    
    markId67 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "AddComponent on_apply")
    
    componentNetwork12.Solve()
    
    componentPositioner12.ClearNetwork()
    
    nErrs46 = theSession.UpdateManager.AddToDeleteList(componentNetwork12)
    
    nErrs47 = theSession.UpdateManager.DoUpdate(markId64)
    
    componentPositioner12.EndAssemblyConstraints()
    
    logicalobjects4 = addComponentBuilder5.GetLogicalObjectsHavingUnassignedRequiredAttributes()
    
    addComponentBuilder5.ComponentName = "MODEL4"
    
    nXObject4 = addComponentBuilder5.Commit()
    
    errorList4 = addComponentBuilder5.GetOperationFailures()
    
    errorList4.Dispose()
    theSession.DeleteUndoMark(markId66, None)
    
    theSession.SetUndoMarkName(markId63, "Add Component")
    
    addComponentBuilder5.Destroy()
    
    workPart.Points.DeletePoint(point16)
    
    componentPositioner12.PrimaryArrangement = NXOpen.Assemblies.Arrangement.Null
    
    theSession.DeleteUndoMark(markId64, None)
    
    rotMatrix25 = NXOpen.Matrix3x3()
    
    rotMatrix25.Xx = -0.96831165940756558
    rotMatrix25.Xy = -0.15823389675099009
    rotMatrix25.Xz = -0.19322154169338909
    rotMatrix25.Yx = -0.12744140943086585
    rotMatrix25.Yy = -0.35230141487582839
    rotMatrix25.Yz = 0.92716902463292294
    rotMatrix25.Zx = -0.21478179023755209
    rotMatrix25.Zy = 0.92241300239940749
    rotMatrix25.Zz = 0.32097201682836102
    translation27 = NXOpen.Point3d(-0.30096233073621192, -117.97846022563768, 361.00303475610849)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix25, translation27, 0.54851507135918609)
    
    # ----------------------------------------------
    #   Menu: Assemblies->Component Position->Move Component...
    # ----------------------------------------------
    markId68 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    componentPositioner13 = workPart.ComponentAssembly.Positioner
    
    componentPositioner13.ClearNetwork()
    
    componentPositioner13.PrimaryArrangement = arrangement2
    
    componentPositioner13.BeginMoveComponent()
    
    allowInterpartPositioning13 = theSession.Preferences.Assemblies.InterpartPositioning
    
    expression102 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", NXOpen.Unit.Null)
    
    expression103 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", unit3)
    
    expression104 = workPart.Expressions.CreateSystemExpressionWithUnits("0.0", unit3)
    
    expression105 = workPart.Expressions.CreateSystemExpressionWithUnits("0.0", unit4)
    
    expression106 = workPart.Expressions.CreateSystemExpressionWithUnits("1", NXOpen.Unit.Null)
    
    expression107 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", unit3)
    
    expression108 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit3)
    
    expression109 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit4)
    
    network13 = componentPositioner13.EstablishNetwork()
    
    componentNetwork13 = network13
    componentNetwork13.MoveObjectsState = True
    
    componentNetwork13.DisplayComponent = NXOpen.Assemblies.Component.Null
    
    componentNetwork13.NetworkArrangementsMode = NXOpen.Positioning.ComponentNetwork.ArrangementsMode.Existing
    
    expression110 = workPart.Expressions.CreateSystemExpressionWithUnits("0.0", unit3)
    
    expression111 = workPart.Expressions.CreateSystemExpressionWithUnits("0.0", unit3)
    
    expression112 = workPart.Expressions.CreateSystemExpressionWithUnits("0.0", unit3)
    
    expression113 = workPart.Expressions.CreateSystemExpressionWithUnits("0.0", unit3)
    
    expression114 = workPart.Expressions.CreateSystemExpressionWithUnits("0.0", unit4)
    
    componentNetwork13.RemoveAllConstraints()
    
    movableObjects8 = []
    componentNetwork13.SetMovingGroup(movableObjects8)
    
    componentNetwork13.Solve()
    
    theSession.SetUndoMarkName(markId68, "Move Component Dialog")
    
    componentNetwork13.MoveObjectsState = True
    
    markId69 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Move Component Update")
    
    # ----------------------------------------------
    #   Menu: Assemblies->Component Position->Assembly Constraints...
    # ----------------------------------------------
    componentPositioner13.EndMoveComponent()
    
    componentPositioner13.PrimaryArrangement = NXOpen.Assemblies.Arrangement.Null
    
    theSession.DeleteUndoMarksUpToMark(markId69, None, False)
    
    theSession.UndoToMark(markId68, None)
    
    theSession.DeleteUndoMark(markId68, None)
    
    markId70 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Constraints with Positioning Task")
    
    markId71 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    componentPositioner14 = workPart.ComponentAssembly.Positioner
    
    componentPositioner14.ClearNetwork()
    
    componentPositioner14.PrimaryArrangement = arrangement2
    
    componentPositioner14.BeginAssemblyConstraints()
    
    allowInterpartPositioning14 = theSession.Preferences.Assemblies.InterpartPositioning
    
    expression115 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", NXOpen.Unit.Null)
    
    expression116 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", unit3)
    
    expression117 = workPart.Expressions.CreateSystemExpressionWithUnits("0.0", unit3)
    
    expression118 = workPart.Expressions.CreateSystemExpressionWithUnits("0.0", unit4)
    
    expression119 = workPart.Expressions.CreateSystemExpressionWithUnits("1", NXOpen.Unit.Null)
    
    expression120 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", unit3)
    
    expression121 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit3)
    
    expression122 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit4)
    
    network14 = componentPositioner14.EstablishNetwork()
    
    componentNetwork14 = network14
    componentNetwork14.MoveObjectsState = True
    
    componentNetwork14.DisplayComponent = NXOpen.Assemblies.Component.Null
    
    componentNetwork14.NetworkArrangementsMode = NXOpen.Positioning.ComponentNetwork.ArrangementsMode.Existing
    
    theSession.SetUndoMarkName(markId71, "Assembly Constraints Dialog")
    
    componentNetwork14.MoveObjectsState = True
    
    componentNetwork14.NetworkArrangementsMode = NXOpen.Positioning.ComponentNetwork.ArrangementsMode.Existing
    
    markId72 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Assembly Constraints Update")
    
    component9 = nXObject4
    face6 = component9.FindObject("PROTO#.Features|EXTRUDE(6)|FACE 140 {(-160,-1.3940372767944,36.6305468146156) EXTRUDE(2)}")
    line22 = workPart.Lines.CreateFaceAxis(face6, NXOpen.SmartObject.UpdateOption.AfterModeling)
    
    line22.SetVisibility(NXOpen.SmartObject.VisibilityOption.Visible)
    
    face7 = component9.FindObject("PROTO#.Features|EXTRUDE(4)|FACE 140 {(-70,-0.1672952755923,8.1078093530407) EXTRUDE(2)}")
    line23 = workPart.Lines.CreateFaceAxis(face7, NXOpen.SmartObject.UpdateOption.AfterModeling)
    
    line23.SetVisibility(NXOpen.SmartObject.VisibilityOption.Visible)
    
    rotMatrix26 = NXOpen.Matrix3x3()
    
    rotMatrix26.Xx = -0.99028987849992245
    rotMatrix26.Xy = 0.090624447641487513
    rotMatrix26.Xz = -0.10541900222583606
    rotMatrix26.Yx = -0.12795478959258152
    rotMatrix26.Yy = -0.29773919149110883
    rotMatrix26.Yz = 0.94603326879689653
    rotMatrix26.Zx = 0.054346373944669978
    rotMatrix26.Zy = 0.95033603706262715
    rotMatrix26.Zz = 0.30644393989630447
    translation28 = NXOpen.Point3d(77.590674846445467, -100.54170116855488, 392.39011825849417)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix26, translation28, 0.54851507135918609)
    
    line24 = workPart.Lines.CreateFaceAxis(face2, NXOpen.SmartObject.UpdateOption.AfterModeling)
    
    line24.SetVisibility(NXOpen.SmartObject.VisibilityOption.Visible)
    
    objects27 = [NXOpen.TaggedObject.Null] * 1 
    objects27[0] = line23
    nErrs48 = theSession.UpdateManager.AddObjectsToDeleteList(objects27)
    
    objects28 = [NXOpen.TaggedObject.Null] * 1 
    objects28[0] = line22
    nErrs49 = theSession.UpdateManager.AddObjectsToDeleteList(objects28)
    
    objects29 = [NXOpen.TaggedObject.Null] * 1 
    objects29[0] = line24
    nErrs50 = theSession.UpdateManager.AddObjectsToDeleteList(objects29)
    
    line25 = workPart.Lines.CreateFaceAxis(face6, NXOpen.SmartObject.UpdateOption.AfterModeling)
    
    line25.SetVisibility(NXOpen.SmartObject.VisibilityOption.Visible)
    
    rotMatrix27 = NXOpen.Matrix3x3()
    
    rotMatrix27.Xx = -0.99064131873949168
    rotMatrix27.Xy = 0.0802226401455685
    rotMatrix27.Xz = -0.11042692431722562
    rotMatrix27.Yx = -0.1342360552219827
    rotMatrix27.Yy = -0.4261789637931408
    rotMatrix27.Yz = 0.89462403963824255
    rotMatrix27.Zx = 0.024707470217094879
    rotMatrix27.Zy = 0.90107481311391813
    rotMatrix27.Zz = 0.43295926146369895
    translation29 = NXOpen.Point3d(74.195747945546884, -142.38847409624435, 377.36710630392514)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix27, translation29, 0.54851507135918609)
    
    rotMatrix28 = NXOpen.Matrix3x3()
    
    rotMatrix28.Xx = -0.78232617514070701
    rotMatrix28.Xy = -0.51219875341297283
    rotMatrix28.Xz = -0.35442656882902274
    rotMatrix28.Yx = -0.15002516010309622
    rotMatrix28.Yy = -0.39731839756642401
    rotMatrix28.Yz = 0.90533449193725712
    rotMatrix28.Zx = -0.60453139457414362
    rotMatrix28.Zy = 0.76143977303359234
    rotMatrix28.Zz = 0.23398988229578691
    translation30 = NXOpen.Point3d(-98.702909617771979, -134.47444454646813, 275.40995029813405)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix28, translation30, 0.54851507135918609)
    
    line26 = workPart.Lines.CreateFaceAxis(face7, NXOpen.SmartObject.UpdateOption.AfterModeling)
    
    line26.SetVisibility(NXOpen.SmartObject.VisibilityOption.Visible)
    
    markId73 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constraint")
    
    constraint6 = componentPositioner14.CreateConstraint(True)
    
    componentConstraint6 = constraint6
    componentConstraint6.ConstraintType = NXOpen.Positioning.Constraint.Type.Distance
    
    edge3 = component6.FindObject("PROTO#.Features|EXTRUDE(8)|EDGE * 140 EXTRUDE(2) 120 {(25.1928085054607,0,28.6602540378444)(10.1928085054608,0,20)(25.1928085054608,0,11.3397459621556) EXTRUDE(2)}")
    constraintReference11 = componentConstraint6.CreateConstraintReference(component6, edge3, False, False, False)
    
    helpPoint11 = NXOpen.Point3d(-145.9250739755812, -348.89957104519726, -65.124411583930083)
    constraintReference11.HelpPoint = helpPoint11
    
    edge4 = component9.FindObject("PROTO#.Features|EXTRUDE(4)|EDGE * 140 EXTRUDE(2) 120 {(0,-5.1672952755923,-10.5524446848037)(0,9.8327047244077,-1.8921906469593)(0,-5.1672952755923,6.768063390885) EXTRUDE(2)}")
    constraintReference12 = componentConstraint6.CreateConstraintReference(component9, edge4, False, False, False)
    
    helpPoint12 = NXOpen.Point3d(-127.02074107501207, 33.568693467243385, 4.2527710537506334)
    constraintReference12.HelpPoint = helpPoint12
    
    constraintReference12.SetFixHint(True)
    
    componentConstraint6.SetExpression("0")
    
    componentConstraint6.SetExpression("389.169038635301")
    
    objects30 = [NXOpen.TaggedObject.Null] * 1 
    objects30[0] = line26
    nErrs51 = theSession.UpdateManager.AddObjectsToDeleteList(objects30)
    
    objects31 = [NXOpen.TaggedObject.Null] * 1 
    objects31[0] = line25
    nErrs52 = theSession.UpdateManager.AddObjectsToDeleteList(objects31)
    
    componentNetwork14.Solve()
    
    line27 = workPart.Lines.CreateFaceAxis(face6, NXOpen.SmartObject.UpdateOption.AfterModeling)
    
    line27.SetVisibility(NXOpen.SmartObject.VisibilityOption.Visible)
    
    line28 = workPart.Lines.CreateFaceAxis(face7, NXOpen.SmartObject.UpdateOption.AfterModeling)
    
    line28.SetVisibility(NXOpen.SmartObject.VisibilityOption.Visible)
    
    face8 = component9.FindObject("PROTO#.Features|EXTRUDE(2)|FACE 140 {(20,0,-40) EXTRUDE(2)}")
    line29 = workPart.Lines.CreateFaceAxis(face8, NXOpen.SmartObject.UpdateOption.AfterModeling)
    
    line29.SetVisibility(NXOpen.SmartObject.VisibilityOption.Visible)
    
    markId74 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Assembly Constraints")
    
    objects32 = [NXOpen.TaggedObject.Null] * 1 
    objects32[0] = line28
    nErrs53 = theSession.UpdateManager.AddObjectsToDeleteList(objects32)
    
    objects33 = [NXOpen.TaggedObject.Null] * 1 
    objects33[0] = line27
    nErrs54 = theSession.UpdateManager.AddObjectsToDeleteList(objects33)
    
    objects34 = [NXOpen.TaggedObject.Null] * 1 
    objects34[0] = line29
    nErrs55 = theSession.UpdateManager.AddObjectsToDeleteList(objects34)
    
    theSession.DeleteUndoMark(markId74, None)
    
    markId75 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Assembly Constraints")
    
    nErrs56 = theSession.UpdateManager.DoUpdate(markId72)
    
    componentNetwork14.Solve()
    
    componentPositioner14.ClearNetwork()
    
    nErrs57 = theSession.UpdateManager.AddToDeleteList(componentNetwork14)
    
    componentPositioner14.DeleteNonPersistentConstraints()
    
    nErrs58 = theSession.UpdateManager.DoUpdate(markId72)
    
    theSession.DeleteUndoMark(markId75, None)
    
    theSession.SetUndoMarkName(markId71, "Assembly Constraints")
    
    componentPositioner14.PrimaryArrangement = NXOpen.Assemblies.Arrangement.Null
    
    componentPositioner14.EndAssemblyConstraints()
    
    theSession.DeleteUndoMark(markId72, None)
    
    theSession.DeleteUndoMark(markId73, None)
    
    theSession.DeleteUndoMark(markId70, None)
    
    # ----------------------------------------------
    #   Menu: Edit->Delete...
    # ----------------------------------------------
    markId76 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Delete")
    
    notifyOnDelete5 = theSession.Preferences.Modeling.NotifyOnDelete
    
    theSession.UpdateManager.ClearErrorList()
    
    markId77 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Delete")
    
    objects35 = [NXOpen.TaggedObject.Null] * 1 
    displayedConstraint1 = workPart.FindObject("ENTITY 160 1 1")
    objects35[0] = displayedConstraint1
    nErrs59 = theSession.UpdateManager.AddObjectsToDeleteList(objects35)
    
    notifyOnDelete6 = theSession.Preferences.Modeling.NotifyOnDelete
    
    id3 = theSession.NewestVisibleUndoMark
    
    nErrs60 = theSession.UpdateManager.DoUpdate(id3)
    
    theSession.DeleteUndoMark(markId76, None)
    
    # ----------------------------------------------
    #   Menu: Assemblies->Component Position->Assembly Constraints...
    # ----------------------------------------------
    markId78 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Constraints with Positioning Task")
    
    markId79 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    componentPositioner15 = workPart.ComponentAssembly.Positioner
    
    componentPositioner15.ClearNetwork()
    
    componentPositioner15.PrimaryArrangement = arrangement2
    
    componentPositioner15.BeginAssemblyConstraints()
    
    allowInterpartPositioning15 = theSession.Preferences.Assemblies.InterpartPositioning
    
    expression123 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", NXOpen.Unit.Null)
    
    expression124 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", unit3)
    
    expression125 = workPart.Expressions.CreateSystemExpressionWithUnits("0.0", unit3)
    
    expression126 = workPart.Expressions.CreateSystemExpressionWithUnits("0.0", unit4)
    
    expression127 = workPart.Expressions.CreateSystemExpressionWithUnits("1", NXOpen.Unit.Null)
    
    expression128 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", unit3)
    
    expression129 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit3)
    
    expression130 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit4)
    
    network15 = componentPositioner15.EstablishNetwork()
    
    componentNetwork15 = network15
    componentNetwork15.MoveObjectsState = True
    
    componentNetwork15.DisplayComponent = NXOpen.Assemblies.Component.Null
    
    componentNetwork15.NetworkArrangementsMode = NXOpen.Positioning.ComponentNetwork.ArrangementsMode.Existing
    
    theSession.SetUndoMarkName(markId79, "Assembly Constraints Dialog")
    
    componentNetwork15.MoveObjectsState = True
    
    componentNetwork15.NetworkArrangementsMode = NXOpen.Positioning.ComponentNetwork.ArrangementsMode.Existing
    
    markId80 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Assembly Constraints Update")
    
    line30 = workPart.Lines.CreateFaceAxis(face6, NXOpen.SmartObject.UpdateOption.AfterModeling)
    
    rotMatrix29 = NXOpen.Matrix3x3()
    
    rotMatrix29.Xx = -0.97395876985472074
    rotMatrix29.Xy = -0.098049611442956638
    rotMatrix29.Xz = -0.20442746468851011
    rotMatrix29.Yx = -0.15002516010309622
    rotMatrix29.Yy = -0.39731839756642401
    rotMatrix29.Yz = 0.90533449193725712
    rotMatrix29.Zx = -0.16999048784895993
    rotMatrix29.Zy = 0.91242773119362064
    rotMatrix29.Zz = 0.37226182907966565
    translation31 = NXOpen.Point3d(18.136121472431498, -134.47444454646813, 362.00240531387391)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix29, translation31, 0.54851507135918609)
    
    line31 = workPart.Lines.CreateFaceAxis(face7, NXOpen.SmartObject.UpdateOption.AfterModeling)
    
    objects36 = [NXOpen.TaggedObject.Null] * 1 
    objects36[0] = line31
    nErrs61 = theSession.UpdateManager.AddObjectsToDeleteList(objects36)
    
    objects37 = [NXOpen.TaggedObject.Null] * 1 
    objects37[0] = line30
    nErrs62 = theSession.UpdateManager.AddObjectsToDeleteList(objects37)
    
    line32 = workPart.Lines.CreateFaceAxis(face7, NXOpen.SmartObject.UpdateOption.AfterModeling)
    
    line32.SetVisibility(NXOpen.SmartObject.VisibilityOption.Visible)
    
    line33 = workPart.Lines.CreateFaceAxis(face2, NXOpen.SmartObject.UpdateOption.AfterModeling)
    
    line33.SetVisibility(NXOpen.SmartObject.VisibilityOption.Visible)
    
    markId81 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constraint")
    
    constraint7 = componentPositioner15.CreateConstraint(True)
    
    componentConstraint7 = constraint7
    componentConstraint7.ConstraintAlignment = NXOpen.Positioning.Constraint.Alignment.InferAlign
    
    componentConstraint7.ConstraintType = NXOpen.Positioning.Constraint.Type.Touch
    
    constraintReference13 = componentConstraint7.CreateConstraintReference(component9, face7, True, False, False)
    
    helpPoint13 = NXOpen.Point3d(-178.84156484738665, 25.679495428354535, -1.8921906469593139)
    constraintReference13.HelpPoint = helpPoint13
    
    constraintReference14 = componentConstraint7.CreateConstraintReference(component6, face2, True, False, False)
    
    helpPoint14 = NXOpen.Point3d(-139.66157809905332, -347.00059231413525, -72.846597224256669)
    constraintReference14.HelpPoint = helpPoint14
    
    constraintReference14.SetFixHint(True)
    
    objects38 = [NXOpen.TaggedObject.Null] * 1 
    objects38[0] = line32
    nErrs63 = theSession.UpdateManager.AddObjectsToDeleteList(objects38)
    
    objects39 = [NXOpen.TaggedObject.Null] * 1 
    objects39[0] = line33
    nErrs64 = theSession.UpdateManager.AddObjectsToDeleteList(objects39)
    
    componentNetwork15.Solve()
    
    rotMatrix30 = NXOpen.Matrix3x3()
    
    rotMatrix30.Xx = -0.20489666149600541
    rotMatrix30.Xy = -0.94742380096373469
    rotMatrix30.Xz = -0.24577530281788959
    rotMatrix30.Yx = -0.19602114803065437
    rotMatrix30.Yy = -0.20629568083187971
    rotMatrix30.Yz = 0.95865416162183237
    rotMatrix30.Zx = -0.95895415303993692
    rotMatrix30.Zy = 0.24460219426150914
    rotMatrix30.Zz = -0.14344580485297917
    translation32 = NXOpen.Point3d(-184.02789795859064, -77.408777286154503, 75.728107941554015)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix30, translation32, 0.54851507135918609)
    
    markId82 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Assembly Constraints")
    
    theSession.DeleteUndoMark(markId82, None)
    
    markId83 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Assembly Constraints")
    
    nErrs65 = theSession.UpdateManager.DoUpdate(markId80)
    
    componentNetwork15.Solve()
    
    componentPositioner15.ClearNetwork()
    
    nErrs66 = theSession.UpdateManager.AddToDeleteList(componentNetwork15)
    
    componentPositioner15.DeleteNonPersistentConstraints()
    
    nErrs67 = theSession.UpdateManager.DoUpdate(markId80)
    
    theSession.DeleteUndoMark(markId83, None)
    
    theSession.SetUndoMarkName(markId79, "Assembly Constraints")
    
    componentPositioner15.PrimaryArrangement = NXOpen.Assemblies.Arrangement.Null
    
    componentPositioner15.EndAssemblyConstraints()
    
    theSession.DeleteUndoMark(markId80, None)
    
    theSession.DeleteUndoMark(markId81, None)
    
    theSession.DeleteUndoMark(markId78, None)
    
    # ----------------------------------------------
    #   Menu: Assemblies->Component Position->Assembly Constraints...
    # ----------------------------------------------
    markId84 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Constraints with Positioning Task")
    
    markId85 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    componentPositioner16 = workPart.ComponentAssembly.Positioner
    
    componentPositioner16.ClearNetwork()
    
    componentPositioner16.PrimaryArrangement = arrangement2
    
    componentPositioner16.BeginAssemblyConstraints()
    
    allowInterpartPositioning16 = theSession.Preferences.Assemblies.InterpartPositioning
    
    expression131 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", NXOpen.Unit.Null)
    
    expression132 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", unit3)
    
    expression133 = workPart.Expressions.CreateSystemExpressionWithUnits("0.0", unit3)
    
    expression134 = workPart.Expressions.CreateSystemExpressionWithUnits("0.0", unit4)
    
    expression135 = workPart.Expressions.CreateSystemExpressionWithUnits("1", NXOpen.Unit.Null)
    
    expression136 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", unit3)
    
    expression137 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit3)
    
    expression138 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit4)
    
    network16 = componentPositioner16.EstablishNetwork()
    
    componentNetwork16 = network16
    componentNetwork16.MoveObjectsState = True
    
    componentNetwork16.DisplayComponent = NXOpen.Assemblies.Component.Null
    
    componentNetwork16.NetworkArrangementsMode = NXOpen.Positioning.ComponentNetwork.ArrangementsMode.Existing
    
    theSession.SetUndoMarkName(markId85, "Assembly Constraints Dialog")
    
    componentNetwork16.MoveObjectsState = True
    
    componentNetwork16.NetworkArrangementsMode = NXOpen.Positioning.ComponentNetwork.ArrangementsMode.Existing
    
    markId86 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Assembly Constraints Update")
    
    line34 = workPart.Lines.CreateFaceAxis(face7, NXOpen.SmartObject.UpdateOption.AfterModeling)
    
    line34.SetVisibility(NXOpen.SmartObject.VisibilityOption.Visible)
    
    componentPositioner16.PrimaryArrangement = NXOpen.Assemblies.Arrangement.Null
    
    componentPositioner16.EndAssemblyConstraints()
    
    theSession.DeleteUndoMark(markId86, None)
    
    objects40 = [NXOpen.TaggedObject.Null] * 1 
    objects40[0] = line34
    nErrs68 = theSession.UpdateManager.AddObjectsToDeleteList(objects40)
    
    theSession.UndoToMark(markId85, None)
    
    theSession.DeleteUndoMark(markId85, None)
    
    theSession.DeleteUndoMark(markId84, None)
    
    # ----------------------------------------------
    #   Menu: Assemblies->Component Position->Assembly Constraints...
    # ----------------------------------------------
    markId87 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Constraints with Positioning Task")
    
    markId88 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    componentPositioner17 = workPart.ComponentAssembly.Positioner
    
    componentPositioner17.ClearNetwork()
    
    componentPositioner17.PrimaryArrangement = arrangement2
    
    componentPositioner17.BeginAssemblyConstraints()
    
    allowInterpartPositioning17 = theSession.Preferences.Assemblies.InterpartPositioning
    
    expression139 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", NXOpen.Unit.Null)
    
    expression140 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", unit3)
    
    expression141 = workPart.Expressions.CreateSystemExpressionWithUnits("0.0", unit3)
    
    expression142 = workPart.Expressions.CreateSystemExpressionWithUnits("0.0", unit4)
    
    expression143 = workPart.Expressions.CreateSystemExpressionWithUnits("1", NXOpen.Unit.Null)
    
    expression144 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", unit3)
    
    expression145 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit3)
    
    expression146 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit4)
    
    network17 = componentPositioner17.EstablishNetwork()
    
    componentNetwork17 = network17
    componentNetwork17.MoveObjectsState = True
    
    componentNetwork17.DisplayComponent = NXOpen.Assemblies.Component.Null
    
    componentNetwork17.NetworkArrangementsMode = NXOpen.Positioning.ComponentNetwork.ArrangementsMode.Existing
    
    theSession.SetUndoMarkName(markId88, "Assembly Constraints Dialog")
    
    componentNetwork17.MoveObjectsState = True
    
    componentNetwork17.NetworkArrangementsMode = NXOpen.Positioning.ComponentNetwork.ArrangementsMode.Existing
    
    markId89 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Assembly Constraints Update")
    
    line35 = workPart.Lines.CreateFaceAxis(face7, NXOpen.SmartObject.UpdateOption.AfterModeling)
    
    line35.SetVisibility(NXOpen.SmartObject.VisibilityOption.Visible)
    
    scaleAboutPoint98 = NXOpen.Point3d(-25.082872015241151, -103.70802852455482, 0.0)
    viewCenter98 = NXOpen.Point3d(25.082872015241151, 103.70802852455482, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint98, viewCenter98)
    
    scaleAboutPoint99 = NXOpen.Point3d(-20.066297612192919, -82.966422819643839, 0.0)
    viewCenter99 = NXOpen.Point3d(20.066297612192919, 82.966422819643839, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint99, viewCenter99)
    
    scaleAboutPoint100 = NXOpen.Point3d(-16.053038089754335, -66.373138255715062, 0.0)
    viewCenter100 = NXOpen.Point3d(16.053038089754306, 66.373138255715062, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint100, viewCenter100)
    
    scaleAboutPoint101 = NXOpen.Point3d(-14.324249372396213, -49.887902986621071, 0.0)
    viewCenter101 = NXOpen.Point3d(14.32424937239613, 49.887902986621071, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint101, viewCenter101)
    
    scaleAboutPoint102 = NXOpen.Point3d(-11.459399497917001, -39.910322389296908, 0.0)
    viewCenter102 = NXOpen.Point3d(11.4593994979169, 39.910322389296773, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint102, viewCenter102)
    
    scaleAboutPoint103 = NXOpen.Point3d(-9.1675195983335485, -31.928257911437534, 0.0)
    viewCenter103 = NXOpen.Point3d(9.167519598333536, 31.928257911437427, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint103, viewCenter103)
    
    scaleAboutPoint104 = NXOpen.Point3d(-7.3340156786668604, -25.542606329150029, 0.0)
    viewCenter104 = NXOpen.Point3d(7.3340156786668063, 25.54260632914994, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint104, viewCenter104)
    
    objects41 = [NXOpen.TaggedObject.Null] * 1 
    objects41[0] = line35
    nErrs69 = theSession.UpdateManager.AddObjectsToDeleteList(objects41)
    
    scaleAboutPoint105 = NXOpen.Point3d(13.555284150915226, -17.500478791853332, 0.0)
    viewCenter105 = NXOpen.Point3d(-13.555284150915277, 17.500478791853265, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint105, viewCenter105)
    
    scaleAboutPoint106 = NXOpen.Point3d(20.864010120345284, -21.875598489816667, 0.0)
    viewCenter106 = NXOpen.Point3d(-20.864010120345341, 21.875598489816582, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint106, viewCenter106)
    
    scaleAboutPoint107 = NXOpen.Point3d(28.4509228913799, -26.712255381351198, 0.0)
    viewCenter107 = NXOpen.Point3d(-28.450922891379982, 26.712255381351092, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint107, viewCenter107)
    
    scaleAboutPoint108 = NXOpen.Point3d(51.172146033801361, -27.66061947773062, 0.0)
    viewCenter108 = NXOpen.Point3d(-51.172146033801496, 27.660619477730485, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint108, viewCenter108)
    
    scaleAboutPoint109 = NXOpen.Point3d(64.953061809313539, -34.328804530397626, 0.0)
    viewCenter109 = NXOpen.Point3d(-64.953061809313638, 34.328804530397626, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint109, viewCenter109)
    
    scaleAboutPoint110 = NXOpen.Point3d(81.808751803555552, -42.602293392040288, 0.0)
    viewCenter110 = NXOpen.Point3d(-81.808751803555666, 42.602293392040288, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint110, viewCenter110)
    
    scaleAboutPoint111 = NXOpen.Point3d(103.4186107705325, -52.866976401354428, 0.0)
    viewCenter111 = NXOpen.Point3d(-103.41861077053262, 52.866976401354428, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint111, viewCenter111)
    
    scaleAboutPoint112 = NXOpen.Point3d(161.10921640558709, -58.365913727772465, 0.0)
    viewCenter112 = NXOpen.Point3d(-161.10921640558718, 58.365913727772465, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint112, viewCenter112)
    
    scaleAboutPoint113 = NXOpen.Point3d(201.38652050698371, -72.354438505503182, 0.0)
    viewCenter113 = NXOpen.Point3d(-201.38652050698391, 72.354438505503182, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint113, viewCenter113)
    
    scaleAboutPoint114 = NXOpen.Point3d(253.24053476926096, -90.443048131878953, 0.0)
    viewCenter114 = NXOpen.Point3d(-253.24053476926122, 90.443048131878953, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint114, viewCenter114)
    
    scaleAboutPoint115 = NXOpen.Point3d(404.1673713393339, -109.28534982602062, 0.0)
    viewCenter115 = NXOpen.Point3d(-404.16737133933424, 109.28534982602062, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint115, viewCenter115)
    
    scaleAboutPoint116 = NXOpen.Point3d(505.20921417416736, -136.60668728252577, 0.0)
    viewCenter116 = NXOpen.Point3d(-505.20921417416758, 136.60668728252577, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint116, viewCenter116)
    
    origin21 = NXOpen.Point3d(-50.913386030914957, -470.71727552589152, 65.622221998342567)
    workPart.ModelingViews.WorkView.SetOrigin(origin21)
    
    origin22 = NXOpen.Point3d(-50.913386030914957, -470.71727552589152, 65.622221998342567)
    workPart.ModelingViews.WorkView.SetOrigin(origin22)
    
    rotMatrix31 = NXOpen.Matrix3x3()
    
    rotMatrix31.Xx = 0.75392799708628211
    rotMatrix31.Xy = -0.65692675325682992
    rotMatrix31.Xz = 0.0063099972196909611
    rotMatrix31.Yx = -0.15517258443708112
    rotMatrix31.Yy = -0.16873569446219638
    rotMatrix31.Yz = 0.97337029667721009
    rotMatrix31.Zx = -0.63836826694987747
    rotMatrix31.Zy = -0.73483025677349767
    rotMatrix31.Zz = -0.22915158625156862
    translation33 = NXOpen.Point3d(-321.4830470878685, -156.93086549355277, -226.72639687316402)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix31, translation33, 0.17973741858297831)
    
    scaleAboutPoint117 = NXOpen.Point3d(-76.546850632449932, -128.06876932736765, 0.0)
    viewCenter117 = NXOpen.Point3d(76.54685063244942, 128.06876932736765, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint117, viewCenter117)
    
    scaleAboutPoint118 = NXOpen.Point3d(-67.125699785379112, -102.45501546189412, 0.0)
    viewCenter118 = NXOpen.Point3d(67.1256997853786, 102.45501546189412, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint118, viewCenter118)
    
    scaleAboutPoint119 = NXOpen.Point3d(-63.121710675374182, -81.021897284808418, 0.0)
    viewCenter119 = NXOpen.Point3d(63.121710675373699, 81.021897284808418, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint119, viewCenter119)
    
    scaleAboutPoint120 = NXOpen.Point3d(-50.497368540299348, -64.817517827846729, 0.0)
    viewCenter120 = NXOpen.Point3d(50.497368540298829, 64.817517827846729, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint120, viewCenter120)
    
    scaleAboutPoint121 = NXOpen.Point3d(-40.397894832239572, -51.854014262277381, 0.0)
    viewCenter121 = NXOpen.Point3d(40.397894832239061, 51.854014262277381, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint121, viewCenter121)
    
    scaleAboutPoint122 = NXOpen.Point3d(-32.318315865791661, -41.483211409821905, 0.0)
    viewCenter122 = NXOpen.Point3d(32.318315865791121, 41.483211409821905, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint122, viewCenter122)
    
    markId90 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constraint")
    
    constraint8 = componentPositioner17.CreateConstraint(True)
    
    componentConstraint8 = constraint8
    componentConstraint8.ConstraintAlignment = NXOpen.Positioning.Constraint.Alignment.InferAlign
    
    componentConstraint8.ConstraintType = NXOpen.Positioning.Constraint.Type.Touch
    
    constraintReference15 = componentConstraint8.CreateConstraintReference(component9, edge4, False, False, False)
    
    helpPoint15 = NXOpen.Point3d(-148.13350837606575, -114.32050457164542, -78.159449319075037)
    constraintReference15.HelpPoint = helpPoint15
    
    constraintReference16 = componentConstraint8.CreateConstraintReference(component6, edge2, False, False, False)
    
    helpPoint16 = NXOpen.Point3d(-133.62786973205718, -488.37842851963455, -64.87198981435499)
    constraintReference16.HelpPoint = helpPoint16
    
    constraintReference16.SetFixHint(True)
    
    componentNetwork17.Solve()
    
    line36 = workPart.Lines.CreateFaceAxis(face8, NXOpen.SmartObject.UpdateOption.AfterModeling)
    
    line36.SetVisibility(NXOpen.SmartObject.VisibilityOption.Visible)
    
    markId91 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Assembly Constraints")
    
    objects42 = [NXOpen.TaggedObject.Null] * 1 
    objects42[0] = line36
    nErrs70 = theSession.UpdateManager.AddObjectsToDeleteList(objects42)
    
    theSession.DeleteUndoMark(markId91, None)
    
    markId92 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Assembly Constraints")
    
    nErrs71 = theSession.UpdateManager.DoUpdate(markId89)
    
    componentNetwork17.Solve()
    
    componentPositioner17.ClearNetwork()
    
    nErrs72 = theSession.UpdateManager.AddToDeleteList(componentNetwork17)
    
    componentPositioner17.DeleteNonPersistentConstraints()
    
    nErrs73 = theSession.UpdateManager.DoUpdate(markId89)
    
    theSession.DeleteUndoMark(markId92, None)
    
    theSession.SetUndoMarkName(markId88, "Assembly Constraints")
    
    componentPositioner17.PrimaryArrangement = NXOpen.Assemblies.Arrangement.Null
    
    componentPositioner17.EndAssemblyConstraints()
    
    theSession.DeleteUndoMark(markId89, None)
    
    theSession.DeleteUndoMark(markId90, None)
    
    theSession.DeleteUndoMark(markId87, None)
    
    rotMatrix32 = NXOpen.Matrix3x3()
    
    rotMatrix32.Xx = 0.8817324853065861
    rotMatrix32.Xy = -0.47076208515975504
    rotMatrix32.Xz = -0.030510383988373416
    rotMatrix32.Yx = 0.02341614313679391
    rotMatrix32.Yy = -0.020920471639507891
    rotMatrix32.Yz = 0.9995068874735088
    rotMatrix32.Zx = -0.47116823810150466
    rotMatrix32.Zy = -0.88201212749169544
    rotMatrix32.Zz = -0.0074228270830129055
    translation34 = NXOpen.Point3d(-161.11340865064048, 15.368260910973177, -289.40023898188048)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix32, translation34, 0.68564383919898342)
    
    scaleAboutPoint123 = NXOpen.Point3d(-52.095195723962561, -43.991498611346017, 0.0)
    viewCenter123 = NXOpen.Point3d(52.095195723961908, 43.991498611345754, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint123, viewCenter123)
    
    scaleAboutPoint124 = NXOpen.Point3d(-65.118994654953127, -54.50701034081245, 0.0)
    viewCenter124 = NXOpen.Point3d(65.118994654952459, 54.50701034081245, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint124, viewCenter124)
    
    scaleAboutPoint125 = NXOpen.Point3d(-50.165744030482493, 23.92520099915285, 0.0)
    viewCenter125 = NXOpen.Point3d(50.165744030481804, -23.925200999152981, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint125, viewCenter125)
    
    scaleAboutPoint126 = NXOpen.Point3d(-62.707180038103033, 29.906501248941229, 0.0)
    viewCenter126 = NXOpen.Point3d(62.707180038102372, -29.906501248941066, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint126, viewCenter126)
    
    markId93 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Change Displayed Part")
    
    status5, partLoadStatus5 = theSession.Parts.SetActiveDisplay(part1, NXOpen.DisplayPartOption.AllowAdditional, NXOpen.PartDisplayPartWorkPartOption.UseLast)
    
    workPart = theSession.Parts.Work # model6
    displayPart = theSession.Parts.Display # model6
    partLoadStatus5.Dispose()
    markId94 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Change Displayed Part")
    
    status6, partLoadStatus6 = theSession.Parts.SetActiveDisplay(part3, NXOpen.DisplayPartOption.AllowAdditional, NXOpen.PartDisplayPartWorkPartOption.UseLast)
    
    workPart = theSession.Parts.Work # assembly2
    displayPart = theSession.Parts.Display # assembly2
    partLoadStatus6.Dispose()
    theSession.DeleteUndoMark(markId94, None)
    
    theSession.DeleteUndoMark(markId93, None)
    
    rotMatrix33 = NXOpen.Matrix3x3()
    
    rotMatrix33.Xx = -0.79004103587825059
    rotMatrix33.Xy = -0.61241470215610694
    rotMatrix33.Xz = 0.027989180257308698
    rotMatrix33.Yx = 0.04438856981050366
    rotMatrix33.Yy = -0.011608289103856782
    rotMatrix33.Yz = 0.99894689673388681
    rotMatrix33.Zx = -0.61144485973684315
    rotMatrix33.Zy = 0.79045144076479179
    rotMatrix33.Zz = 0.036355237508020666
    translation35 = NXOpen.Point3d(-292.18773622499543, 33.790173073717227, 544.71479491546438)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix33, translation35, 0.43881205708734944)
    
    rotMatrix34 = NXOpen.Matrix3x3()
    
    rotMatrix34.Xx = -0.46099018630580879
    rotMatrix34.Xy = 0.88687091129445839
    rotMatrix34.Xz = 0.03079017423595188
    rotMatrix34.Yx = 0.034149160693110664
    rotMatrix34.Yy = -0.016941998969669872
    rotMatrix34.Yz = 0.99927313758294889
    rotMatrix34.Zx = 0.8867479252604431
    rotMatrix34.Zy = 0.46170656847250535
    rotMatrix34.Zz = -0.02247580200241911
    translation36 = NXOpen.Point3d(463.59846091911868, 30.928010616977804, 409.03009701768815)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix34, translation36, 0.43881205708734944)
    
    rotMatrix35 = NXOpen.Matrix3x3()
    
    rotMatrix35.Xx = -0.61160627028416625
    rotMatrix35.Xy = 0.79057890276661247
    rotMatrix35.Xz = 0.030377107325066762
    rotMatrix35.Yx = -3.8723496548475136e-05
    rotMatrix35.Yy = -0.038425457984297605
    rotMatrix35.Yz = 0.99926146862529996
    rotMatrix35.Zx = 0.79116228970394631
    rotMatrix35.Zy = 0.61115340355678638
    rotMatrix35.Zz = 0.023531865021149484
    translation37 = NXOpen.Point3d(412.41232667211017, 19.498805450053617, 483.28630463704513)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix35, translation37, 0.43881205708734944)
    
    # ----------------------------------------------
    #   Menu: Assemblies->Component Position->Assembly Constraints...
    # ----------------------------------------------
    markId95 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Constraints with Positioning Task")
    
    markId96 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    componentPositioner18 = workPart.ComponentAssembly.Positioner
    
    componentPositioner18.ClearNetwork()
    
    componentPositioner18.PrimaryArrangement = arrangement2
    
    componentPositioner18.BeginAssemblyConstraints()
    
    allowInterpartPositioning18 = theSession.Preferences.Assemblies.InterpartPositioning
    
    expression147 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", NXOpen.Unit.Null)
    
    expression148 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", unit3)
    
    expression149 = workPart.Expressions.CreateSystemExpressionWithUnits("0.0", unit3)
    
    expression150 = workPart.Expressions.CreateSystemExpressionWithUnits("0.0", unit4)
    
    expression151 = workPart.Expressions.CreateSystemExpressionWithUnits("1", NXOpen.Unit.Null)
    
    expression152 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", unit3)
    
    expression153 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit3)
    
    expression154 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit4)
    
    network18 = componentPositioner18.EstablishNetwork()
    
    componentNetwork18 = network18
    componentNetwork18.MoveObjectsState = True
    
    componentNetwork18.DisplayComponent = NXOpen.Assemblies.Component.Null
    
    componentNetwork18.NetworkArrangementsMode = NXOpen.Positioning.ComponentNetwork.ArrangementsMode.Existing
    
    theSession.SetUndoMarkName(markId96, "Assembly Constraints Dialog")
    
    componentNetwork18.MoveObjectsState = True
    
    componentNetwork18.NetworkArrangementsMode = NXOpen.Positioning.ComponentNetwork.ArrangementsMode.Existing
    
    markId97 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Assembly Constraints Update")
    
    component10 = nXObject3
    face9 = component10.FindObject("PROTO#.Features|EXTRUDE(4)|FACE 140 {(-70,-0.1672952755923,8.1078093530407) EXTRUDE(2)}")
    line37 = workPart.Lines.CreateFaceAxis(face9, NXOpen.SmartObject.UpdateOption.AfterModeling)
    
    line37.SetVisibility(NXOpen.SmartObject.VisibilityOption.Visible)
    
    face10 = component6.FindObject("PROTO#.Features|EXTRUDE(6)|FACE 140 {(150,-70,9.9999999999997) EXTRUDE(2)}")
    line38 = workPart.Lines.CreateFaceAxis(face10, NXOpen.SmartObject.UpdateOption.AfterModeling)
    
    line38.SetVisibility(NXOpen.SmartObject.VisibilityOption.Visible)
    
    markId98 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constraint")
    
    constraint9 = componentPositioner18.CreateConstraint(True)
    
    componentConstraint9 = constraint9
    componentConstraint9.ConstraintAlignment = NXOpen.Positioning.Constraint.Alignment.InferAlign
    
    componentConstraint9.ConstraintType = NXOpen.Positioning.Constraint.Type.Touch
    
    constraintReference17 = componentConstraint9.CreateConstraintReference(component10, face9, True, False, False)
    
    helpPoint17 = NXOpen.Point3d(-39.185352080101495, -649.52255707739823, -1.8921906469595307)
    constraintReference17.HelpPoint = helpPoint17
    
    constraintReference18 = componentConstraint9.CreateConstraintReference(component6, face10, True, False, False)
    
    helpPoint18 = NXOpen.Point3d(-9.8543866045130812, -348.86008169091684, -72.846597224256826)
    constraintReference18.HelpPoint = helpPoint18
    
    constraintReference18.SetFixHint(True)
    
    objects43 = [NXOpen.TaggedObject.Null] * 1 
    objects43[0] = line38
    nErrs74 = theSession.UpdateManager.AddObjectsToDeleteList(objects43)
    
    objects44 = [NXOpen.TaggedObject.Null] * 1 
    objects44[0] = line37
    nErrs75 = theSession.UpdateManager.AddObjectsToDeleteList(objects44)
    
    componentNetwork18.Solve()
    
    markId99 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Assembly Constraints")
    
    theSession.DeleteUndoMark(markId99, None)
    
    markId100 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Assembly Constraints")
    
    nErrs76 = theSession.UpdateManager.DoUpdate(markId97)
    
    componentNetwork18.Solve()
    
    componentPositioner18.ClearNetwork()
    
    nErrs77 = theSession.UpdateManager.AddToDeleteList(componentNetwork18)
    
    componentPositioner18.DeleteNonPersistentConstraints()
    
    nErrs78 = theSession.UpdateManager.DoUpdate(markId97)
    
    theSession.DeleteUndoMark(markId100, None)
    
    theSession.SetUndoMarkName(markId96, "Assembly Constraints")
    
    componentPositioner18.PrimaryArrangement = NXOpen.Assemblies.Arrangement.Null
    
    componentPositioner18.EndAssemblyConstraints()
    
    theSession.DeleteUndoMark(markId97, None)
    
    theSession.DeleteUndoMark(markId98, None)
    
    theSession.DeleteUndoMark(markId95, None)
    
    # ----------------------------------------------
    #   Menu: Assemblies->Component Position->Assembly Constraints...
    # ----------------------------------------------
    markId101 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Constraints with Positioning Task")
    
    markId102 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    componentPositioner19 = workPart.ComponentAssembly.Positioner
    
    componentPositioner19.ClearNetwork()
    
    componentPositioner19.PrimaryArrangement = arrangement2
    
    componentPositioner19.BeginAssemblyConstraints()
    
    allowInterpartPositioning19 = theSession.Preferences.Assemblies.InterpartPositioning
    
    expression155 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", NXOpen.Unit.Null)
    
    expression156 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", unit3)
    
    expression157 = workPart.Expressions.CreateSystemExpressionWithUnits("0.0", unit3)
    
    expression158 = workPart.Expressions.CreateSystemExpressionWithUnits("0.0", unit4)
    
    expression159 = workPart.Expressions.CreateSystemExpressionWithUnits("1", NXOpen.Unit.Null)
    
    expression160 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", unit3)
    
    expression161 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit3)
    
    expression162 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit4)
    
    network19 = componentPositioner19.EstablishNetwork()
    
    componentNetwork19 = network19
    componentNetwork19.MoveObjectsState = True
    
    componentNetwork19.DisplayComponent = NXOpen.Assemblies.Component.Null
    
    componentNetwork19.NetworkArrangementsMode = NXOpen.Positioning.ComponentNetwork.ArrangementsMode.Existing
    
    theSession.SetUndoMarkName(markId102, "Assembly Constraints Dialog")
    
    componentNetwork19.MoveObjectsState = True
    
    componentNetwork19.NetworkArrangementsMode = NXOpen.Positioning.ComponentNetwork.ArrangementsMode.Existing
    
    markId103 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Assembly Constraints Update")
    
    line39 = workPart.Lines.CreateFaceAxis(face9, NXOpen.SmartObject.UpdateOption.AfterModeling)
    
    objects45 = [NXOpen.TaggedObject.Null] * 1 
    objects45[0] = line39
    nErrs79 = theSession.UpdateManager.AddObjectsToDeleteList(objects45)
    
    face11 = component10.FindObject("PROTO#.Features|EXTRUDE(2)|FACE 140 {(20,0,-40) EXTRUDE(2)}")
    line40 = workPart.Lines.CreateFaceAxis(face11, NXOpen.SmartObject.UpdateOption.AfterModeling)
    
    line40.SetVisibility(NXOpen.SmartObject.VisibilityOption.Visible)
    
    line41 = workPart.Lines.CreateFaceAxis(face9, NXOpen.SmartObject.UpdateOption.AfterModeling)
    
    line41.SetVisibility(NXOpen.SmartObject.VisibilityOption.Visible)
    
    objects46 = [NXOpen.TaggedObject.Null] * 1 
    objects46[0] = line40
    nErrs80 = theSession.UpdateManager.AddObjectsToDeleteList(objects46)
    
    objects47 = [NXOpen.TaggedObject.Null] * 1 
    objects47[0] = line41
    nErrs81 = theSession.UpdateManager.AddObjectsToDeleteList(objects47)
    
    face12 = component6.FindObject("PROTO#.Features|EXTRUDE(4)|FACE 160 {(201.0050506338832,-70,41.0050506338833) EXTRUDE(2)}")
    line42 = workPart.Lines.CreateFaceAxis(face12, NXOpen.SmartObject.UpdateOption.AfterModeling)
    
    line42.SetVisibility(NXOpen.SmartObject.VisibilityOption.Visible)
    
    rotMatrix36 = NXOpen.Matrix3x3()
    
    rotMatrix36.Xx = 0.43511132783404999
    rotMatrix36.Xy = 0.89849261891595433
    rotMatrix36.Xz = 0.058216373504787255
    rotMatrix36.Yx = -0.045810796048441293
    rotMatrix36.Yy = -0.042482092408279576
    rotMatrix36.Yz = 0.9980464131442115
    rotMatrix36.Zx = 0.89921048890452104
    rotMatrix36.Zy = -0.43692823847649509
    rotMatrix36.Zz = 0.022676222479252658
    translation38 = NXOpen.Point3d(496.0679308221579, 16.217534315835522, -110.84791099614043)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix36, translation38, 0.43881205708734944)
    
    line43 = workPart.Lines.CreateFaceAxis(face10, NXOpen.SmartObject.UpdateOption.AfterModeling)
    
    line43.SetVisibility(NXOpen.SmartObject.VisibilityOption.Visible)
    
    scaleAboutPoint127 = NXOpen.Point3d(49.442199645426676, -27.132914439563663, 0.0)
    viewCenter127 = NXOpen.Point3d(-49.4421996454275, 27.132914439563663, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint127, viewCenter127)
    
    scaleAboutPoint128 = NXOpen.Point3d(61.802749556783326, -33.916143049454568, 0.0)
    viewCenter128 = NXOpen.Point3d(-61.802749556784356, 33.916143049454568, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint128, viewCenter128)
    
    scaleAboutPoint129 = NXOpen.Point3d(77.253436945979303, -42.395178811818205, 0.0)
    viewCenter129 = NXOpen.Point3d(-77.253436945980269, 42.395178811818205, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint129, viewCenter129)
    
    scaleAboutPoint130 = NXOpen.Point3d(61.802749556783304, -33.916143049454554, 0.0)
    viewCenter130 = NXOpen.Point3d(-61.802749556784072, 33.916143049454554, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint130, viewCenter130)
    
    scaleAboutPoint131 = NXOpen.Point3d(49.442199645426747, -27.132914439563645, 0.0)
    viewCenter131 = NXOpen.Point3d(-49.442199645427415, 27.132914439563645, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint131, viewCenter131)
    
    scaleAboutPoint132 = NXOpen.Point3d(39.071396792971321, -21.706331551650916, 0.0)
    viewCenter132 = NXOpen.Point3d(-39.071396792971974, 21.706331551650916, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint132, viewCenter132)
    
    scaleAboutPoint133 = NXOpen.Point3d(31.257117434376987, -17.365065241320863, 0.0)
    viewCenter133 = NXOpen.Point3d(-31.25711743437768, 17.3650652413206, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint133, viewCenter133)
    
    scaleAboutPoint134 = NXOpen.Point3d(25.005693947501594, -13.892052193056692, 0.0)
    viewCenter134 = NXOpen.Point3d(-25.005693947502145, 13.892052193056482, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint134, viewCenter134)
    
    scaleAboutPoint135 = NXOpen.Point3d(20.004555158001185, -11.113641754445352, 0.0)
    viewCenter135 = NXOpen.Point3d(-20.004555158001775, 11.113641754445183, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint135, viewCenter135)
    
    markId104 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constraint")
    
    constraint10 = componentPositioner19.CreateConstraint(True)
    
    componentConstraint10 = constraint10
    componentConstraint10.ConstraintAlignment = NXOpen.Positioning.Constraint.Alignment.InferAlign
    
    componentConstraint10.ConstraintType = NXOpen.Positioning.Constraint.Type.Touch
    
    edge5 = component10.FindObject("PROTO#.Features|EXTRUDE(4)|EDGE * 140 EXTRUDE(2) 120 {(0,-5.1672952755923,-10.5524446848037)(0,9.8327047244077,-1.8921906469593)(0,-5.1672952755923,6.768063390885) EXTRUDE(2)}")
    constraintReference19 = componentConstraint10.CreateConstraintReference(component10, edge5, False, False, False)
    
    helpPoint19 = NXOpen.Point3d(-2.6154754135206058, -789.52255707739289, -65.947454903001784)
    constraintReference19.HelpPoint = helpPoint19
    
    edge6 = component6.FindObject("PROTO#.Features|EXTRUDE(6)|EDGE * 140 EXTRUDE(2) 130 {(158.6602540378446,-140,25.0000000000002)(150,-140,9.9999999999997)(141.3397459621553,-140,25.0000000000002) EXTRUDE(2)}")
    constraintReference20 = componentConstraint10.CreateConstraintReference(component6, edge6, False, False, False)
    
    helpPoint20 = NXOpen.Point3d(-7.3395854285162043, -488.37842851963455, -63.167972577892115)
    constraintReference20.HelpPoint = helpPoint20
    
    constraintReference20.SetFixHint(True)
    
    objects48 = [NXOpen.TaggedObject.Null] * 1 
    objects48[0] = line43
    nErrs82 = theSession.UpdateManager.AddObjectsToDeleteList(objects48)
    
    objects49 = [NXOpen.TaggedObject.Null] * 1 
    objects49[0] = line42
    nErrs83 = theSession.UpdateManager.AddObjectsToDeleteList(objects49)
    
    componentNetwork19.Solve()
    
    line44 = workPart.Lines.CreateFaceAxis(face11, NXOpen.SmartObject.UpdateOption.AfterModeling)
    
    line44.SetVisibility(NXOpen.SmartObject.VisibilityOption.Visible)
    
    line45 = workPart.Lines.CreateFaceAxis(face8, NXOpen.SmartObject.UpdateOption.AfterModeling)
    
    line45.SetVisibility(NXOpen.SmartObject.VisibilityOption.Visible)
    
    markId105 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Assembly Constraints")
    
    objects50 = [NXOpen.TaggedObject.Null] * 1 
    objects50[0] = line44
    nErrs84 = theSession.UpdateManager.AddObjectsToDeleteList(objects50)
    
    objects51 = [NXOpen.TaggedObject.Null] * 1 
    objects51[0] = line45
    nErrs85 = theSession.UpdateManager.AddObjectsToDeleteList(objects51)
    
    theSession.DeleteUndoMark(markId105, None)
    
    markId106 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Assembly Constraints")
    
    nErrs86 = theSession.UpdateManager.DoUpdate(markId103)
    
    componentNetwork19.Solve()
    
    componentPositioner19.ClearNetwork()
    
    nErrs87 = theSession.UpdateManager.AddToDeleteList(componentNetwork19)
    
    componentPositioner19.DeleteNonPersistentConstraints()
    
    nErrs88 = theSession.UpdateManager.DoUpdate(markId103)
    
    theSession.DeleteUndoMark(markId106, None)
    
    theSession.SetUndoMarkName(markId102, "Assembly Constraints")
    
    componentPositioner19.PrimaryArrangement = NXOpen.Assemblies.Arrangement.Null
    
    componentPositioner19.EndAssemblyConstraints()
    
    theSession.DeleteUndoMark(markId103, None)
    
    theSession.DeleteUndoMark(markId104, None)
    
    theSession.DeleteUndoMark(markId101, None)
    
    rotMatrix37 = NXOpen.Matrix3x3()
    
    rotMatrix37.Xx = -0.46248568811986729
    rotMatrix37.Xy = 0.88623984923193944
    rotMatrix37.Xz = -0.026190034701051641
    rotMatrix37.Yx = -0.1105299564809793
    rotMatrix37.Yy = -0.028321374266487141
    rotMatrix37.Yz = 0.99346918849049892
    rotMatrix37.Zx = 0.87971024604957604
    rotMatrix37.Zy = 0.46236006466065693
    rotMatrix37.Zz = 0.1110542822334525
    translation39 = NXOpen.Point3d(436.86536921514255, 38.911930333013231, 267.96586704946878)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix37, translation39, 1.3391481234355151)
    
    scaleAboutPoint136 = NXOpen.Point3d(61.248514557831442, -23.7091024094833, 0.0)
    viewCenter136 = NXOpen.Point3d(-61.248514557831946, 23.709102409483165, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint136, viewCenter136)
    
    scaleAboutPoint137 = NXOpen.Point3d(76.560643197289252, -29.636378011854124, 0.0)
    viewCenter137 = NXOpen.Point3d(-76.560643197289892, 29.636378011853957, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint137, viewCenter137)
    
    scaleAboutPoint138 = NXOpen.Point3d(129.35044153090436, -37.045472514817668, 0.0)
    viewCenter138 = NXOpen.Point3d(-129.35044153090496, 37.045472514817462, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint138, viewCenter138)
    
    scaleAboutPoint139 = NXOpen.Point3d(162.0739422523265, -46.306840643521952, 0.0)
    viewCenter139 = NXOpen.Point3d(-162.07394225232721, 46.306840643521952, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint139, viewCenter139)
    
    scaleAboutPoint140 = NXOpen.Point3d(202.5924278154082, -57.883550804402439, 0.0)
    viewCenter140 = NXOpen.Point3d(-202.59242781540885, 57.883550804402439, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint140, viewCenter140)
    
    scaleAboutPoint141 = NXOpen.Point3d(253.24053476926034, -72.35443850550304, 0.0)
    viewCenter141 = NXOpen.Point3d(-253.24053476926096, 72.35443850550304, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint141, viewCenter141)
    
    scaleAboutPoint142 = NXOpen.Point3d(315.04328432604422, -90.443048131878797, 0.0)
    viewCenter142 = NXOpen.Point3d(-315.04328432604484, 90.443048131878797, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint142, viewCenter142)
    
    scaleAboutPoint143 = NXOpen.Point3d(391.919875238141, -113.0538101648485, 0.0)
    viewCenter143 = NXOpen.Point3d(-391.91987523814169, 113.0538101648485, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint143, viewCenter143)
    
    scaleAboutPoint144 = NXOpen.Point3d(473.41283006530256, -135.42904342664113, 0.0)
    viewCenter144 = NXOpen.Point3d(-473.41283006530335, 135.42904342664113, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint144, viewCenter144)
    
    scaleAboutPoint145 = NXOpen.Point3d(591.76603758162821, -169.2863042833014, 0.0)
    viewCenter145 = NXOpen.Point3d(-591.76603758162912, 169.2863042833014, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint145, viewCenter145)
    
    scaleAboutPoint146 = NXOpen.Point3d(739.70754697703524, -211.60788035412676, 0.0)
    viewCenter146 = NXOpen.Point3d(-739.70754697703649, 211.60788035412676, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint146, viewCenter146)
    
    rotMatrix38 = NXOpen.Matrix3x3()
    
    rotMatrix38.Xx = -0.7938699132569107
    rotMatrix38.Xy = -0.59902466400773424
    rotMatrix38.Xz = -0.10459451580215037
    rotMatrix38.Yx = -0.12367145297975213
    rotMatrix38.Yy = -0.009361721393942056
    rotMatrix38.Yz = 0.99227905847620268
    rotMatrix38.Zx = -0.59537881432189244
    rotMatrix38.Zy = 0.80067584582211748
    rotMatrix38.Zz = -0.066650261617600168
    translation40 = NXOpen.Point3d(655.30777824937695, -200.15240806271197, 373.49208373056541)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix38, translation40, 0.11503194789310622)
    
    rotMatrix39 = NXOpen.Matrix3x3()
    
    rotMatrix39.Xx = -0.71486597763835913
    rotMatrix39.Xy = 0.69366886335024458
    rotMatrix39.Xz = -0.08826178127328832
    rotMatrix39.Yx = -0.092925423356739922
    rotMatrix39.Yy = 0.030862604454791519
    rotMatrix39.Yz = 0.99519463691291976
    rotMatrix39.Zx = 0.69305952104355717
    rotMatrix39.Zy = 0.71963255044824637
    rotMatrix39.Zz = 0.042396846890169572
    translation41 = NXOpen.Point3d(1198.3008204927007, -182.5991592242361, 369.49492182826452)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix39, translation41, 0.11503194789310622)
    
    scaleAboutPoint147 = NXOpen.Point3d(1168.4435132597453, -331.21233446732953, 0.0)
    viewCenter147 = NXOpen.Point3d(-1168.4435132597459, 331.21233446732953, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint147, viewCenter147)
    
    scaleAboutPoint148 = NXOpen.Point3d(934.75481060779589, -264.96986757386361, 0.0)
    viewCenter148 = NXOpen.Point3d(-934.75481060779714, 264.96986757386361, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint148, viewCenter148)
    
    scaleAboutPoint149 = NXOpen.Point3d(747.80384848623635, -211.97589405909088, 0.0)
    viewCenter149 = NXOpen.Point3d(-747.80384848623783, 211.97589405909088, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint149, viewCenter149)
    
    scaleAboutPoint150 = NXOpen.Point3d(572.33491395954445, -116.58674173249996, 0.0)
    viewCenter150 = NXOpen.Point3d(-572.33491395954582, 116.58674173249996, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint150, viewCenter150)
    
    scaleAboutPoint151 = NXOpen.Point3d(457.86793116763562, -92.32727830129312, 0.0)
    viewCenter151 = NXOpen.Point3d(-457.86793116763693, 92.32727830129312, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint151, viewCenter151)
    
    origin23 = NXOpen.Point3d(-34.327402794491299, -479.84520631986589, -9.2402825505003339)
    workPart.ModelingViews.WorkView.SetOrigin(origin23)
    
    origin24 = NXOpen.Point3d(-34.327402794491299, -479.84520631986589, -9.2402825505003339)
    workPart.ModelingViews.WorkView.SetOrigin(origin24)
    
    rotMatrix40 = NXOpen.Matrix3x3()
    
    rotMatrix40.Xx = -0.62302565289687328
    rotMatrix40.Xy = 0.77963702948284075
    rotMatrix40.Xz = -0.063286160348046253
    rotMatrix40.Yx = -0.091225364998474293
    rotMatrix40.Yy = 0.0079325788581729954
    rotMatrix40.Yz = 0.99579867793322285
    rotMatrix40.Zx = 0.77686354568438942
    rotMatrix40.Zy = 0.62618142455029191
    rotMatrix40.Zz = 0.066180472458629236
    translation42 = NXOpen.Point3d(346.17557258823604, 11.276755272774324, 332.90296652911792)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix40, translation42, 0.35104964566987984)
    
    scaleAboutPoint152 = NXOpen.Point3d(110.79273396155087, -58.787981285721209, 0.0)
    viewCenter152 = NXOpen.Point3d(-110.79273396155214, 58.787981285721209, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint152, viewCenter152)
    
    scaleAboutPoint153 = NXOpen.Point3d(88.63418716924059, -47.030385028576966, 0.0)
    viewCenter153 = NXOpen.Point3d(-88.634187169241926, 47.030385028576966, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint153, viewCenter153)
    
    scaleAboutPoint154 = NXOpen.Point3d(70.907349735392302, -37.624308022861577, 0.0)
    viewCenter154 = NXOpen.Point3d(-70.907349735393623, 37.624308022861577, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint154, viewCenter154)
    
    rotMatrix41 = NXOpen.Matrix3x3()
    
    rotMatrix41.Xx = -0.99418570576537602
    rotMatrix41.Xy = 0.056719884176085443
    rotMatrix41.Xz = -0.091529433467351456
    rotMatrix41.Yx = -0.091225364998474293
    rotMatrix41.Yy = 0.0079325788581729954
    rotMatrix41.Yz = 0.99579867793322285
    rotMatrix41.Zx = 0.057207650123895004
    rotMatrix41.Zy = 0.99835861739743215
    rotMatrix41.Zz = -0.0027121643740176285
    translation43 = NXOpen.Point3d(-18.853810156730685, 39.965290140206804, 471.63973611322251)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix41, translation43, 0.68564383919898408)
    
    # ----------------------------------------------
    #   Menu: Tools->Journal->Stop Recording
    # ----------------------------------------------
    
if __name__ == '__main__':
    main()